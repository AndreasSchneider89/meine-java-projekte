package myDemos;

import acm.program.GraphicsProgram;

public class Zero extends GraphicsProgram {

	public static void main(String[] args) {
		new Zero().start(args);
	}
}


