package myDemos;

import acm.program.GraphicsProgram;

public class PaintGrapghicsDemo extends GraphicsProgram {

	public static void main(String[] args) {
		new PaintGrapghicsDemo().start(args);
	}
}


