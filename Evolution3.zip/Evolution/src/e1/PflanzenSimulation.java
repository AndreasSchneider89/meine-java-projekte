package e1;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PflanzenSimulation extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int DELAY = 50;

    private List<Plant2> plants = new ArrayList<>();

    public PflanzenSimulation() {
        setBackground(Color.BLACK);
        setPreferredSize(new java.awt.Dimension(WIDTH, HEIGHT));
        Plant2 plant = new Plant2(WIDTH/2, HEIGHT/2, 5);
        plants.add(plant);
        Thread simulationThread = new Thread(() -> {
            while (true) {
                for (Plant2 p : plants) {
                    p.grow();
                }
                List<Plant2> newPlants = new ArrayList<>();
                for (Plant2 p : plants) {
                    if (p.canReproduce()) {
                        Plant2 babyPlant = p.reproduce();
                        newPlants.add(babyPlant);
                    }
                }
                plants.addAll(newPlants);
                repaint();
                try {
                    Thread.sleep(DELAY);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        simulationThread.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Plant2 p : plants) {
            p.draw(g);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pflanzen Simulation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        PflanzenSimulation panel = new PflanzenSimulation();
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }
}

class Plant2 {
    private int x;
    private int y;
    private int size;
    private int growthRate;
    private int maxAge;
    private int age;

    public Plant2(int x, int y, int size) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.growthRate = 1;
        this.maxAge = 100;
        this.age = 0;
    }

    public void grow() {
        if (age >= maxAge) {
            return;
        }
        size += growthRate;
        age++;
    }

    public boolean canReproduce() {
        return age >= maxAge/2 && Math.random() < 0.02;
    }

    public Plant2 reproduce() {
        Plant2 baby = new Plant2(x + (int) (Math.random()*20 - 10), y + (int) (Math.random()*20 - 10), size/5);
        baby.maxAge = maxAge;
        return baby;
    }

    public void draw(Graphics g) {
        g.setColor(Color.GREEN);
        g.fillOval(x - size/2, y - size/2, size, size);
    }
}