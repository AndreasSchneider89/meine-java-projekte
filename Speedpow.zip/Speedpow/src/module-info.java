/**
 * 
 */
/**
 * @author Andreas Schneider
 *
 Kontext: Ich habe mich gefragt warum die default Division von zwei Integern in vielen Programmiersprachen entgegen jeglicher
 mathematischer Konvention ein Integer zur�ckgibt und keine Float oder Double bzw. nur dann eine Integer, falls der Modulo Wert
 in einer Fallunterscheidung 0 ist�
So wie ich die Sache sehe kann es nur an der Existenz eines Algorithmuses liegen der
Einerseits: Sehr gut sein muss
Andererseits nicht anpassbar war bzw. darauf aufgebaut haben muss, dass die primitive Integer-Division f�lschlicherweise
ein Integer zur�ckgibt und den Nachkommaanteil einfach abschneidet solange man nicht entweder den Dividenden oder Divisor
ebenfalls zu einem Zahlentyp mit Nachkommastellen �ndert. Beispiel: Statt 3 / 5 = 0
3.0 / 5 = 0.6
Vielleicht lag es an am Algorithmus zur Multiplikation sowie Potenzierung mit logarithmischer Geschwindigkeit.
Jene Algorithmen sowohl in einer Form, die eine fehlerhaft auf eine (mathematisch) korrigierte Division reagieren w�rden
als auch in einer angepassten Variante findest du in den beiden Verlinkungen.
Was h�ltst du davon? War dir die Problematik bekannt? Oder hat man sonst gar nicht dar�ber nachgedacht? Falls ja,
dann bringe doch bitte weitere Informatiker auf diese Gedanken...

Context: I asked myself why the default division of two integers in many programming languages, contrary to any mathematical convention,
returns an integer and no float or double or only an integer if the modulo value in a case distinction is 0 ...
The way I see it, it can only be due to the existence of an algorithm
On the one hand: it has to be very good
On the other hand, it was not adaptable or must have been based on the fact that the primitive integer division incorrectly returns
an integer and simply cuts off the fractional part as long as you do not change either the dividend or divisor to a number type with decimal places. Example: Instead of 3/5 = 0
3.0 / 5 = 0.6
Perhaps it was due to the algorithm for multiplication and exponentiation with logarithmic speed.
Those algorithms both in a form that would react incorrectly to a (mathematically) corrected division and in an adapted
variant can be found in the two links.
What do you think about? Did you know the problem? Or did you not think about it at all? If so, please bring these thoughts
to other computer scientists ...
 */
module Speedpow {
}