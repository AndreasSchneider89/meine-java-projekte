package speedpow;

public class Main {

	public static void main(String[] args) {
		new Main().printout(args);
	}

	private void printout(String[] args) {
		double factorA = -7.5;
		int factorB = 6;
		System.out.println(speedMulCthaeh(factorA, factorB));
		
		System.out.println(speedMulCthaehGood(factorA, factorB));
		
		double base = 3;
		int exponent = 3;
		System.out.println(speedPowCthaeh(base, exponent));
		
		System.out.println(speedPowCthaehGood(base, exponent));
		
	}
	// die Algorithmen speedMulCthaeh und speedPowCthaeh w�rden nicht mehr funktionieren wenn der Returntyp der default 
	// Integerdivision nicht jegliche Nachkommastellen abschneiden w�rde.
	// The algorithms speedMulCthaeh and speedPowCthah would no longer work if the return type of the default
	// Integer division would not cut any decimal places.
	
	double speedMulCthaeh(double factorA, int factorB) {
		if(factorB < 0)
			return -speedMulCthaeh(factorA, -factorB);
		double result = 0;
		while (factorB > 0) {
			if (factorB % 2 == 1)
				result = result + factorA;
			factorB = factorB / 2;
			factorA = factorA + factorA;
		}
		return result;
	}
	
	double speedPowCthaeh(double base, int exponent) {
		if (exponent < 0)
			return 1 / speedPowCthaeh(base, -exponent);
		double result = 1;
		while (exponent > 0 ) {
			if(exponent % 2 == 1)
				result = result * base;
			exponent = exponent / 2;
			base = base * base;
		}
		return result;
	}
	
	// Die Algorithmen speedMulCthaehGood und speedPowCthaehGood habe ich so verbessert, dass sie auch noch funktionieren w�rden,
	// wenn der Returntyp der default Integerdivision z.B.: eine Double mit Nachkommerstellen werden k�nnte.
	// Die Beispielrechnungen aus der printout-Methode w�rden auch noch richtig gerechnet, wenn man  die Typen von factorB und exponent
	// in den folgenden beiden Methoden durch double ersetzt.
	
	double speedMulCthaehGood(double factorA, int factorB) {
		if(factorB < 0)
			return -speedMulCthaeh(factorA, -factorB);
		double result = 0;
		while (factorB > 0.5) {
			if (factorB % 2 >= 1)
				result = result + factorA;
			factorB = factorB / 2;
			factorA = factorA + factorA;
		}
		return result;
	}
	
	double speedPowCthaehGood(double base, int exponent) {
		if (exponent < 0)
			return 1 / speedPowCthaeh(base, -exponent);
		double result = 1;
		while (exponent > 0.5 ) {
			if(exponent % 2 >= 1)
				result = result * base;
			exponent = exponent / 2;
			base = base * base;
		}
		return result;
	}
}
