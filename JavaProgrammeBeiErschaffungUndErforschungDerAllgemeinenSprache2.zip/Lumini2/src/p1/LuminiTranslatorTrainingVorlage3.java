package p1;

import java.util.*;

public class LuminiTranslatorTrainingVorlage3 {

	static Map<Character, String> LetterToLumini = new HashMap<>();

	private static Map<String, Character> LuminiToLetter = new HashMap<>();

	private static Random RANDOM = new Random();

	static int motivationPoints = 0;

	static int length = 4;

	static int start = 0;

	static int inc = 2;

	static int mode = 1;

	static double toText = 0.5;

	// Zeichen sortiert nach Häufigkeit (MistralAI)
	// enisratdhulcgmobwfkäzpvöüjßyxq
	// .,"?!-':;()/@#&*
	
	
	// 01234567 // 
	// 89enisra // -
	// tdhulcgm // -.
	// obwfkäzp // --
	// vöüjßyxq // -..
	// .,"?!-´: // -.-
	// ;()/@#&* // --.
	// <>%_^[]{ // ---
	// }~\$§      // -...
	

	static String[] words = {

			"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "e", "f", "g", "h", "i", "j", "k", "l",
			"m", "n", "o", "p", "q", "r", "t", "u", "v", "w", "x", "y", "z", "ä", "ö", "ü", "ß", "A", "B", "C", "D",
			"E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y",
			"Z", "Ä", "Ö", "Ü", "+", "-", "*", "/", "^", "<", ">", "=", "*", "(", ")", "[", "]", "{", "}", "&", "|",
			"!", "~", "%", "$", ".", ",", ";", "_", "#", ":", "?",  "§"


//			
//
//			 "i", "j", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "10", "11", "12", "13", "14", "15", "20",
//			"50",
////
//			"75", "100", "a b", "b c", "c d", "d e", "e f", "f g", "h i", "j k", "0123", "1234", "2345", "3456", "4567",
////
//			"5678", "6789", "789a", "89ab", "9abc", "3210", "4321", "5432", "6543", "7654", "8765", "9876", "a987",

//			"abcd","bcde","cdef","defg","efgh","fghi","ghij","hijk","ijkl","jklm","klmn",
//			"ABCD","BCDE","CDEF","DEFG","EFGH","FGHI","GHIJ","HIJK","IJKL","JKLM","KLMN",
//			"Abcd","Bcde","Cdef","Defg","Efgh","Fghi","Ghij","Hijk","Ijkl","Jklm","Klmn",
//			
//			"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!","Bitte schreib mir eine Nachricht und verbinde unsere Visionen","@Andreas5564","andreas.schneider01989","+491778627094","Fragment des Übergangs","Struktgame","Quantenverschränkung","Collectiv Conciousnes","Telepathie","Search: Heiliges Hirn on YouTube","Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit","Find my Matrixgame-Journal","Please use and improve","Open Source","Photosynthese und Zellatmung","Mandarin","Latein","Deutsch","english","Periodensystem of elements","SI Units","Bit and Byte","Binary Language","Ascii","Hello Universe","Hello World",",.-öäüß!\" $ / ( ) = ? ' @","01234567890","ABCDEFGHIJKLMNOPQRSTUVWXYZ","Licht Forschung","KIGame","Lumini4","Matrixgame","LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT", "HELLO!", "ÄÖÜ", "123",

	};

	static {
		// Ziffern
		LetterToLumini.put('0', ".");
		LetterToLumini.put('1', "-");
		LetterToLumini.put('2', "-.");
		LetterToLumini.put('3', "--");
		LetterToLumini.put('4', "-..");
		LetterToLumini.put('5', "-.-");
		LetterToLumini.put('6', "--.");
		LetterToLumini.put('7', "---");
		LetterToLumini.put('8', "-...");
		LetterToLumini.put('9', "-..-");

		// Häufigste Kleinbuchstaben
		LetterToLumini.put('e', "-.-.");
		LetterToLumini.put('n', "-.--");
		LetterToLumini.put('i', "--..");
		LetterToLumini.put('s', "--.-");
		LetterToLumini.put('r', "---.");
		LetterToLumini.put('a', "----");
		
		LetterToLumini.put('t', "-....");
		LetterToLumini.put('d', "-...-");
		LetterToLumini.put('h', "-..-.");
		LetterToLumini.put('u', "-..--");
		LetterToLumini.put('l', "-.-..");
		LetterToLumini.put('c', "-.-.-");
		LetterToLumini.put('g', "-.--.");
		LetterToLumini.put('m', "-.---");
		
		LetterToLumini.put('o', "--...");
		LetterToLumini.put('b', "--..-");
		LetterToLumini.put('w', "--.-.");
		LetterToLumini.put('f', "--.--");
		LetterToLumini.put('k', "---..");
		LetterToLumini.put('ä', "---.-");
		LetterToLumini.put('z', "----.");
		LetterToLumini.put('p', "-----");
		
		LetterToLumini.put('v', "-.....");
		LetterToLumini.put('ö', "-....-");
		LetterToLumini.put('ü', "-...-.");
		LetterToLumini.put('j', "-...--");
		LetterToLumini.put('ß', "-..-..");
		LetterToLumini.put('y', "-..-.-");
		LetterToLumini.put('x', "-..--.");
		LetterToLumini.put('q', "-..---");
		
		// Sonderzeichen (Programmier-Kontext)
				LetterToLumini.put('.', "-.-...");
				LetterToLumini.put(',', "-.-..-");
				LetterToLumini.put('"', "-.-.-.");
				LetterToLumini.put('?', "-.-.--");
				LetterToLumini.put('!', "-.--..");
				LetterToLumini.put('-', "-.--.-");
				LetterToLumini.put('´', "-.---.");
				LetterToLumini.put(':', "-.----");
				
				
				LetterToLumini.put(';', "--....");
				LetterToLumini.put('(', "--...-");
				LetterToLumini.put(')', "--..-.");
				LetterToLumini.put('/', "--..--");
				LetterToLumini.put('@', "--.-..");
				LetterToLumini.put('#', "--.-.-");
				LetterToLumini.put('&', "--.--.");
				LetterToLumini.put('*', "--.---");
				
				LetterToLumini.put('<', "---...");
				LetterToLumini.put('>', "---..-");
				LetterToLumini.put('%', "---.-.");
				LetterToLumini.put('_', "---.--");
				LetterToLumini.put('^', "----..");
				LetterToLumini.put('[', "----.-");
				LetterToLumini.put(']', "-----.");
				LetterToLumini.put('{', "------");
				
				LetterToLumini.put('}', "-......");
				LetterToLumini.put('|', "-.....-");
				LetterToLumini.put('~', "-....-.");
				LetterToLumini.put('\'', "-....--");
				LetterToLumini.put('$', "-...-..");
				LetterToLumini.put('§', "-...-.-");
		

		// Großbuchstaben
				LetterToLumini.put('E', "-..-.-.");
				LetterToLumini.put('N', "-..-.--");
				LetterToLumini.put('I', "-..--..");
				LetterToLumini.put('S', "-..--.-");
				LetterToLumini.put('R', "-..---.");
				LetterToLumini.put('A', "-..----");
				
				LetterToLumini.put('T', "-.-....");
				LetterToLumini.put('D', "-.-...-");
				LetterToLumini.put('H', "-.-..-.");
				LetterToLumini.put('U', "-.-..--");
				LetterToLumini.put('L', "-.-.-..");
				LetterToLumini.put('C', "-.-.-.-");
				LetterToLumini.put('G', "-.-.--.");
				LetterToLumini.put('M', "-.-.---");
				
				LetterToLumini.put('O', "-.--...");
				LetterToLumini.put('B', "-.--..-");
				LetterToLumini.put('W', "-.--.-.");
				LetterToLumini.put('F', "-.--.--");
				LetterToLumini.put('K', "-.---..");
				LetterToLumini.put('Ä', "-.---.-");
				LetterToLumini.put('Z', "-.----.");
				LetterToLumini.put('P', "-.-----");
				
				LetterToLumini.put('V', "--.....");
				LetterToLumini.put('Ö', "--....-");
				LetterToLumini.put('Ü', "--...-.");
				LetterToLumini.put('J', "--...--");
				LetterToLumini.put('Y', "--..-.-");
				LetterToLumini.put('X', "--..--.");
				LetterToLumini.put('Q', "--..---");

		

		// Leerzeichen
		LetterToLumini.put(' ', " ");

		// Umkehrabbildung
		for (Map.Entry<Character, String> entry : LetterToLumini.entrySet()) {
			LuminiToLetter.put(entry.getValue(), entry.getKey());
		}
	}
	
	// Noch nicht implementiert
	// Soll eine Tabelle wie die folgende Automatisch Generieren
		// 01234567 // 
		// 89enisra // -
		// tdhulcgm // -.
		// obwfkäzp // --
		// vöüjßyxq // -..
		// .,"?!-´: // -.-
		// ;()/@#&* // --.
		// <>%_^[]{ // ---
		// }~\$§    // -...
	public static void printTranslatorTabel() {}


	public static String toLumini(String text) {
		StringBuilder sb = new StringBuilder();
		for (char c : text.toCharArray()) {
			if (LetterToLumini.containsKey(c)) {
				sb.append(LetterToLumini.get(c)).append(" ");
			}
		}
		return sb.toString().trim();
	}

// Lumini -> Klartext
	public static String fromLumini(String morse) {
		StringBuilder sb = new StringBuilder();
		String[] LuminiCodes = morse.split(" ");
		for (String LuminiCode : LuminiCodes) {
			if (LuminiToLetter.containsKey(LuminiCode)) {
				sb.append(LuminiToLetter.get(LuminiCode));
			} else if (LuminiCode.equals(" ")) {
				sb.append(" ");
			}
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("🌟 Willkommen beim Lumini-Translator-Game 🌟");
		System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");
		boolean running = true;
		while (running) {
			System.out.println("Menü:");
			System.out.println("Mode:" + mode + " Start:" + start + " Length:" + length + " Inc:" + inc
					+ " ToTextWahrscheinlichkeit:" + toText);
			System.out.println("1 = Text → LuminiCode");
			System.out.println("2 = LuminiCode → Text");
			System.out.println("3 = Punktestand anzeigen");
			System.out.println("4 = 10er LuminiCode Quest");
			System.out.println("5 = 50er LuminiCode Quest mit inc");
			System.out.println("6 = Mode wählen, Aufgabengenerierung durch randomTextMode oder selber definiert");
			System.out.println("7 = Start einstellen- Wo die Reihe durchschnittlich beginnt");
			System.out.println("8 = Length einstellen - Wie lang die Reihe ist");
			System.out.println("9 = Inc einstellen - in welchen Schritten die Reihe hochzählt");
			System.out.println("10 = ToText Wahrscheinlichkeit 0 bis 1");			
			System.out.println("11 = Übersetzungstabelle ausgeben");
			System.out.println("0 = Beenden");

			System.out.print("Wähle: ");

			int choice = scanner.nextInt();

			scanner.nextLine();

			switch (choice) {
			case 1:
				playTextToLumini(scanner);
				break;
			case 2:
				playLuminiToText(scanner);
				break;
			case 3:
				System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");
				break;
			case 4:
				playLuminiTraining1(scanner);
				break;
			case 5:
				playLuminiTraining2(scanner);
				break;
			case 6:
				mode = scanner.nextInt();
				break;
			case 7:
				start = scanner.nextInt();
				break;
			case 8:
				length = scanner.nextInt();
				break;
			case 9:
				inc = scanner.nextInt();
				break;
			case 10:
				toText = scanner.nextDouble();
				break;			
			case 11:
				printTranslatorTabel();
				break;
			case 0:
				running = false;
				System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");
				break;
			default:
				System.out.println("Ungültige Auswahl!\n");
			}
		}
		scanner.close();
	}

	static void playTextToLumini(Scanner scanner) {
		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String LuminiString = toLumini(word);

		System.out.println("Übersetze in LuminiCode: " + word);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(LuminiString)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + LuminiString + "\n");

		}

	}

	static void playLuminiToText(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String LuminiString = toLumini(word);

		System.out.println("Übersetze in Text: " + LuminiString);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(word)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");

		}

	}

	static void playLuminiTraining1(Scanner scanner) {

		for (int i = 0; i < 10; i++) {

			if (Math.random() > toText)

				playTextToLumini(scanner);

			else

				playLuminiToText(scanner);

		}

	}

	static void playLuminiTraining2(Scanner scanner) {

		for (int i = 0; i < 50; i++) {

			start++;

			if (Math.random() > toText)

				playTextToLumini(scanner);

			else

				playLuminiToText(scanner);

		}

	}

}