package p1;

import java.util.*;

public class LuminiTranslatorTrainingVorlage3InvNumbers {
	
	/**
	 * Created on 17.09.2025
	 * 
	 * @author Andreas Schneider
	 * Weingartenstraße 45, 64297
	 * Handy: +491778627094
	 * Matrixgame-Journal: https://docs.google.com/document/d/1J_qc7-O3qbUb8WOyBHNnLkcEEQ5JklY4d9vmd67RtC4/edit?tab=t.0
	 */
	
	static Map<Character, String> LetterToLumini = new HashMap<>();
	static Map<String, Character> LuminiToLetter = new HashMap<>();
	
	static String[] LuminiStrings=new String[256];
	
	

	static Random RANDOM = new Random();

	static int motivationPoints = 0;

	static int length = 4;

	static int start = 0;

	static int inc = 2;

	static int mode = 1;

	static double toText = 0.5;
	
	static boolean invertNumber=true;

	// Zeichen sortiert nach Häufigkeit (MistralAI)
	// enisratdhulcgmobwfkäzpvöüjßyxq
	// .,"?!-':;()/@#&*
	
	
	// Bit1-3	// Bit4-6  // Bit 7-8
	// 01234567 //     	   // normal
	// 89enisra // 1  	   // groß
	// tdhulcgm // 2	   // AltGr
	// obwfkäzp // 3
	// vöüjßyxq // 4
	// ,.-+^<´# // 5
	


	static String[] words = {

			"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
			"a", "b", "c", "e", "f", "g", "h", "i", "j", "k", "l",
			"m", "n", "o", "p", "q", "r", "t", "u", "v", "w", "x", "y", "z", "ä", "ö", "ü", "ß", "A", "B", "C", "D",
			"E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y",
			"Z", "Ä", "Ö", "Ü", "+", "-", "*", "/", "^", "<", ">", "=", "*", "(", ")", "[", "]", "{", "}", "&", "|",
			"!", "~", "%", "$", ".", ",", ";", "_", "#", ":", "?",  "§",


			

			"10", "11", "12", "13", "14", "15", "20",	"50", "75", "100", "200","500","1000",
			"16","32","64","128","256","512","1024",
			"kg","m","s","N","J",
			"k","M","G","T",
			"d","c","m",
			
			"a b", "b c", "c d", "d e", "e f", "f g", "h i", "j k", "0123", "1234", "2345", "3456", "4567",

			"5678", "6789", "789a", "89ab", "9abc", "3210", "4321", "5432", "6543", "7654", "8765", "9876", "a987",

			"abcd","bcde","cdef","defg","efgh","fghi","ghij","hijk","ijkl","jklm","klmn",
			"ABCD","BCDE","CDEF","DEFG","EFGH","FGHI","GHIJ","HIJK","IJKL","JKLM","KLMN",
			"Abcd","Bcde","Cdef","Defg","Efgh","Fghi","Ghij","Hijk","Ijkl","Jklm","Klmn",
			
			"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", 
			"HELLO!","Bitte schreib mir eine Nachricht und verbinde unsere Visionen"
			,"@Andreas5564","andreas.schneider01989","+491778627094","Fragment des Übergangs",
			"Struktgame","Quantenverschränkung","Collectiv Conciousnes","Telepathie","Search: Heiliges Hirn on YouTube",
			"Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit","Find my Matrixgame-Journal","Please use and improve",
			"Open Source","Photosynthese und Zellatmung","Mandarin","Latein","Deutsch","english","Periodensystem of elements","SI Units"
			,"Bit and Byte","Binary Language","Ascii","Hello Universe","Hello World",",.-öäüß!\" $ / ( ) = ? ' @","01234567890","ABCDEFGHIJKLMNOPQRSTUVWXYZ",
			"Licht Forschung","KIGame","Lumini4","Matrixgame","LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT", "HELLO!", "ÄÖÜ", "123","Matrixgame-Journal","StruktGame",
			"AND","OR","NOT",
			
			"Kraft","Strecke","Zeit","Masse","Kraft(F)","Strecke(s)","Zeit(t)","Masse(m)",
			"F=m*a","g~9.81m/s^2","v=s/t","a=s/t^2","F=G*m1*m2/s^2","s^2=(x2-x1)^2+(y2-y1)^2+(z2-z1)^2","G=6.6743*10^-11N*m^2/kg^2","E=F*s","E~mv^2","a^2+b^2=c^2",
			"Fläche=s^2","Volumen=s^3","Dichte=Masse/Volumen","Geschwindigkeit(v)","Beschleunigung(a)","Frequenz(Hz)=t^-1","sqrt = ^0.5",
			"Math.pow(x,y)=x^y",
			"bit","byte",
			"Schaltnetze","Morse","Ascii",
			"Assembler","Cobal","C++","Java",
			"boolean","char","int","float","double","String","Objekt","Klasse","Massekugel","Ordner","Basis","Element","super","Molekül","...",
			"Modellierung","Simulation","Kollektiv","Bewusstsein","Ursache","Wirkung","Entscheidungsfindung","Evaluation","MinMax",
			"Computer","Internet","AI","LLMs",
			"Level","XP","Freude","Interesse","Begeisterung","Didaktik","Gamification","Motivation","Language","Loop","Rekursion",
			"Input","Operation","Output",
			"ChatGPT","Gemini","DeepSeek","Qwen","Grok","MistralAI","Claude",
			"YouTube","Facebook","Instagram",
			"Reddit","Wikipedia","IBM","Windows","Clint","Server","Browser","IP","URL","Copy","Paste","Send","Deleate","Senden","Empfangen","Speichern",
			"Wissenschaft","Natur","Religion","Spiritualität","Fragment","Übergang","Geist",
			"Proton","Elektron","Neutron","Standard","Equivalenz","Bijektion","Abbildung","Text","Buchstabe","Zeichen","Symbol","Rune","Emoji",
			"Aktien","Währung","Handel","Wirtschaft","Regierung","Währung","Nation","Fachgebiet","Typ","Eigenschaften","Variable","Gleichung",
			
			"Artikel","Protonenzahl","Valenzelektronen",
			
			"Rot","Gelb","Blau", "Magenta","Yellow","Cyan",
			"Color","RGB"
			

	};
	
	public static void makeLuminiStrings(boolean invertString) {
		for(int i=0; i<LuminiStrings.length; i++) {
			String binary=Integer.toBinaryString(i);
			if(invertString)binary=invertString(binary);
			String LuminiString=binary.replace("0", ".").replace("1", "-");
			LuminiStrings[i]=LuminiString;
		}
	}
	
	public static String invertString(String string) {
		String invertString="";
		
		for(int i=0; i<string.length();i++) {
			invertString=string.charAt(i)+invertString;
		}
		
		return invertString;
	}

	static {
	    // 1. Array vor der Nutzung befüllen
	    makeLuminiStrings(invertNumber);
		
		// Ziffern
		LetterToLumini.put('0', LuminiStrings[0]);
		LetterToLumini.put('1', LuminiStrings[1]);
		LetterToLumini.put('2', LuminiStrings[2]);
		LetterToLumini.put('3', LuminiStrings[3]);
		LetterToLumini.put('4', LuminiStrings[4]);
		LetterToLumini.put('5', LuminiStrings[5]);
		LetterToLumini.put('6', LuminiStrings[6]);
		LetterToLumini.put('7', LuminiStrings[7]);
		LetterToLumini.put('8', LuminiStrings[8]);
		LetterToLumini.put('9', LuminiStrings[9]);

		// Häufigste Kleinbuchstaben
		LetterToLumini.put('e', LuminiStrings[10]);
		LetterToLumini.put('n', LuminiStrings[11]);
		LetterToLumini.put('i', LuminiStrings[12]);
		LetterToLumini.put('s', LuminiStrings[13]);
		LetterToLumini.put('r', LuminiStrings[14]);
		LetterToLumini.put('a', LuminiStrings[15]);
		
		LetterToLumini.put('t', LuminiStrings[16]);
		LetterToLumini.put('d', LuminiStrings[17]);
		LetterToLumini.put('h', LuminiStrings[18]);
		LetterToLumini.put('u', LuminiStrings[19]);
		LetterToLumini.put('l', LuminiStrings[20]);
		LetterToLumini.put('c', LuminiStrings[21]);
		LetterToLumini.put('g', LuminiStrings[22]);
		LetterToLumini.put('m', LuminiStrings[23]);
		
		LetterToLumini.put('o', LuminiStrings[24]);
		LetterToLumini.put('b', LuminiStrings[25]);
		LetterToLumini.put('w', LuminiStrings[26]);
		LetterToLumini.put('f', LuminiStrings[27]);
		LetterToLumini.put('k', LuminiStrings[28]);
		LetterToLumini.put('ä', LuminiStrings[29]);
		LetterToLumini.put('z', LuminiStrings[30]);
		LetterToLumini.put('p', LuminiStrings[31]);
		
		LetterToLumini.put('v', LuminiStrings[32]);
		LetterToLumini.put('ö', LuminiStrings[33]);
		LetterToLumini.put('ü', LuminiStrings[34]);
		LetterToLumini.put('j', LuminiStrings[35]);
		LetterToLumini.put('ß', LuminiStrings[36]);
		LetterToLumini.put('y', LuminiStrings[37]);
		LetterToLumini.put('x', LuminiStrings[38]);
		LetterToLumini.put('q', LuminiStrings[39]);
		
		// Sonderzeichen (Programmier-Kontext)
				LetterToLumini.put(',', LuminiStrings[40]);
				LetterToLumini.put('.', LuminiStrings[41]);
				LetterToLumini.put('-', LuminiStrings[42]);
				LetterToLumini.put('+', LuminiStrings[43]);
				LetterToLumini.put('^', LuminiStrings[44]);
				LetterToLumini.put('<', LuminiStrings[45]);
				LetterToLumini.put('´', LuminiStrings[46]);
				LetterToLumini.put('#', LuminiStrings[47]);
						

		// Zeichen Groß
				int inc=64;
				LetterToLumini.put('=', LuminiStrings[0+inc]);
				LetterToLumini.put('!', LuminiStrings[1+inc]);
				LetterToLumini.put('"', LuminiStrings[2+inc]);
				LetterToLumini.put('§', LuminiStrings[3+inc]);
				LetterToLumini.put('$', LuminiStrings[4+inc]);
				LetterToLumini.put('%', LuminiStrings[5+inc]);
				LetterToLumini.put('&', LuminiStrings[6+inc]);
				LetterToLumini.put('/', LuminiStrings[7+inc]);
				
				LetterToLumini.put('(', LuminiStrings[8+inc]);
				LetterToLumini.put(')', LuminiStrings[9+inc]);				
				
				LetterToLumini.put('E', LuminiStrings[10+inc]);
				LetterToLumini.put('N', LuminiStrings[11+inc]);
				LetterToLumini.put('I', LuminiStrings[12+inc]);
				LetterToLumini.put('S', LuminiStrings[13+inc]);
				LetterToLumini.put('R', LuminiStrings[14+inc]);
				LetterToLumini.put('A', LuminiStrings[15+inc]);
				
				LetterToLumini.put('T', LuminiStrings[16+inc]);
				LetterToLumini.put('D', LuminiStrings[17+inc]);
				LetterToLumini.put('H', LuminiStrings[18+inc]);
				LetterToLumini.put('U', LuminiStrings[19+inc]);
				LetterToLumini.put('L', LuminiStrings[20+inc]);
				LetterToLumini.put('C', LuminiStrings[21+inc]);
				LetterToLumini.put('G', LuminiStrings[22+inc]);
				LetterToLumini.put('M', LuminiStrings[23+inc]);
				
				LetterToLumini.put('O', LuminiStrings[24+inc]);
				LetterToLumini.put('B', LuminiStrings[25+inc]);
				LetterToLumini.put('W', LuminiStrings[26+inc]);
				LetterToLumini.put('F', LuminiStrings[27+inc]);
				LetterToLumini.put('K', LuminiStrings[28+inc]);
				LetterToLumini.put('Ä', LuminiStrings[29+inc]);
				LetterToLumini.put('Z', LuminiStrings[30+inc]);
				LetterToLumini.put('P', LuminiStrings[31+inc]);
				
				LetterToLumini.put('V', LuminiStrings[32+inc]);
				LetterToLumini.put('Ö', LuminiStrings[33+inc]);
				LetterToLumini.put('Ü', LuminiStrings[34+inc]);
				LetterToLumini.put('J', LuminiStrings[35+inc]);
				LetterToLumini.put('?', LuminiStrings[36+inc]);
				LetterToLumini.put('Y', LuminiStrings[37+inc]);
				LetterToLumini.put('X', LuminiStrings[38+inc]);
				LetterToLumini.put('Q', LuminiStrings[39+inc]);
				
				LetterToLumini.put(';', LuminiStrings[40+inc]);
				LetterToLumini.put(':', LuminiStrings[41+inc]);
				LetterToLumini.put('_', LuminiStrings[42+inc]);
				LetterToLumini.put('*', LuminiStrings[43+inc]);
				LetterToLumini.put('°', LuminiStrings[44+inc]);
				LetterToLumini.put('>', LuminiStrings[45+inc]);
				LetterToLumini.put('`', LuminiStrings[46+inc]);
//				LetterToLumini.put(''', LuminiStrings[47+inc]);
				
				LetterToLumini.put('}', LuminiStrings[0+inc*2]);
//				LetterToLumini.put('1', LuminiStrings[1+inc*2]);
				LetterToLumini.put('²', LuminiStrings[2+inc*2]);
				LetterToLumini.put('³', LuminiStrings[3+inc*2]);
//				LetterToLumini.put('4', LuminiStrings[4+inc*2]);
//				LetterToLumini.put('5', LuminiStrings[5+inc*2]);
//				LetterToLumini.put('6', LuminiStrings[6+inc*2]);
				LetterToLumini.put('{', LuminiStrings[7+inc*2]);
				
				LetterToLumini.put('[', LuminiStrings[8+inc*2]);
				LetterToLumini.put(']', LuminiStrings[9+inc*2]);
				
//				LetterToLumini.put(',', LuminiStrings[40+inc*2]);
//				LetterToLumini.put('.', LuminiStrings[41+inc*2]);
//				LetterToLumini.put('-', LuminiStrings[42+inc*2]);
				LetterToLumini.put('~', LuminiStrings[43+inc*2]);
//				LetterToLumini.put('', LuminiStrings[44+inc*2]);
				LetterToLumini.put('|', LuminiStrings[45+inc*2]);
//				LetterToLumini.put('´', LuminiStrings[46+inc*2]);
//				LetterToLumini.put('#', LuminiStrings[47+inc*2]);
				
				LetterToLumini.put('@', LuminiStrings[39+inc*2]);

		

		// Leerzeichen
		LetterToLumini.put(' ', " ");

		// Umkehrabbildung
		for (Map.Entry<Character, String> entry : LetterToLumini.entrySet()) {
			LuminiToLetter.put(entry.getValue(), entry.getKey());
		}
	}
	
	// Noch nicht implementiert
	// Soll eine Tabelle wie die folgende Automatisch Generieren
		// 01234567 // 
		// 89enisra // -
		// tdhulcgm // -.
		// obwfkäzp // --
		// vöüjßyxq // -..
		// .,"?!-´: // -.-
		// ;()/@#&* // --.
		// <>%_^[]{ // ---
		// }~\$§    // -...
	public static void printTranslatorTabel() {}


	public static String toLumini(String text) {
		StringBuilder sb = new StringBuilder();
		for (char c : text.toCharArray()) {
			if (LetterToLumini.containsKey(c)) {
				sb.append(LetterToLumini.get(c)).append(" ");
			}
		}
		return sb.toString().trim();
	}

// Lumini -> Klartext
	public static String fromLumini(String morse) {
		StringBuilder sb = new StringBuilder();
		String[] LuminiCodes = morse.split(" ");
		for (String LuminiCode : LuminiCodes) {
			if (LuminiToLetter.containsKey(LuminiCode)) {
				sb.append(LuminiToLetter.get(LuminiCode));
			} else if (LuminiCode.equals(" ")) {
				sb.append(" ");
			}
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("🌟 Willkommen beim Lumini-Translator-Game 🌟");
		System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");
		boolean running = true;
		while (running) {
			System.out.println("Menü:");
			System.out.println("Mode:" + mode + " Start:" + start + " Length:" + length + " Inc:" + inc
					+ " ToTextWahrscheinlichkeit:" + toText);
			System.out.println("1 = Text → LuminiCode");
			System.out.println("2 = LuminiCode → Text");
			System.out.println("3 = Punktestand anzeigen");
			System.out.println("4 = 10er LuminiCode Quest");
			System.out.println("5 = 50er LuminiCode Quest mit inc");
			System.out.println("6 = Mode wählen, Aufgabengenerierung durch randomTextMode oder selber definiert");
			System.out.println("7 = Start einstellen- Wo die Reihe durchschnittlich beginnt");
			System.out.println("8 = Length einstellen - Wie lang die Reihe ist");
			System.out.println("9 = Inc einstellen - in welchen Schritten die Reihe hochzählt");
			System.out.println("10 = ToText Wahrscheinlichkeit 0 bis 1");			
			System.out.println("11 = Übersetzungstabelle ausgeben");
			System.out.println("0 = Beenden");

			System.out.print("Wähle: ");

			int choice = scanner.nextInt();

			scanner.nextLine();

			switch (choice) {
			case 1:
				playTextToLumini(scanner);
				break;
			case 2:
				playLuminiToText(scanner);
				break;
			case 3:
				System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");
				break;
			case 4:
				playLuminiTraining1(scanner);
				break;
			case 5:
				playLuminiTraining2(scanner);
				break;
			case 6:
				mode = scanner.nextInt();
				break;
			case 7:
				start = scanner.nextInt();
				break;
			case 8:
				length = scanner.nextInt();
				break;
			case 9:
				inc = scanner.nextInt();
				break;
			case 10:
				toText = scanner.nextDouble();
				break;			
			case 11:
				printTranslatorTabel();
				break;
			case 0:
				running = false;
				System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");
				break;
			default:
				System.out.println("Ungültige Auswahl!\n");
			}
		}
		scanner.close();
	}

	static void playTextToLumini(Scanner scanner) {
		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String LuminiString = toLumini(word);

		System.out.println("Übersetze in LuminiCode: " + word);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(LuminiString)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + LuminiString + "\n");

		}

	}

	static void playLuminiToText(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String LuminiString = toLumini(word);

		System.out.println("Übersetze in Text: " + LuminiString);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(word)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");

		}

	}

	static void playLuminiTraining1(Scanner scanner) {

		for (int i = 0; i < 10; i++) {

			if (Math.random() > toText)

				playTextToLumini(scanner);

			else

				playLuminiToText(scanner);

		}

	}

	static void playLuminiTraining2(Scanner scanner) {

		for (int i = 0; i < 50; i++) {

			start++;

			if (Math.random() > toText)

				playTextToLumini(scanner);

			else

				playLuminiToText(scanner);

		}

	}

}