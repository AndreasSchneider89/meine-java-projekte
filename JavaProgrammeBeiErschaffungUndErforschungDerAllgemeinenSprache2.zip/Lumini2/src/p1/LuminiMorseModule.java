package p1;

import java.io.*;
import java.util.*;

public class LuminiMorseModule {
    
    private static final Map<Character, String> TEXT_TO_MORSE = new HashMap<>();
    private static final Map<String, Character> MORSE_TO_TEXT = new HashMap<>();
    private int motivationPoints = 0;
    private int highestLevel = 0;
    private final File saveFile = new File("progress.txt");

    static {
        TEXT_TO_MORSE.put('A', ".-"); TEXT_TO_MORSE.put('B', "-..."); TEXT_TO_MORSE.put('C', "-.-.");
        TEXT_TO_MORSE.put('D', "-.."); TEXT_TO_MORSE.put('E', ".");    TEXT_TO_MORSE.put('F', "..-.");
        TEXT_TO_MORSE.put('G', "--."); TEXT_TO_MORSE.put('H', "...."); TEXT_TO_MORSE.put('I', "..");
        TEXT_TO_MORSE.put('J', ".---");TEXT_TO_MORSE.put('K', "-.-");  TEXT_TO_MORSE.put('L', ".-..");
        TEXT_TO_MORSE.put('M', "--");  TEXT_TO_MORSE.put('N', "-.");   TEXT_TO_MORSE.put('O', "---");
        TEXT_TO_MORSE.put('P', ".--.");TEXT_TO_MORSE.put('Q', "--.-"); TEXT_TO_MORSE.put('R', ".-.");
        TEXT_TO_MORSE.put('S', "..."); TEXT_TO_MORSE.put('T', "-");    TEXT_TO_MORSE.put('U', "..-");
        TEXT_TO_MORSE.put('V', "...-");TEXT_TO_MORSE.put('W', ".--");  TEXT_TO_MORSE.put('X', "-..-");
        TEXT_TO_MORSE.put('Y', "-.--");TEXT_TO_MORSE.put('Z', "--.."); TEXT_TO_MORSE.put(' ', "/");

        for (Map.Entry<Character, String> entry : TEXT_TO_MORSE.entrySet()) {
            MORSE_TO_TEXT.put(entry.getValue(), entry.getKey());
        }
    }

    public String toMorse(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toUpperCase().toCharArray()) {
            if (TEXT_TO_MORSE.containsKey(c)) {
                sb.append(TEXT_TO_MORSE.get(c)).append(" ");
            }
        }
        motivationPoints += text.split(" ").length;
        return sb.toString().trim();
    }

    public String fromMorse(String morse) {
        StringBuilder sb = new StringBuilder();
        String[] codes = morse.split(" ");
        for (String code : codes) {
            if (MORSE_TO_TEXT.containsKey(code)) {
                sb.append(MORSE_TO_TEXT.get(code));
            } else if (code.equals("/")) {
                sb.append(" ");
            }
        }
        motivationPoints += morse.split("/").length;
        return sb.toString();
    }

    public int getMotivationPoints() {
        return motivationPoints;
    }

    // Speichern
    public void saveProgress() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(saveFile))) {
            pw.println(motivationPoints);
            pw.println(highestLevel);
        } catch (IOException e) {
            System.out.println("❌ Fehler beim Speichern: " + e.getMessage());
        }
    }

    // Laden
    public void loadProgress() {
        if (!saveFile.exists()) return;
        try (Scanner sc = new Scanner(saveFile)) {
            if (sc.hasNextInt()) motivationPoints = sc.nextInt();
            if (sc.hasNextInt()) highestLevel = sc.nextInt();
            System.out.println("🔄 Fortschritt geladen: " + motivationPoints + " Punkte, Level " + highestLevel);
        } catch (IOException e) {
            System.out.println("❌ Fehler beim Laden: " + e.getMessage());
        }
    }

    // --- QUEST SYSTEM ---
    public void startQuests() {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Lumini Morse Quest ===");
        loadProgress();

        // Level 1
        if (highestLevel < 1) {
            System.out.println("\nLevel 1: Übersetze 'LUMINI' in Morse:");
            String answer1 = sc.nextLine().trim();
            String correct1 = toMorse("LUMINI");
            if (answer1.equals(correct1)) {
                System.out.println("✅ Richtig! +5 Motivation");
                motivationPoints += 5;
                highestLevel = 1;
            } else {
                System.out.println("❌ Falsch. Richtige Antwort: " + correct1);
            }
            saveProgress();
        }

        // Level 2
        if (highestLevel < 2) {
            System.out.println("\nLevel 2: Entschlüssele diesen Morse-Code: '-- .- - .-. .. -..-'");
            String answer2 = sc.nextLine().trim().toUpperCase();
            String correct2 = fromMorse("-- .- - .-. .. -..-");
            if (answer2.equals(correct2)) {
                System.out.println("✅ Richtig! +10 Motivation");
                motivationPoints += 10;
                highestLevel = 2;
            } else {
                System.out.println("❌ Falsch. Richtige Antwort: " + correct2);
            }
            saveProgress();
        }

        // Level 3
        if (highestLevel < 3) {
            System.out.println("\nLevel 3: Entschlüssele den geheimen Satz:");
            String secretMorse = ".-.. .. -.-. .... - .-.-.- / ..-. --- .-. ... -.-. .... ..- -. --.";
            System.out.println("👉 " + secretMorse);
            String answer3 = sc.nextLine().trim().toUpperCase();
            String correct3 = fromMorse(secretMorse);
            if (answer3.equals(correct3)) {
                System.out.println("🌟 Großartig! Du hast das Rätsel gelöst! +20 Motivation");
                motivationPoints += 20;
                highestLevel = 3;
            } else {
                System.out.println("❌ Falsch. Der Satz lautet: " + correct3);
            }
            saveProgress();
        }

        System.out.println("\n=== Quest abgeschlossen ===");
        System.out.println("Deine Motivationspunkte: " + getMotivationPoints());
        System.out.println("Dein höchstes Level: " + highestLevel);
    }

    public static void main(String[] args) {
        LuminiMorseModule game = new LuminiMorseModule();
        game.startQuests();
    }
}
