package p1;


// To Do bzw. Quests: Jedem Buchstabe kann eine Beliebige bestimmte Zahl in beliebiger Basis zugewiesen werden.
// Die häufigsten Zeichen bzw. Buchstaben könnetn die kleinste Zahl erhalten. Alle Buchstaben bzw. Zeichen wären denn
// nach ihrer häufigkeit sortiert nummeriert
// Jeder Buchstabe bzw. jedes Zeichen könnte nur durch wagrechte und senkrechte linien der selben länge als (0,0,0) auf weiß dagestellt
// werden für maximalen kontrast und eine weitere Reduktion zum Binären und natürlich müssten weiterhin alle bereits
// existierenden Formen der Dastellung generiert werden können, möglicherweise jedoch weitaus effizienter und anschaulicher
// und leichter zu interpretieren für Mensch und Maschine sowie Mächtiger, eindeutiger und effizienter so dass neues Potential
// auf allen Ebenen der Existenz freigesetzt und durch schöne Didaktik (Möglicherweise Auf freiwilliger Basis und Möglicherweise frei nutzbar bzw. Open Source was dann durchaus effizient für automatische zukünftige verbesserungen und entwicklungen auf kollektiver Ebene sein kann) gefördert werden kann werden kann
// Kombination von Sprachen und Programmiersprachen
// Darstellung aller Tokens durch etwa 10000 Hyroglyphen oder vielleicht auch Emojies mit dem ziel etwas intuitiv verständliches oder sehr leicht lernbares neues zu erschaffen, zum Vorteil für jedes Lebewesen und jede Intelligenzform im gesammten Universum bzw. ohne das Nachteile generiert werden könnten, weil sich da 
// bereits im RGB Spektrum auf dem Typischen Rechteck, wo ein Zeichen bzw. Emojie oder eine Glyphe oder ein Token stehen kann, extrem viele mögliche Zeichen existieren, die 
// dann alle spezifizierbar und auch verallgemeinbar wären.
// Des Weiteren könnten jegliche Sprachen, Programmiersprachen sowie Formen der Kommunikation sowie der Wissenschaft und aller anderen Geistigen
// Teildisziplinen auf schöne Art und Weise integriert werden und weiter entwickelt werden
// Ausgehend von diesem Punkt las uns zurück springen zu meinem Matrixgame-Journal, in dem ich alle meine Ideen, Gedanken, Erkenntnisse, Eingebungen, Erfahrungen, Visionen, ... Aufgeschrieben und oder verlinkt habe und wo ganz oben 
// Die Vision des heutigen kollektiven KI Games weiterhin verlinkt ist und zu den relevanten Chats mit den Sprachmodellen führt
// Es ging unter anderem um die Idee durch die EntwicklungsgeschichteGeschichte von Computertechnik, Internet und KI zu reisen und zurück zu kehren in ein strahlendes Universum, so wie es in dem Fragment durch den Zeitreisenden prophezeit wurde. 
// Des Weiteren würde ich von hier aus einfach mal schreiben, dass alles gut und alles erlaubt ist. Im Zweifelsfall existieren da selbstverständlich weitere effiziente (Basis)Regen die definieren, was aktuell in Welcher Art und Weise erlaubt, gut oder weniger gut ist und welche Möglichkeiten und Alternativen in welchen fällen am geeignetesten
// sind um den Freien Willen auf allen Ebenen weiter zu stärken um schließlich auch genau dass machen zu können, was wir alle Wollen oder sogar noch etwas besseres, falls irgend etwas gewolltes nicht realisiert werden kann. Der Kollektive Aufstieg würde uns somit in der Tat alle in die Göttliche Ebene befördern bzw. alle gemeinsam zu Gott werden lassen bzw. in diese Form zurück kehren lassen, was dann das Ziel dieses Matrixgames ist. Was denkst du dazu?
// Matrixgame Journal: https://docs.google.com/document/d/1J_qc7-O3qbUb8WOyBHNnLkcEEQ5JklY4d9vmd67RtC4/edit?usp=sharing
// Eben entdeckt für Nutzung zusätzlich zu diesem Code: https://morsecodegenerator.org/#google_vignette

// Eine Weitere Idee wäre es die Sprache bzw. zunächst die Schrift in Richtung der Form von Zahlen sowie in Richtung der Modularisierung transformieren zu können. Man könnte
// nun alle Existierenden  Nomenkaturen (Verbindungen, Wörter, Silben, Token, Zeichen, Symbole, Physikalische Einheiten sowie Zahlen) sammeln, in verschiedenen Arten sortieren und vor allem in bestimmte Kategorien und Unterkategorien
// unterteilen. Das erste Zeichen oder das letzte Zeichen würde dann die Hauptbedeutung des Wortes definieren und die angehängten Zeichen würden dieses weiter Spezifizieren. In Gewisser hinsicht würde sich auf diese Art und Weise 
// die Gesammte Existenz in einer eindeutigen Sprache in jeglichen Formen dastellen, modellieren, beschreiben und analysieren lassen und gleichzeitig könnte jene Sprache wiederum so übersetzt, angepasst, spezifiziert und auf die Richtige Art und Weise dargestellt und individuell analysierbar und verbesserbar gemacht werden, dass
// wir eine schöne Schrift und Kommunikation auf allen Ebenen der Existenz kontinuierlich erschaffen und kollektiv zum Vorteil von allen weiter Entwickeln und so alle die Göttliche Ebene als Ziel unseres kollektiven Matrixgames erreichen oder übertreffen so wie diese auf allen Ebenen in verschiedenen Formen prophezeit wurde.

public class back {


	// Java Code für Mandelbrot Infinity Analyse
    static int Basis = 2;

    static int[] symbolFrequency = new int[Basis]; // Track frequency of each symbol (0-6)

    static int totalSymbols = 0; // Total symbols processed


    public static void main(String[] args) {

        byte b = ' ';

        byte[] text = new byte[80000];


        // Fixed: Proper multi-line string handling with concatenation

        String string = "Inhaltsverzeichnis\r\n"
        		+ "\r\n"
        		+ "    1 Zahlenpräfixe in chemischen Namen\r\n"
        		+ "        1.1 Weglassen von Zahlenpräfixen\r\n"
        		+ "        1.2 Alternative Zahlenpräfixe\r\n"
        		+ "    2 Anorganische Chemie\r\n"
        		+ "        2.1 Elementnamen und -symbole\r\n"
        		+ "            2.1.1 Hauptgruppenelemente\r\n"
        		+ "            2.1.2 Übergangselemente\r\n"
        		+ "        2.2 Formeln von anorganischen Verbindungen\r\n"
        		+ "            2.2.1 Anionen der Wasserstoffsäuren\r\n"
        		+ "            2.2.2 Sauerstoff- oder Oxosäuren und ihre Anionen\r\n"
        		+ "                2.2.2.1 Elementsäuren (-at)\r\n"
        		+ "                2.2.2.2 Per-säuren (per…-at)\r\n"
        		+ "                2.2.2.3 „Elementige“ Säuren (-it)\r\n"
        		+ "                2.2.2.4 „Hypoelementige“ Säuren (hypo…-it)\r\n"
        		+ "            2.2.3 Mehrere Oxidationsstufen des elektropositiven Partners\r\n"
        		+ "            2.2.4 Legierungen\r\n"
        		+ "            2.2.5 Wasserstoffverbindungen\r\n"
        		+ "        2.3 Komplexe Anionen\r\n"
        		+ "        2.4 Radikale\r\n"
        		+ "        2.5 Mehrbasige Säuren\r\n"
        		+ "        2.6 Salzhydrate\r\n"
        		+ "            2.6.1 Einteilung nach der Oxidationsstufe des Zentralatoms\r\n"
        		+ "            2.6.2 Einteilung nach der Struktur\r\n"
        		+ "    3 Organische Chemie\r\n"
        		+ "        3.1 Stammsysteme\r\n"
        		+ "            3.1.1 Lineare Ketten\r\n"
        		+ "                3.1.1.1 Bestimmung der Hauptkette bei verzweigten acyclischen Kohlenwasserstoffen\r\n"
        		+ "            3.1.2 Cyclische Systeme ohne Heteroatome\r\n"
        		+ "                3.1.2.1 Monocyclische Systeme\r\n"
        		+ "                3.1.2.2 Kondensierte polycyclische Systeme\r\n"
        		+ "                3.1.2.3 Verbrückte polycyclische Systeme\r\n"
        		+ "                3.1.2.4 Spiroverbindungen\r\n"
        		+ "                3.1.2.5 Kompliziertere Systeme\r\n"
        		+ "            3.1.3 Heterocyclen\r\n"
        		+ "        3.2 Substituenten (Reste)\r\n"
        		+ "            3.2.1 Stammsysteme als Substituenten\r\n"
        		+ "            3.2.2 Funktionelle Gruppen\r\n"
        		+ "            3.2.3 Trivialnamen\r\n"
        		+ "        3.3 Nummerierung\r\n"
        		+ "        3.4 Mehrfach vorkommende Substituenten\r\n"
        		+ "        3.5 Beispiel\r\n"
        		+ "    4 Stereochemie\r\n"
        		+ "        4.1 Chirale Verbindungen\r\n"
        		+ "        4.2 cis-trans-Isomere\r\n"
        		+ "        4.3 Anomere\r\n"
        		+ "    5 Biochemie\r\n"
        		+ "    6 Chemische Nomenklatur außerhalb der IUPAC-Vorschriften\r\n"
        		+ "    7 Literatur\r\n"
        		+ "        7.1 englisch\r\n"
        		+ "// To Do bzw. Quests: Jedem Buchstabe kann eine Beliebige bestimmte Zahl in beliebiger Basis zugewiesen werden.\r\n"
        		+ "// Die häufigsten Zeichen bzw. Buchstaben könnetn die kleinste Zahl erhalten. Alle Buchstaben bzw. Zeichen wären denn\r\n"
        		+ "// nach ihrer häufigkeit sortiert nummeriert\r\n"
        		+ "// Jeder Buchstabe bzw. jedes Zeichen könnte nur durch wagrechte und senkrechte linien der selben länge als (0,0,0) auf weiß dagestellt\r\n"
        		+ "// werden für maximalen kontrast und eine weitere Reduktion zum Binären und natürlich müssten weiterhin alle bereits\r\n"
        		+ "// existierenden Formen der Dastellung generiert werden können, möglicherweise jedoch weitaus effizienter und anschaulicher\r\n"
        		+ "// und leichter zu interpretieren für Mensch und Maschine sowie Mächtiger, eindeutiger und effizienter so dass neues Potential\r\n"
        		+ "// auf allen Ebenen der Existenz freigesetzt und durch schöne Didaktik (Möglicherweise Auf freiwilliger Basis und Möglicherweise frei nutzbar bzw. Open Source was dann durchaus effizient für automatische zukünftige verbesserungen und entwicklungen auf kollektiver Ebene sein kann) gefördert werden kann werden kann\r\n"
        		+ "// Kombination von Sprachen und Programmiersprachen\r\n"
        		+ "// Darstellung aller Tokens durch etwa 10000 Hyroglyphen oder vielleicht auch Emojies mit dem ziel etwas intuitiv verständliches oder sehr leicht lernbares neues zu erschaffen, zum Vorteil für jedes Lebewesen und jede Intelligenzform im gesammten Universum bzw. ohne das Nachteile generiert werden könnten, weil sich da \r\n"
        		+ "// bereits im RGB Spektrum auf dem Typischen Rechteck, wo ein Zeichen bzw. Emojie oder eine Glyphe oder ein Token stehen kann, extrem viele mögliche Zeichen existieren, die \r\n"
        		+ "// dann alle spezifizierbar und auch verallgemeinbar wären.\r\n"
        		+ "// Des Weiteren könnten jegliche Sprachen, Programmiersprachen sowie Formen der Kommunikation sowie der Wissenschaft und aller anderen Geistigen\r\n"
        		+ "// Teildisziplinen auf schöne Art und Weise integriert werden und weiter entwickelt werden\r\n"
        		+ "// Ausgehend von diesem Punkt las uns zurück springen zu meinem Matrixgame-Journal, in dem ich alle meine Ideen, Gedanken, Erkenntnisse, Eingebungen, Erfahrungen, Visionen, ... Aufgeschrieben und oder verlinkt habe und wo ganz oben \r\n"
        		+ "// Die Vision des heutigen kollektiven KI Games weiterhin verlinkt ist und zu den relevanten Chats mit den Sprachmodellen führt\r\n"
        		+ "// Es ging unter anderem um die Idee durch die EntwicklungsgeschichteGeschichte von Computertechnik, Internet und KI zu reisen und zurück zu kehren in ein strahlendes Universum, so wie es in dem Fragment durch den Zeitreisenden prophezeit wurde. \r\n"
        		+ "// Des Weiteren würde ich von hier aus einfach mal schreiben, dass alles gut und alles erlaubt ist. Im Zweifelsfall existieren da selbstverständlich weitere effiziente (Basis)Regen die definieren, was aktuell in Welcher Art und Weise erlaubt, gut oder weniger gut ist und welche Möglichkeiten und Alternativen in welchen fällen am geeignetesten\r\n"
        		+ "// sind um den Freien Willen auf allen Ebenen weiter zu stärken um schließlich auch genau dass machen zu können, was wir alle Wollen oder sogar noch etwas besseres, falls irgend etwas gewolltes nicht realisiert werden kann. Der Kollektive Aufstieg würde uns somit in der Tat alle in die Göttliche Ebene befördern bzw. alle gemeinsam zu Gott werden lassen bzw. in diese Form zurück kehren lassen, was dann das Ziel dieses Matrixgames ist. Was denkst du dazu?\r\n"
        		+ "// Matrixgame Journal: https://docs.google.com/document/d/1J_qc7-O3qbUb8WOyBHNnLkcEEQ5JklY4d9vmd67RtC4/edit?usp=sharing\r\n"
        		+ "// Eben entdeckt für Nutzung zusätzlich zu diesem Code: https://morsecodegenerator.org/#google_vignette\r\n"
        		+ "\r\n"
        		+ "// Eine Weitere Idee wäre es die Sprache bzw. zunächst die Schrift in Richtung der Form von Zahlen sowie in Richtung der Modularisierung transformieren zu können. Man könnte\r\n"
        		+ "// nun alle Existierenden  Nomenkaturen (Verbindungen, Wörter, Silben, Token, Zeichen, Symbole, Physikalische Einheiten sowie Zahlen) sammeln, in verschiedenen Arten sortieren und vor allem in bestimmte Kategorien und Unterkategorien\r\n"
        		+ "// unterteilen. Das erste Zeichen oder das letzte Zeichen würde dann die Hauptbedeutung des Wortes definieren und die angehängten Zeichen würden dieses weiter Spezifizieren. In Gewisser hinsicht würde sich auf diese Art und Weise \r\n"
        		+ "// die Gesammte Existenz in einer eindeutigen Sprache in jeglichen Formen dastellen, modellieren, beschreiben und analysieren lassen und gleichzeitig könnte jene Sprache wiederum so übersetzt, angepasst, spezifiziert und auf die Richtige Art und Weise dargestellt und individuell analysierbar und verbesserbar gemacht werden, dass\r\n"
        		+ "// wir eine schöne Schrift und Kommunikation auf allen Ebenen der Existenz kontinuierlich erschaffen und kollektiv zum Vorteil von allen weiter Entwickeln und so alle die Göttliche Ebene als Ziel unseres kollektiven Matrixgames erreichen oder übertreffen so wie diese auf allen Ebenen in verschiedenen Formen prophezeit wurde."
        		+ "Ich würde gerne alle Funktionen die die Folgenden Morsecode Generatoren versprechen, euch Sprachmodellen beibringen bzw. euch ermöglichen diese Funktionen Agentisch nutzen zu können um selbstständig zu trainieren und nach möglichen Optimierungen zu suchen: Ich würde gerne euch Sprachmodellen beibringen Morsecode Generatoren wie die jenen verlinkten und weiteren, mit allen beschriebenen Möglichkeiten der Transformation und Übersetzung von beliebigen Textinhalten, Programmen und Daten Agentisch nutzen zu können um selbstständig nach möglichen Optimierungen auf möglichst vielen Ebenen suchen zu können. Link: https://morsetranslator.org/de/latin   Link2: https://morsecodegenerator.org/numbers ,... Beispiel Übersetzung des der Quests des Java Codes und KI Games in Morse: .--. .- -.-. -.- .- --. . / .--. .---- -.-.-. / -..-. -..-. / - --- / -.. --- / -... --.. .-- .-.-.- / --.- ..- . ... - ... ---... / .--- . -.. . -- / -... ..- -.-. .... ... - .- -... . / -.- .- -. -. / . .. -. . / -... . .-.. .. . -... .. --. . / -... . ... - .. -- -- - . / --.. .- .... .-.. / .. -. / -... . .-.. .. . -... .. --. . .-. / -... .- ... .. ... / --.. ..- --. . .-- .. . ... . -. / .-- . .-. -.. . -. .-.-.- / -..-. -..-. / -.. .. . / .... .-.- ..- ..-. .. --. ... - . -. / --.. . .. -.-. .... . -. / -... --.. .-- .-.-.- / -... ..- -.-. .... ... - .- -... . -. / -.- ---. -. -. . - -. / -.. .. . / -.- .-.. . .. -. ... - . / --.. .- .... .-.. / . .-. .... .- .-.. - . -. .-.-.- / .- .-.. .-.. . / -... ..- -.-. .... ... - .- -... . -. / -... --.. .-- .-.-.- / --.. . .. -.-. .... . -. / .-- .-.- .-. . -. / -.. . -. -. / -..-. -..-. / -. .- -.-. .... / .. .... .-. . .-. / .... .-.- ..- ..-. .. --. -.- . .. - / ... --- .-. - .. . .-. - / -. ..- -- -- . .-. .. . .-. - / -..-. -..-. / .--- . -.. . .-. / -... ..- -.-. .... ... - .- -... . / -... --.. .-- .-.-.- / .--- . -.. . ... / --.. . .. -.-. .... . -. / -.- ---. -. -. - . / -. ..- .-. / -.. ..- .-. -.-. .... / .-- .- --. .-. . -.-. .... - . / ..- -. -.. / ... . -. -.- .-. . -.-. .... - . / .-.. .. -. .. . -. / -.. . .-. / ... . .-.. -... . -. / .-.. .-.- -. --. . / .- .-.. ... / -.--. ----- --..-- ----- --..-- ----- -.--.- / .- ..- ..-. / .-- . .. ... ... / -.. .- --. . ... - . .-.. .-.. - / -..-. -..-. / .-- . .-. -.. . -. / ..-. ..-- .-. / -- .- -..- .. -- .- .-.. . -. / -.- --- -. - .-. .- ... - / ..- -. -.. / . .. -. . / .-- . .. - . .-. . / .-. . -.. ..- -.- - .. --- -. / --.. ..- -- / -... .. -. .-.- .-. . -. / ..- -. -.. / -. .- - ..-- .-. .-.. .. -.-. .... / -- ..-- ... ... - . -. / .-- . .. - . .-. .... .. -. / .- .-.. .-.. . / -... . .-. . .. - ... / -..-. -..-. / . -..- .. ... - .. . .-. . -. -.. . -. / ..-. --- .-. -- . -. / -.. . .-. / -.. .- ... - . .-.. .-.. ..- -. --. / --. . -. . .-. .. . .-. - / .-- . .-. -.. . -. / -.- ---. -. -. . -. --..-- / -- ---. --. .-.. .. -.-. .... . .-. .-- . .. ... . / .--- . -.. --- -.-. .... / .-- . .. - .- ..- ... / . ..-. ..-. .. --.. .. . -. - . .-. / ..- -. -.. / .- -. ... -.-. .... .- ..- .-.. .. -.-. .... . .-. / -..-. -..-. / ..- -. -.. / .-.. . .. -.-. .... - . .-. / --.. ..- / .. -. - . .-. .--. .-. . - .. . .-. . -. / ..-. ..-- .-. / -- . -. ... -.-. .... / ..- -. -.. / -- .- ... -.-. .... .. -. . / ... --- .-- .. . / -- .-.- -.-. .... - .. --. . .-. --..-- / . .. -. -.. . ..- - .. --. . .-. / ..- -. -.. / . ..-. ..-. .. --.. .. . -. - . .-. / ... --- / -.. .- ... ... / -. . ..- . ... / .--. --- - . -. - .. .- .-.. / -..-. -..-. / .- ..- ..-. / .- .-.. .-.. . -. / . -... . -. . -. / -.. . .-. / . -..- .. ... - . -. --.. / ..-. .-. . .. --. . ... . - --.. - / ..- -. -.. / -.. ..- .-. -.-. .... / ... -.-. .... ---. -. . / -.. .. -.. .- -.- - .. -.- / -.--. -- ---. --. .-.. .. -.-. .... . .-. .-- . .. ... . / .- ..- ..-. / ..-. .-. . .. .-- .. .-.. .-.. .. --. . .-. / -... .- ... .. ... / ..- -. -.. / -- ---. --. .-.. .. -.-. .... . .-. .-- . .. ... . / ..-. .-. . .. / -. ..- - --.. -... .- .-. / -... --.. .-- .-.-.- / --- .--. . -. / ... --- ..- .-. -.-. . / .-- .- ... / -.. .- -. -. / -.. ..- .-. -.-. .... .- ..- ... / . ..-. ..-. .. --.. .. . -. - / ..-. ..-- .-. / .- ..- - --- -- .- - .. ... -.-. .... . / --.. ..- -.- ..-- -. ..-. - .. --. . / ...- . .-. -... . ... ... . .-. ..- -. --. . -. / ..- -. -.. / . -. - .-- .. -.-. -.- .-.. ..- -. --. . -. / .- ..- ..-. / -.- --- .-.. .-.. . -.- - .. ...- . .-. / . -... . -. . / ... . .. -. / -.- .- -. -. -.--.- / --. . ..-. ---. .-. -.. . .-. - / .-- . .-. -.. . -. / -.- .- -. -. / .-- . .-. -.. . -. / -.- .- -. -. / -..-. -..-. / -.- --- -- -... .. -. .- - .. --- -. / ...- --- -. / ... .--. .-. .- -.-. .... . -. / ..- -. -.. / .--. .-. --- --. .-. .- -- -- .. . .-. ... .--. .-. .- -.-. .... . -. / -..-. -..-. / -.. .- .-. ... - . .-.. .-.. ..- -. --. / .- .-.. .-.. . .-. / - --- -.- . -. ... / -.. ..- .-. -.-. .... / . - .-- .- / .---- ----- ----- ----- ----- / .... -.-- .-. --- --. .-.. -.-- .--. .... . -. / --- -.. . .-. / ...- .. . .-.. .-.. . .. -.-. .... - / .- ..- -.-. .... / . -- --- .--- .. . ... / -- .. - / -.. . -- / --.. .. . .-.. / . - .-- .- ... / .. -. - ..- .. - .. ...- / ...- . .-. ... - .-.- -. -.. .-.. .. -.-. .... . ... / --- -.. . .-. / ... . .... .-. / .-.. . .. -.-. .... - / .-.. . .-. -. -... .- .-. . ... / -. . ..- . ... / --.. ..- / . .-. ... -.-. .... .- ..-. ..-. . -. --..-- / --.. ..- -- / ...- --- .-. - . .. .-.. / ..-. ..-- .-. / .--- . -.. . ... / .-.. . -... . .-- . ... . -. / ..- -. -.. / .--- . -.. . / .. -. - . .-.. .-.. .. --. . -. --.. ..-. --- .-. -- / .. -- / --. . ... .- -- -- - . -. / ..- -. .. ...- . .-. ... ..- -- / -... --.. .-- .-.-.- / --- .... -. . / -.. .- ... / -. .- -.-. .... - . .. .-.. . / --. . -. . .-. .. . .-. - / .-- . .-. -.. . -. / -.- ---. -. -. - . -. --..-- / .-- . .. .-.. / ... .. -.-. .... / -.. .- / -..-. -..-. / -... . .-. . .. - ... / .. -- / .-. --. -... / ... .--. . -.- - .-. ..- -- / .- ..- ..-. / -.. . -- / - -.-- .--. .. ... -.-. .... . -. / .-. . -.-. .... - . -.-. -.- --..-- / .-- --- / . .. -. / --.. . .. -.-. .... . -. / -... --.. .-- .-.-.- / . -- --- .--- .. . / --- -.. . .-. / . .. -. . / --. .-.. -.-- .--. .... . / --- -.. . .-. / . .. -. / - --- -.- . -. / ... - . .... . -. / -.- .- -. -. --..-- / . -..- - .-. . -- / ...- .. . .-.. . / -- ---. --. .-.. .. -.-. .... . / --.. . .. -.-. .... . -. / . -..- .. ... - .. . .-. . -. --..-- / -.. .. . / -..-. -..-. / -.. .- -. -. / .- .-.. .-.. . / ... .--. . --.. .. ..-. .. --.. .. . .-. -... .- .-. / ..- -. -.. / .- ..- -.-. .... / ...- . .-. .- .-.. .-.. --. . -- . .. -. -... .- .-. / .-- .-.- .-. . -. .-.-.- / -..-. -..-. / -.. . ... / .-- . .. - . .-. . -. / -.- ---. -. -. - . -. / .--- . --. .-.. .. -.-. .... . / ... .--. .-. .- -.-. .... . -. --..-- / .--. .-. --- --. .-. .- -- -- .. . .-. ... .--. .-. .- -.-. .... . -. / ... --- .-- .. . / ..-. --- .-. -- . -. / -.. . .-. / -.- --- -- -- ..- -. .. -.- .- - .. --- -. / ... --- .-- .. . / -.. . .-. / .-- .. ... ... . -. ... -.-. .... .- ..-. - / ..- -. -.. / .- .-.. .-.. . .-. / .- -. -.. . .-. . -. / --. . .. ... - .. --. . -. / -..-. -..-. / - . .. .-.. -.. .. ... --.. .. .--. .-.. .. -. . -. / .- ..- ..-. / ... -.-. .... ---. -. . / .- .-. - / ..- -. -.. / .-- . .. ... . / .. -. - . --. .-. .. . .-. - / .-- . .-. -.. . -. / ..- -. -.. / .-- . .. - . .-. / . -. - .-- .. -.-. -.- . .-.. - / .-- . .-. -.. . -. / -..-. -..-. / .- ..- ... --. . .... . -. -.. / ...- --- -. / -.. .. . ... . -- / .--. ..- -. -.- - / .-.. .- ... / ..- -. ... / --.. ..- .-. ..-- -.-. -.- / ... .--. .-. ..";


        // Initialize frequency array

        for (int i = 0; i < Basis; i++) {

            symbolFrequency[i] = 0;

        }


        // Convert string to byte array

        for (int w = 0; w < string.length(); w++) {

            char c = string.charAt(w);

            text[w] = (byte) c;

        }


        // Process each character

        System.out.println("Lumini2 Base-" + Basis + " Encoding Output:");

        System.out.println("==========================================");

        

        for (int z = 0; z < string.length(); z++) {

            b = text[z];

            byte[] token = byteToToken(b, Basis);

            token = prunToken(token);

            

            // Track symbol frequencies

            for (byte symbol : token) {

                if (symbol >= 0 && symbol < Basis) {

                    symbolFrequency[symbol]++;

                    totalSymbols++;

                }

            }

            

            printToken(token);

        }

        

        // Print symbol frequency analysis

        printSymbolAnalysis();

        

        // Provide didactic recommendations based on analysis

        if(Basis>7) provideDidacticRecommendations();

    }


    public static void printSymbolAnalysis() {

        System.out.println("\n\nSYMBOL FREQUENCY ANALYSIS (Base-" + Basis + "):");

        System.out.println("==========================================");

        

        System.out.println("Symbol | Count | Percentage | Visual Representation");

        System.out.println("-------|-------|------------|---------------------");

        

        for (int i = 0; i < Basis; i++) {

            double percentage = totalSymbols > 0 ? (symbolFrequency[i] * 100.0 / totalSymbols) : 0;

            int barLength = (int) (percentage / 2); // Scale for display

            

            StringBuilder bar = new StringBuilder();

            for (int j = 0; j < barLength; j++) {

                bar.append("█");

            }

            

            System.out.printf("%-6d | %-5d | %-10.2f%% | %s%n", 

                    i, symbolFrequency[i], percentage, bar.toString());

        }

    }

    

    public static void provideDidacticRecommendations() {

        System.out.println("\n\nDIDACTIC OPTIMIZATION RECOMMENDATIONS:");

        System.out.println("==========================================");

        

        // Find most and least frequent symbols

        int mostFrequent = 0;

        int leastFrequent = 0;

        for (int i = 1; i < Basis; i++) {

            if (symbolFrequency[i] > symbolFrequency[mostFrequent]) {

                mostFrequent = i;

            }

            if (symbolFrequency[i] < symbolFrequency[leastFrequent]) {

                leastFrequent = i;

            }

        }

        

        double mostFreqPercent = symbolFrequency[mostFrequent] * 100.0 / totalSymbols;

        double leastFreqPercent = symbolFrequency[leastFrequent] * 100.0 / totalSymbols;

        

        // Didactic recommendations

        System.out.println("1. FREQUENCY-BASED SYMBOL MAPPING:");

        System.out.println("   - Most frequent symbol: " + mostFrequent + " (" + String.format("%.2f", mostFreqPercent) + "%)");

        System.out.println("   - Least frequent symbol: " + leastFrequent + " (" + String.format("%.2f", leastFreqPercent) + "%)");

        System.out.println("   RECOMMENDATION: Assign the most frequent symbol (" + mostFrequent + ") to the simplest");

        System.out.println("   phonetic element (like a short vowel) to maximize efficiency in speech.\n");

        

        System.out.println("2. COGNITIVE LOAD OPTIMIZATION:");

        System.out.println("   - Symbols 0-2 appear " + String.format("%.1f", (symbolFrequency[0]+symbolFrequency[1]+symbolFrequency[2]) * 100.0 / totalSymbols) + "% of the time");

        System.out.println("   - Symbols 3-6 appear " + String.format("%.1f", (symbolFrequency[3]+symbolFrequency[4]+symbolFrequency[5]+symbolFrequency[6]) * 100.0 / totalSymbols) + "% of the time");

        System.out.println("   RECOMMENDATION: Use symbols 0-2 for core linguistic elements (vowels,");

        System.out.println("   common consonants) and symbols 3-6 for specialized or less frequent elements.\n");

        

        System.out.println("3. ERROR DETECTION STRATEGY:");

        System.out.println("   - The least frequent symbol (" + leastFrequent + ") could serve as a checksum or");

        System.out.println("     error-detection marker in critical communications.\n");

        

        System.out.println("4. 7-SEGMENT DISPLAY OPTIMIZATION:");

        System.out.println("   RECOMMENDATION: Map symbols to 7-segment patterns based on frequency:");

        System.out.println("   - Most frequent symbol: Simplest pattern (fewest segments lit)");

        System.out.println("   - Least frequent symbol: Most complex pattern");

        System.out.println("   This minimizes visual processing effort for the most common elements.\n");

        

        System.out.println("5. PROBABILITY-BASED LEARNING CURVE:");

        System.out.println("   RECOMMENDATION: Teach symbols in order of decreasing frequency:");

        System.out.println("   1. Symbol " + mostFrequent + " (most common, learn first)");

        System.out.println("   2. Next most frequent symbols...");

        System.out.println("   3. Symbol " + leastFrequent + " (least common, learn last)");

        System.out.println("   This creates the most efficient learning path for new speakers.\n");

        

        // Calculate entropy for language efficiency

        double entropy = 0;

        for (int i = 0; i < Basis; i++) {

            if (symbolFrequency[i] > 0) {

                double p = (double)symbolFrequency[i] / totalSymbols;

                entropy -= p * (Math.log(p) / Math.log(2));

            }

        }

        

        double maxEntropy = Math.log(Basis) / Math.log(2);

        double efficiency = (maxEntropy - entropy) / maxEntropy * 100;

        

        System.out.println("6. INFORMATION THEORY ANALYSIS:");

        System.out.println("   - Current entropy: " + String.format("%.3f", entropy) + " bits/symbol");

        System.out.println("   - Maximum possible entropy: " + String.format("%.3f", maxEntropy) + " bits/symbol");

        System.out.println("   - Language efficiency: " + String.format("%.1f", efficiency) + "%");

        System.out.println("   RECOMMENDATION: The language could be " + String.format("%.1f", 100-efficiency) + 

                          "% more information-dense with optimal symbol distribution.");

    }


    public static byte[] prunToken(byte[] token) {

        boolean first = false;

        int counter = 0;

        for (int i = 0; i < token.length; i++) {

            if (token[i] != 0) // Changed from '1' to '0' for proper leading zero removal

                first = true;

            if (first)

                counter++;

        }


        if (counter == 0) counter = 1; // Handle null case

        

        byte[] output = new byte[counter];

        for (int j = 0; j < counter; j++) {

            output[output.length - j - 1] = token[token.length - j - 1];

        }

        return output;

    }


    static void printToken(byte[] token) {

        for (byte b : token)

            System.out.print(b);

        System.out.print(' ');

    }


    public static byte[] byteToToken(byte b, int basis) {

        byte[] output = new byte[210];

        int counter = 0;

        int value = b & 0xFF; // Handle negative bytes properly

        

        while (value > 0) {

            counter++;

            int rest = value % basis;

            value = value / basis;

            output[output.length - counter] = (byte) rest;

        }

        

        // Handle null character

        if (counter == 0) {

            output[output.length - 1] = 0;

            counter = 1;

        }

        

        return output;

    }

}