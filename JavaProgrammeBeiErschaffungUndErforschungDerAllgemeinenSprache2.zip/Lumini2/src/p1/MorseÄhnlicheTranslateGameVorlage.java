package p1;

import java.util.*;

public class MorseÄhnlicheTranslateGameVorlage {

	static Map<Character, String> LetterToCode = new HashMap<>();

	private static Map<String, Character> CodeToLetter = new HashMap<>();

	private static Random RANDOM = new Random();

	static int motivationPoints = 0;

	static int length = 4;

	static int start = 0;

	static int inc = 2;

	static int mode = 1;

	static double toText = 0.5;

	// 01234567 // .
	// 89abcdef // -
	// sjklöiru // -.
	// ghwotzqp // --
	// vncmxyäü //-..
	// =~-+/&*( //-.- //-..
	// )|?\^><! //--. //-.-
	// []{}%'"ß //---
	// $#/;_., //-...
	// 01234567
	// ABCDEF /-..-
	// SJKLÖIRU -.-.
	// GHWOTZQP /-.--
	// VNCMXYÄÜ /--..

	static String[] words = {

			"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "e", "f", "g", "h", "i", "j", "k", "l",
			"m", "n", "o", "p", "q", "r", "t", "u", "v", "w", "x", "y", "z", "ä", "ö", "ü", "ß", "A", "B", "C", "D",
			"E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y",
			"Z", "Ä", "Ö", "Ü", "+", "-", "*", "/", "^", "<", ">", "=", "*", "(", ")", "[", "]", "{", "}", "&", "|",
			"!", "~", "%", "$", ".", ",", ";", "_", "#", ":", "?", "'", "´", "´"
//			,"""

//			
//
			, "i", "j", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "10", "11", "12", "13", "14", "15", "20",
			"50",
////
			"75", "100", "a b", "b c", "c d", "d e", "e f", "f g", "h i", "j k", "0123", "1234", "2345", "3456", "4567",
////
			"5678", "6789", "789a", "89ab", "9abc", "3210", "4321", "5432", "6543", "7654", "8765", "9876", "a987",

//			"abcd","bcde","cdef","defg","efgh","fghi","ghij","hijk","ijkl","jklm","klmn",
//			"ABCD","BCDE","CDEF","DEFG","EFGH","FGHI","GHIJ","HIJK","IJKL","JKLM","KLMN",
//			"Abcd","Bcde","Cdef","Defg","Efgh","Fghi","Ghij","Hijk","Ijkl","Jklm","Klmn",
//			
//			"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!","Bitte schreib mir eine Nachricht und verbinde unsere Visionen","@Andreas5564","andreas.schneider01989","+491778627094","Fragment des Übergangs","Struktgame","Quantenverschränkung","Collectiv Conciousnes","Telepathie","Search: Heiliges Hirn on YouTube","Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit","Find my Matrixgame-Journal","Please use and improve","Open Source","Photosynthese und Zellatmung","Mandarin","Latein","Deutsch","english","Periodensystem of elements","SI Units","Bit and Byte","Binary Language","Ascii","Hello Universe","Hello World",",.-öäüß!\" $ / ( ) = ? ' @","01234567890","ABCDEFGHIJKLMNOPQRSTUVWXYZ","Licht Forschung","KIGame","Lumini4","Matrixgame","LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT", "HELLO!", "ÄÖÜ", "123",

	};

	static {
		// Ziffern
		LetterToCode.put('0', ".");
		LetterToCode.put('1', "-");
		LetterToCode.put('2', "-.");
		LetterToCode.put('3', "--");
		LetterToCode.put('4', "-..");
		LetterToCode.put('5', "-.-");
		LetterToCode.put('6', "--.");
		LetterToCode.put('7', "---");
		LetterToCode.put('8', "-...");
		LetterToCode.put('9', "-..-");

		// Häufigste Kleinbuchstaben
		LetterToCode.put('e', "-.-.");
		LetterToCode.put('n', "-.--");
		LetterToCode.put('i', "--..");
		LetterToCode.put('r', "--.-");
		LetterToCode.put('t', "---.");
		LetterToCode.put('a', "----");
		
		LetterToCode.put('h', ".-..");
		LetterToCode.put('u', ".--.");
		LetterToCode.put('o', ".---");
		LetterToCode.put('l', "..-.");

		// Weitere mittlere Buchstaben
		LetterToCode.put('c', "..--");
		LetterToCode.put('m', ".-.-");
		LetterToCode.put('g', ".--.");
		LetterToCode.put('f', ".-.-.");
		LetterToCode.put('b', "..-..");
		LetterToCode.put('k', ".-..-");
		LetterToCode.put('w', "..--.");
		LetterToCode.put('v', ".---.");
		LetterToCode.put('z', ".----");

		// Umlaute + ß
		LetterToCode.put('ü', "..--..");
		LetterToCode.put('ä', ".-.-..");
		LetterToCode.put('ö', "---..");
		LetterToCode.put('ß', "--..--");

		// Seltenere Kleinbuchstaben
		LetterToCode.put('j', ".---..");
		LetterToCode.put('y', "-.--..");
		LetterToCode.put('x', "-..--");
		LetterToCode.put('q', "--.--");

		// Großbuchstaben: einfache Abbildung (Variante der Kleinschreibung)
		LetterToCode.put('A', "----.");
		LetterToCode.put('B', "..-..-");
		LetterToCode.put('C', "..--..");
		LetterToCode.put('D', "-..-.");
		LetterToCode.put('E', "-.-..");
		LetterToCode.put('F', ".-.-.-");
		LetterToCode.put('G', ".--..-");
		LetterToCode.put('H', ".-..-.");
		LetterToCode.put('I', "--..-");
		LetterToCode.put('J', ".---.-");
		LetterToCode.put('K', ".-..--");
		LetterToCode.put('L', "..-.-");
		LetterToCode.put('M', ".-.-..-");
		LetterToCode.put('N', "-.--.");
		LetterToCode.put('O', ".---.-.");
		LetterToCode.put('P', ".--.-");
		LetterToCode.put('Q', "--.--.");
		LetterToCode.put('R', "--.-.");
		LetterToCode.put('S', "...-"); // fehlte klein, jetzt bei Groß
		LetterToCode.put('T', "---.-");
		LetterToCode.put('U', ".--..");
		LetterToCode.put('V', ".---..");
		LetterToCode.put('W', "..--.-");
		LetterToCode.put('X', "-..--.");
		LetterToCode.put('Y', "-.--.-");
		LetterToCode.put('Z', ".----.");

		// Groß-Umlaute
		LetterToCode.put('Ä', ".-.-.-");
		LetterToCode.put('Ö', "---..-");
		LetterToCode.put('Ü', "..--.--");

		// Sonderzeichen (Programmier-Kontext)
		LetterToCode.put('.', ".-.-.-.");
		LetterToCode.put(',', "--..--.");
		LetterToCode.put(';', "-.-.-.");
		LetterToCode.put(':', "---...");
		LetterToCode.put('(', "-.--.-");
		LetterToCode.put(')', "-.--.-.");
		LetterToCode.put('[', "..--...");
		LetterToCode.put(']', "..--....");
		LetterToCode.put('{', ".---...");
		LetterToCode.put('}', ".---....");
		LetterToCode.put('+', ".-.-.");
		LetterToCode.put('-', "-....-");
		LetterToCode.put('*', "-..-..");
		LetterToCode.put('/', "-..-.");
		LetterToCode.put('=', "-...-");
		LetterToCode.put('<', "-.--.");
		LetterToCode.put('>', "-.--..");
		LetterToCode.put('%', "-----.");
		LetterToCode.put('$', "...-..-");
		LetterToCode.put('&', ".-...");
		LetterToCode.put('|', "-.-.-");
		LetterToCode.put('!', "-.-.--");
		LetterToCode.put('?', "..--..");
		LetterToCode.put('#', "....-");
		LetterToCode.put('_', "..--.-");
		LetterToCode.put('^', "....--");
		LetterToCode.put('~', "--..-.");
		LetterToCode.put('\'', ".----.");
		LetterToCode.put('´', ".----..");

		// Leerzeichen
		LetterToCode.put(' ', " ");

		// Umkehrabbildung
		for (Map.Entry<Character, String> entry : LetterToCode.entrySet()) {
			CodeToLetter.put(entry.getValue(), entry.getKey());
		}
	}
	
	public static void printTranslatorTabel() {
	    Map<String, List<Character>> grouped = new TreeMap<>();

	    for (Map.Entry<Character, String> entry : LetterToCode.entrySet()) {
	        grouped.computeIfAbsent(entry.getValue(), k -> new ArrayList<>()).add(entry.getKey());
	    }

	    int groupIndex = 1;
	    for (Map.Entry<String, List<Character>> group : grouped.entrySet()) {
	        System.out.println("// Gruppe " + group.getKey());
	        System.out.print("// " + groupIndex + "  ");
	        for (char c : group.getValue()) {
	            System.out.print(c + " ");
	        }
	        System.out.println("\n");
	        groupIndex++;
	    }
	}


	public static String toCode(String text) {

		StringBuilder sb = new StringBuilder();

		for (char c : text.toCharArray()) {

			if (LetterToCode.containsKey(c)) {

				sb.append(LetterToCode.get(c)).append(" ");

			}

		}

		return sb.toString().trim();

	}

// Code -> Klartext

	public static String fromCode(String morse) {

		StringBuilder sb = new StringBuilder();

		String[] codes = morse.split(" ");

		for (String code : codes) {

			if (CodeToLetter.containsKey(code)) {

				sb.append(CodeToLetter.get(code));

			} else if (code.equals(" ")) {

				sb.append(" ");

			}

		}

		return sb.toString();

	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("🌟 Willkommen beim Lumini-Translator-Game 🌟");

		System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");

		boolean running = true;

		while (running) {

			System.out.println("Menü:");

			System.out.println("Mode:" + mode + " Start:" + start + " Length:" + length + " Inc:" + inc
					+ " ToTextWahrscheinlichkeit:" + toText);

			System.out.println("1 = Text → Code");

			System.out.println("2 = Code → Text");

			System.out.println("3 = Punktestand anzeigen");

			System.out.println("4 = 10er Code Quest");

			System.out.println("5 = 50er Code Quest mit inc");

			System.out.println("6 = Mode wählen, Aufgabengenerierung durch randomTextMode oder selber definiert");

			System.out.println("7 = Start einstellen- Wo die Reihe durchschnittlich beginnt");

			System.out.println("8 = Length einstellen - Wie lang die Reihe ist");

			System.out.println("9 = Inc einstellen - in welchen Schritten die Reihe hochzählt");

			System.out.println("10 = ToText Wahrscheinlichkeit 0 bis 1");
			
			System.out.println("11 = Übersetzungstabelle ausgeben");

			System.out.println("0 = Beenden");

			System.out.print("Wähle: ");

			int choice = scanner.nextInt();

			scanner.nextLine();

			switch (choice) {

			case 1:

				playTextToCode(scanner);

				break;

			case 2:

				playCodeToText(scanner);

				break;

			case 3:

				System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");

				break;

			case 4:

				playLuminiTraining1(scanner);

				break;

			case 5:

				playLuminiTraining2(scanner);

				break;

			case 6:

				mode = scanner.nextInt();

				break;

			case 7:

				start = scanner.nextInt();

				break;

			case 8:

				length = scanner.nextInt();

				break;

			case 9:

				inc = scanner.nextInt();

				break;

			case 10:

				toText = scanner.nextDouble();

				break;
				
			case 11:

				printTranslatorTabel();

				break;

			case 0:

				running = false;

				System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");

				break;

			default:

				System.out.println("Ungültige Auswahl!\n");

			}

		}

		scanner.close();

	}

	static void playTextToCode(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String correctCode = toCode(word);

		System.out.println("Übersetze in Code: " + word);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(correctCode)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + correctCode + "\n");

		}

	}

	static void playCodeToText(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String code = toCode(word);

		System.out.println("Übersetze in Text: " + code);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(word)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");

		}

	}

	static void playLuminiTraining1(Scanner scanner) {

		for (int i = 0; i < 10; i++) {

			if (Math.random() > toText)

				playTextToCode(scanner);

			else

				playCodeToText(scanner);

		}

	}

	static void playLuminiTraining2(Scanner scanner) {

		for (int i = 0; i < 50; i++) {

			start++;

			if (Math.random() > toText)

				playTextToCode(scanner);

			else

				playCodeToText(scanner);

		}

	}

}