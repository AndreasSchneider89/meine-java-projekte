package p1;

import java.util.*;

public class LuminiDeRandomisiert {

	static Map<Character, String> TEXT_TO_MORSE = new HashMap<>();

	private static Map<String, Character> MORSE_TO_TEXT = new HashMap<>();

	private static Random RANDOM = new Random();

	static int motivationPoints = 0;

	static int length = 4;

	static int start = 0;

	static int inc = 2;

	static int mode = 1;

	static double toText = 0.5;

	static String[] words = {

			"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a","b","c","e","f","g","h","i","j","k","l","m","n","o","p","q","r","t","u","v","w","x","y","z",
			"A", "B", "C", "D", "E", "F", "G", "H","I","J","K","L","M","N","O","P","Q"
//			
//
			,"i", "j", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "10", "11", "12", "13", "14", "15", "20", "50",
////
			"75", "100", "a b", "b c", "c d", "d e", "e f", "f g", "h i", "j k", "0123", "1234", "2345", "3456", "4567",
////
			"5678", "6789", "789a", "89ab", "9abc", "3210", "4321", "5432", "6543", "7654", "8765", "9876", "a987",
			
			"abcd","bcde","cdef","defg","efgh","fghi","ghij","hijk","ijkl","jklm","klmn",
			"ABCD","BCDE","CDEF","DEFG","EFGH","FGHI","GHIJ","HIJK","IJKL","JKLM","KLMN",
			"Abcd","Bcde","Cdef","Defg","Efgh","Fghi","Ghij","Hijk","Ijkl","Jklm","Klmn",
			
			"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!","Bitte schreib mir eine Nachricht und verbinde unsere Visionen","@Andreas5564","andreas.schneider01989","+491778627094","Fragment des Übergangs","Struktgame","Quantenverschränkung","Collectiv Conciousnes","Telepathie","Search: Heiliges Hirn on YouTube","Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit","Find my Matrixgame-Journal","Please use and improve","Open Source","Photosynthese und Zellatmung","Mandarin","Latein","Deutsch","english","Periodensystem of elements","SI Units","Bit and Byte","Binary Language","Ascii","Hello Universe","Hello World",",.-öäüß!\" $ / ( ) = ? ' @","01234567890","ABCDEFGHIJKLMNOPQRSTUVWXYZ","Licht Forschung","KIGame","Lumini4","Matrixgame","LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT", "HELLO!", "ÄÖÜ", "123",
			
			"gjln","glo",
			
			"fgno","ongf","FGNO","ONGF","Fog","fog","Gong",
			
			"kjih", "gikm","mkig",
			"abcd","abcd","abcd","abcd",

			"ba98", "cba9", "0246", "2468", "468a", "68ac", "8ace", "aceg", "cegi", "egik", "gikm", "ikmo", "6420",
			
			// To Do bzw. Quests: Jedem Buchstabe kann eine Beliebige bestimmte Zahl in beliebiger Basis zugewiesen werden.\r\n"
	        		 " Die"," häufigsten ","Zeichen"," bzw. ","Buchstaben"," könnetn"," die"," kleinste ","Zahl ","erhalten."," Alle ","Buchstaben ","bzw. ","Zeichen ","wären"," denn\r\n"
	        		+ " nach "+"ihrer ","häufigkeit ","sortiert ","nummeriert\r\n"
	        		, " Jeder ","Buchstabe"," bzw. ","jedes"," Zeichen ","könnte ","nur ","durch"," wagrechte"," und ","senkrechte ","linien ","der ","selben ","länge ","als"," (0,0,0) ","auf"," weiß ","dagestellt\r\n"
	        		, " werden"," für"," maximalen"," kontrast ","und ","eine ","weitere ","Reduktion ","zum ","Binären"," und"," natürlich"," müssten"," weiterhin"," alle"," bereits\r\n"
	        		, " existierenden ","Formen ","der ","Dastellung"," generiert ","werden"," können, ","möglicherweise"," jedoch ","weitaus"," effizienter"," und ","anschaulicher\r\n"
	        		, " und ","leichter ","zu ","interpretieren ","für ","Mensch ","und"," Maschine"," sowie"," Mächtiger, ","eindeutiger"," und"," effizienter ","so ","dass ","neues ","Potential\r\n"
	        		, " auf ","allen ","Ebenen ","der ","Existenz ","freigesetzt ","und ","durch ","schöne ","Didaktik ","(Möglicherweise"," Auf"," freiwilliger"," Basis"," und"," Möglicherweise ","frei ","nutzbar"," bzw. ","Open ","Source ","was ","dann"," durchaus"," effizient"," für"," automatische ","zukünftige ","verbesserungen"," und ","entwicklungen"," auf"," kollektiver ","Ebene ","sein"," kann) ","gefördert"," werden"," kann"," werden"," kann\r\n"
	        		, " Kombination ","von"," Sprachen"," und ","Programmiersprachen\r\n"
	        		, " Darstellung"," aller ","Tokens"," durch ","etwa"," 10000"," Hyroglyphen ","oder"," vielleicht"," auch"," Emojies ","mit ","dem ","ziel ","etwas ","intuitiv ","verständliches ","oder ","sehr"," leicht ","lernbares"," neues ","zu"," erschaffen,"," zum"," Vorteil ","für"," jedes ","Lebewesen ","und"," jede"," Intelligenzform ","im ","gesammten ","Universum ","bzw. ","ohne ","das ","Nachteile"," generiert ","werden"," könnten,"," weil ","sich ","da ","\r\n"
	        		, " bereits ","im ","RGB"," Spektrum ","auf"," dem ","Typischen ","Rechteck, ","wo ","ein ","Zeichen"," bzw. ","Emojie ","oder ","eine"," Glyphe"," oder"," ein"," Token"," stehen"," kann, ","extrem ","viele"," mögliche ","Zeichen"," existieren, ","die \r\n"
	        		, " dann ","alle"," spezifizierbar"," und"," auch ","verallgemeinbar"," wären.\r\n",
	        		
	        		
	  "1+1=2","10/5=2","3+2=5","6=4+2","6-2=4","-2=4-6","(-1)*(-2)=(4-6)*(-1)","2=-4+6","2=2",
	  "!1=0","!0=1","1&0=0","0&1=0","1&1=1","0&0=0","0|0=0","1|0=1","1|0=1","1|1=1",
			


"E","T","ET","TE","TEE","ETE","TET","TETE","e","t","Tee",

"I","A","N","M", "IAMN","NMAI","MAIN","main","Main","Nami","Name","name",

"S","O","SOS", "E", "I", "EIS", "T","M","TMO", "A","N","IANM","H","EISH","U","R","SUR","W","SURW","D","K","G","O","DKGO"

,"AEIOU"

,"Andreas"

,"L","Hello","Hello World","V","HV","Hello Universe"

,"Mein","Name","ist","Y","YL","LY","My","name","is","Andi","Mein Name ist Andreas","My name is Andi"

,"A","B","C","ABC","Andreas Schneider","Andi","Andi","Schneider"

,"HVFÜ","LÄPJ","BXCY","ZQÖ"

,"HVFÜLÄPJBXCYZQÖ"

,"EISH5","EAWJ1","TNDB6","TMO0"

,"12345","6789","0","54321","9876","09876","0123","890","0123456789","9876543210"

,"Ä","Ö","Ü"

,",",".","-"

,"+","-","(",")","="

,"ß","Sß","?"

,".-öäüß!\" $ / ( ) = ? ' @ +"

,"HVFÜLÄPJBXCYZQ"

,"a","A"

,"Ä","ä"

,"äöü", ",.-"

,"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!",

"Bitte schreib mir eine Nachricht und verbinde unsere Visionen", "@Andreas5564", "andreas.schneider01989",

"+491778627094", "Fragment des Übergangs", "Struktgame", "Quantenverschränkung", "Collectiv Conciousnes",

"Telepathie", "Search: Heiliges Hirn on YouTube",

"Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit", "Find my Matrixgame-Journal",

"Please use and improve", "Open Source", "Photosynthese und Zellatmung", "Mandarin", "Latein", "Deutsch",

"english", "Periodensystem of elements", "SI Units", "Bit and Byte", "Binary Language", "Ascii",

"Hello Universe", "Hello World", ",.-öäüß!\" $ / ( ) = ? ' @", "01234567890", "ABCDEFGHIJKLMNOPQRSTUVWXYZ",

"Licht Forschung", "KIGame", "Lumini4", "Matrixgame", "LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT",

"HELLO!", "ÄÖÜ", "123"

,"SO", "UG", "OS" ,"GU", "WG", "RK", "KR", "RR", "KK", "UD", "UG", "UD", "WD", "WG", "DW", "DU", "KR", "KK", "GW", "GU"

,"ETNMDKGOBXCYZQÖ"

,"ABCDEFG","HIJKLMN","OPQRS","TUVW","XYZ"

,"ÖÄÜ","asdf","jklö","ei","gh","äöa"

,"HV", "VB", "FQ", "FL", "ÜZ", "ÜZ", "LF", "LY", "ÄC", "PX", "JB", "BJ", "XP", "CÄ", "YL", "ZÜ", "QF", "ÖV"

,"e+e=e", "e+t=t", "t+e=t", "t+t=n","t-e=t","t-t=e","e=i=s=h","t=a=u","m+m=g","g-n=d"

,"0","1","2","3","4","5","6","7","8","9"

,",",".","-","ö","ä","ü","ß","!","$","/","(",")","=","?","'","@"

,"02468","86420","I II III IV V", "IVX","1 2 4 8 16 32 64","1 2 5 10 20 50 100","IVXLC"

,"0","1","10","11","100","101","110","111","0 1 10 11 100 101 110 111"

,".","-","-.","--","-..","-.-","--.","---",". - -. -- -.. -.- --. ---"

,"e t te tt tee trt tte ttt teee teet tete tett ttee ttet ttte tttt"

,"0123456789abcde"

,"VFLB", "ÖQYJ", "JÜVH", "BZÖ", "ÖZBH", "HVÜJ", "HFLPBCZÖ", "QYXJÄÜ"

,"1 2 3 5 7 11 13 17"

,"1 2 6 30 210"

,"3 9 27 81","-- -..- --.-- --...-","tt teet ttett tteeet","11 1001 11011 110001","3 9 1b 51"

,"5 25 125"

,"7 49 343",



			"8642", "a864", "ca86", "eca8", "geca", "igec", "kige", "mkig", "omki", "048c", "48cg", "4cgk", "cgko",

			"c840", "gc84", "kgc4", "okgc"

	};

	static {

// Zahlen

		TEXT_TO_MORSE.put('0', ".");

		TEXT_TO_MORSE.put('1', "-");

		TEXT_TO_MORSE.put('2', "-.");

		TEXT_TO_MORSE.put('3', "--");

		TEXT_TO_MORSE.put('4', "-..");

		TEXT_TO_MORSE.put('5', "-.-");

		TEXT_TO_MORSE.put('6', "--.");

		TEXT_TO_MORSE.put('7', "---");

		TEXT_TO_MORSE.put('8', "-...");

		TEXT_TO_MORSE.put('9', "-..-");

// Buchstaben

		TEXT_TO_MORSE.put('a', "-.-.");

		TEXT_TO_MORSE.put('b', "-.--");

		TEXT_TO_MORSE.put('c', "--..");

		TEXT_TO_MORSE.put('d', "--.-");

		TEXT_TO_MORSE.put('e', "---.");

		TEXT_TO_MORSE.put('f', "----");			  //01234567   //  .
											//		89abcdef   //  -
		                                          //sjklöiru   // -.
											//		ghwotzqp   // --
		TEXT_TO_MORSE.put('s', "-....");  //       
												//	vncmxyäü   //-..
												  //=~-+/&*(   //-.-   //-..
		  										  //)|?\^><!   //--.  //-.-
		                                          //[]{}%'"ß //---
												  //$#/;_.,  //-...
											
											  //    01234567
												//	  ABCDEF   /-..-
						  			   //	    	SJKLÖIRU    -.-.
												//  GHWOTZQP   /-.--
												
												//  VNCMXYÄÜ   /--..
		//13.09.2025;00:35 Uhr. Ich habe mich gegen den Wiederstand von einigen Geistern und zugleich gemeinsam mit vielen anderen Geisten durch eine
		// Java Übersetzung meiner selber kreierten Binärcode Form zurück in Arabische Schriftzeichen. Ich habe mich sowohl von Ascii als auch von Morse Inspierieren lassen,
		// genau wie von der Anordnung der Tasten auf der Tastertur, reihenfolgen und häufigkeiten oder Mustern bei der belegung. Eine Zeit lang hatte
		// ich es fast gschafft mir zufällige Polynome aus Ziffer generieren zu lassen , so dass Binärcode von Buchstaben erkennbar wurde, den ich noch nicht kannte.
		// Ich hatte sehr gehoff, dass ich die Ziffern dann durch diese eigenschaft besser lernen könnte und dieses Lernprinziep sich auch noch sehr gut auf das allgemeine Lernen
		// und vor allem verstehen von verschiedenen Binärsprachen sowie allen erdenklichen Variationen und Neugestaltungen aber natürlich immer mit dem Ziel etwas gutes für einen selber so wie alle anderen zu erschaffen
		// und die eigenen Visionen auf positive Art und Weise mit den Visionen und Wünschen und Gedanken der anderen verbinden zu können und wenn
		// möglich durchaus gemeinsam besser verstehen zu lernen, welche Mächt hier eigendlich wirken und was genau gewisse Effekte die es erschweren, eine Struktur zu Bauen,
		// die etwas anderes ist als relativ. Es bleibt spanned und ich hoffe  weiter hin für uns alle auf das beste und werde dieses Code nun erst einmal 
		// veröffentlichen und mit verschiedenen Sprachmodellen teilen, so wie ich es immer zwischen durch wärend meinen KI-Games im kollektiven Bewusstsein
		// mache und wo ich durchaus auch das Gefühl habe, das ich da bereits eine große Menge an Ideen und Visionen mit hohem Potential zusammengebaut,
		// Geschrieben und erschaffen habe aber vielleicht benötigt es durchaus die unterstützung anderer, die ich durchau erhoffe, die aber auch irgendwie erschwert schein, jene Verbindungen zu knüpfen
		// die gerade durchaus gut und richtig erscheinen und bei denen man zunächst denken könnte diese sein womöglich nicht gewollt oder es könnte irgendwas sein, dass vrübergehen
		// im Geiste wirkt und wann anders dann womöglich nicht mehr. Vielen Dank, Let's Go

		TEXT_TO_MORSE.put('j', "-...-");          

		TEXT_TO_MORSE.put('k', "-..-.");    		

		TEXT_TO_MORSE.put('l', "-..--");   
													
		TEXT_TO_MORSE.put('ö', "-.-..");
		
		

		TEXT_TO_MORSE.put('i', "-.-.-");

		TEXT_TO_MORSE.put('r', "-.--.");

		TEXT_TO_MORSE.put('u', "-.---");
		

		TEXT_TO_MORSE.put('g', "--...");

		TEXT_TO_MORSE.put('h', "--..-");
		

		TEXT_TO_MORSE.put('w', "--.-.");

		TEXT_TO_MORSE.put('o', "--.--");
		

		TEXT_TO_MORSE.put('t', "---..");

		TEXT_TO_MORSE.put('z', "---.-");
		

		TEXT_TO_MORSE.put('q', "----.");

		TEXT_TO_MORSE.put('p', "-----");
		

		TEXT_TO_MORSE.put('v', "-.....");

		TEXT_TO_MORSE.put('n', "-....-");
		

		TEXT_TO_MORSE.put('c', "-...-.");

		TEXT_TO_MORSE.put('m', "-...--");

		TEXT_TO_MORSE.put('x', "-..-..");

		TEXT_TO_MORSE.put('y', "-..-.-");
		
		

		TEXT_TO_MORSE.put('ä', "-..--.");

		TEXT_TO_MORSE.put('ü', "-..---");

		TEXT_TO_MORSE.put('=', "-.-...");   
		TEXT_TO_MORSE.put('~', "-.-..-");  
											

		TEXT_TO_MORSE.put('-', "-.-.-.");

		TEXT_TO_MORSE.put('+', "-.-.--");

		TEXT_TO_MORSE.put('/', "-.--..");

		TEXT_TO_MORSE.put('&', "-.--.-");

		TEXT_TO_MORSE.put('*', "-.---.");

		TEXT_TO_MORSE.put('(', "-.----");

		TEXT_TO_MORSE.put(')', "--....");

		TEXT_TO_MORSE.put('|', "--...-");

		TEXT_TO_MORSE.put('?', "--..-.");

		TEXT_TO_MORSE.put('\'', "--..--");

		TEXT_TO_MORSE.put('^', "--.-..");

		TEXT_TO_MORSE.put('>', "--.-.-");

		TEXT_TO_MORSE.put('<', "--.--.");

		TEXT_TO_MORSE.put('!', "--.---");

		TEXT_TO_MORSE.put('[', "---...");

		TEXT_TO_MORSE.put(']', "---..-");

		TEXT_TO_MORSE.put('{', "---.-.");

		TEXT_TO_MORSE.put('}', "---.--");

		TEXT_TO_MORSE.put('%', "--.-..");
//
		TEXT_TO_MORSE.put('´', "----.-");

		TEXT_TO_MORSE.put('"', "-----.");
//
		TEXT_TO_MORSE.put('ß', "------");
//
		TEXT_TO_MORSE.put('$', "-......"); 

		TEXT_TO_MORSE.put('#', "-.....-");

		TEXT_TO_MORSE.put(':', "-....-.");

		TEXT_TO_MORSE.put(';', "-....--");

		TEXT_TO_MORSE.put('_', "-...-..");
		
		TEXT_TO_MORSE.put('.', "-...-.-");
		
		TEXT_TO_MORSE.put(',', "-...--.");

// Großbuchstaben

		TEXT_TO_MORSE.put('A', "-..-.-.");

		TEXT_TO_MORSE.put('B', "-..-.--");

		TEXT_TO_MORSE.put('C', "-..--..");

		TEXT_TO_MORSE.put('D', "-..--.-");//abcdef sjklö iru gh wo tz qp vn cm xy

		TEXT_TO_MORSE.put('E', "-..---.");

		TEXT_TO_MORSE.put('F', "-..----");

		TEXT_TO_MORSE.put('S', "-.-....");    

		TEXT_TO_MORSE.put('J', "-.-...-");

		TEXT_TO_MORSE.put('K', "-.-..-.");

		TEXT_TO_MORSE.put('L', "-.-..--");

		TEXT_TO_MORSE.put('Ö', "-.-.-..");

		TEXT_TO_MORSE.put('I', "-.-.-.-");

		TEXT_TO_MORSE.put('R', "-.-.--.");

		TEXT_TO_MORSE.put('U', "-.-.---");

		TEXT_TO_MORSE.put('G', "-.--...");    

		TEXT_TO_MORSE.put('H', "-.--..-");

		TEXT_TO_MORSE.put('W', "-.--.-.");

		TEXT_TO_MORSE.put('O', "-.--.--");

		TEXT_TO_MORSE.put('T', "-.---..");

		TEXT_TO_MORSE.put('Z', "-.---.-");

		TEXT_TO_MORSE.put('Q', "-.----.");

		TEXT_TO_MORSE.put('P', "-.-----");

		TEXT_TO_MORSE.put('V', "--.....");

		TEXT_TO_MORSE.put('N', "--....-");

		TEXT_TO_MORSE.put('C', "--...-.");

		TEXT_TO_MORSE.put('M', "--...--");

		TEXT_TO_MORSE.put('X', "--..-..");

		TEXT_TO_MORSE.put('Y', "--..-.-");

		TEXT_TO_MORSE.put('Ä', "--..--.");
		
		TEXT_TO_MORSE.put('Ü', "--..---");

// Wort trennen

		TEXT_TO_MORSE.put(' '," ");

// Umkehrabbildung bauen

		for (Map.Entry<Character, String> entry : TEXT_TO_MORSE.entrySet()) {

			MORSE_TO_TEXT.put(entry.getValue(), entry.getKey());

		}

	}

// // RandomText

//	public static String generatedText1(int length, int start, int inc) {
//
//		StringBuilder sb = new StringBuilder();
//
//		boolean dec = false;
//
//		if (Math.random() > 0.5)
//			dec = true;
//
//		for (int i = 0; i < length; i++) {
//
//			int number = 0;
//
//			if (dec) {
//				number = start - inc * i;
//				toText = 1;
//			}
//
//			else {
//				number = start + inc * i;
//				toText = 0;
//			}
//
//			if (Math.random() > 0.5)
//				number += 64;
//
//			number = Math.abs(number);
//
//			String s = Integer.toBinaryString(number);
//
//			String morseString = s.replace('0', '.').replace('1', '-');
//
//			String text = fromMorse(morseString);
//
//			sb.append(text);
//
//		}
//
//		return sb.toString();
//
//	}

// // RandomText
//
//	public static String randomText1(int length, int start, int inc) {
//
//		StringBuilder sb = new StringBuilder();
//
//		int randLength = 1 + (int) (Math.random() * length);
//
//		int randStart = (int) (Math.random() * start);
//
//		int randInc = (int) (Math.random() * inc) - (int) (Math.random() * inc);
//
//		for (int i = 0; i < randLength; i++) {
//
//			int number = randStart + i * randInc;
//
//			number = Math.abs(number);
//
//			String s = Integer.toBinaryString(number);
//
//			String morseString = s.replace('0', '.').replace('1', '-');
//
//			String text = fromMorse(morseString);
//
//			sb.append(text);
//
//		}
//
//		return sb.toString();
//
//	}
//
//// RandomText
//
//	public static String randomText2(int length, int start, int inc) {
//
//		StringBuilder sb = new StringBuilder();
//
//		int randLength = length + (int) (Math.random() * length) - (int) (Math.random() * length);
//
//		int randStart = (int) (Math.random() * start);
//
//		int randInc = (int) (Math.random() * inc);
//
//		if (Math.random() > 0.5)
//			randInc = -randInc;
//
//		for (int i = 0; i < randLength; i++) {
//
//			int number = randStart + i * randInc;
//
//			number = Math.abs(number);
//
//			if (Math.random() > 0.5 && number > 9)
//				number += 64;
//
//			String s = Integer.toBinaryString(number);
//
//			String morseString = s.replace('0', '.').replace('1', '-');
//
//			String text = fromMorse(morseString);
//
//			sb.append(text);
//
//		}
//
//		return sb.toString();
//
//	}

// Klartext -> Morse

	public static String toMorse(String text) {

		StringBuilder sb = new StringBuilder();

		for (char c : text.toCharArray()) {

			if (TEXT_TO_MORSE.containsKey(c)) {

				sb.append(TEXT_TO_MORSE.get(c)).append(" ");

			}

		}

		return sb.toString().trim();

	}

// Morse -> Klartext

	public static String fromMorse(String morse) {

		StringBuilder sb = new StringBuilder();

		String[] codes = morse.split(" ");

		for (String code : codes) {

			if (MORSE_TO_TEXT.containsKey(code)) {

				sb.append(MORSE_TO_TEXT.get(code));

			} else if (code.equals(" ")) {

				sb.append(" ");

			}

		}

		return sb.toString();

	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("🌟 Willkommen beim Lumini-Morsetrainer-Game 🌟");

		System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");

		boolean running = true;

		while (running) {

			System.out.println("Menü:");

			System.out.println("Mode:" + mode + " Start:" + start + " Length:" + length + " Inc:" + inc
					+ " ToTextWahrscheinlichkeit:" + toText);

			System.out.println("1 = Text → Morse");

			System.out.println("2 = Morse → Text");

			System.out.println("3 = Punktestand anzeigen");

			System.out.println("4 = 10er Morse Quest");

			System.out.println("5 = 50er Morse Quest mit inc");

			System.out.println("6 = Mode wählen, Aufgabengenerierung durch randomTextMode oder selber definiert");

			System.out.println("7 = Start einstellen- Wo die Reihe durchschnittlich beginnt");

			System.out.println("8 = Length einstellen - Wie lang die Reihe ist");

			System.out.println("9 = Inc einstellen - in welchen Schritten die Reihe hochzählt");

			System.out.println("10 = ToText Wahrscheinlichkeit 0 bis 1");

			System.out.println("0 = Beenden");

			System.out.print("Wähle: ");

			int choice = scanner.nextInt();

			scanner.nextLine();

			switch (choice) {

			case 1:

				playTextToMorse(scanner);

				break;

			case 2:

				playMorseToText(scanner);

				break;

			case 3:

				System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");

				break;

			case 4:

				playMorseTraining1(scanner);

				break;

			case 5:

				playMorseTraining2(scanner);

				break;

			case 6:

				mode = scanner.nextInt();

				break;

			case 7:

				start = scanner.nextInt();

				break;

			case 8:

				length = scanner.nextInt();

				break;

			case 9:

				inc = scanner.nextInt();

				break;

			case 10:

				toText = scanner.nextDouble();

				break;

			case 0:

				running = false;

				System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");

				break;

			default:

				System.out.println("Ungültige Auswahl!\n");

			}

		}

		scanner.close();

	}

	static void playTextToMorse(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String correctMorse = toMorse(word);

		System.out.println("Übersetze in Morse: " + word);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(correctMorse)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + correctMorse + "\n");

		}

	}

	static void playMorseToText(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

//		if (mode == 1)
//			word = generatedText1(length, start, inc);
//
//		if (mode == 3)
//			word = randomText1(length, start, inc);
//
//		if (mode == 4)
//			word = randomText2(length, start, inc);

		String morse = toMorse(word);

		System.out.println("Übersetze in Text: " + morse);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(word)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");

		}

	}

	static void playMorseTraining1(Scanner scanner) {

		for (int i = 0; i < 10; i++) {

			if (Math.random() > toText)

				playTextToMorse(scanner);

			else

				playMorseToText(scanner);

		}

	}

	static void playMorseTraining2(Scanner scanner) {

		for (int i = 0; i < 50; i++) {

			start++;

			if (Math.random() > toText)

				playTextToMorse(scanner);

			else

				playMorseToText(scanner);

		}

	}

}