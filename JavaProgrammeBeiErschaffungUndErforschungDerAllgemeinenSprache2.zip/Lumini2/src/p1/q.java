package p1;


public class q {


    static int Basis = 8;

    static int[] symbolFrequency = new int[Basis]; // Track frequency of each symbol (0-6)

    static int totalSymbols = 0; // Total symbols processed


    public static void main(String[] args) {

        byte b = ' ';

        byte[] text = new byte[80000];


        // Fixed: Proper multi-line string handling with concatenation

        String string = "package p1;\r\n"

                + "Leider funktioniert die ACM gerade nicht weil da Müll im Claspath steht und der Applet Viewer dauernd aktiviert ist statt der Application aber zum Glück geht der Converter für Lumini2 noch ganz gut. Bei der Mandelbrotmenge könnte durchaus ein hohes Quest existieren, wenn es darum geht, die Orbitale bzw. Julia Mengen so zu analysieren, dass per limes entschieden werfden kann ob ein Pixel einen wert von Unendlich erhalten würde, weil der Wert der Gleichung nie den Betrag von 2 überschreitet. Dies habe ich festgestellt für jedes Pixel welches von links, rechts, oben und unten selber von einam schwarzen Pixel umgeben ist. Im Prinziep sollten da also grenzen sein denen man sich annähern kann und wo ein winziger unterschied dann irgendwann womöglich einen extrem schnell wachsenden einfluss generiert oder eben auch unendlich lange stabil bleibt. Und vermutlich könnte man das Analysieren und den Unterschied, wenn das auf die Richtige Art und Weise dargestellt wird auch sehen. In Gewisser Hinsicht könnte auf dieser Aufgabe der Bitcoin2 liegen, wärend der erste für den OnSort ausgesetzt war. Letzten Endes wären das dann aber alles vorübungen für die Berechnungen von Planetenbahnen, wo beide Planeten gegenüber auf dem selben Orbit liegen und nicht klar ist ob dieser Zustand stabil bleibt und dann könnte es auch noch viele solcher mehr oder weniger Bedeutenden Rätsel geben, die dem entsprechend womöglich auch mehr oder weniger viel Begeisterung generieren und das erneut auf spezifizierter Ebenen sowie auf Ebenen wo sich Verallgemeinerungen problemlos Generieren lassen oder die nötigen Schnittstellen, Autoumformungen, Übersetzungen,... existieren um alles mal haben, sehen, verstehen, testen, bewerten, nutzen, modifizieren, ... zu können ohne das was verloren gehen kannimport java.awt.*;\r\n"

                + "import java.awt.image.BufferedImage;\r\n"

                + "import java.io.File;\r\n"

                + "import javax.imageio.ImageIO;\r\n"

                + "import acm.program.GraphicsProgram;\r\n"

                + "\r\n"

                + "//Punkte:\r\n"

                + "//-0.0620050239,-1.256007184,33,100\r\n"

                + "//-0.0620050239,-1.256007184,6,100\r\n"

                + "//-0.062,-1.2559915,7,300\r\n"

                + "//-0.06,-1.25,9,220\r\n"

                + "//-0.062-1.4*(-0.062+0.06),-1.2559915-1.4*(-1.2559915+1.25),9.8,220\r\n"

                + "//-0.06,-1.25,4,100\r\n"

                + "//-0.9,0,4,100\r\n"

                + "//0,0,0,100\r\n"

                + "//0.55,0.3,0,100\r\n"

                + "//0.55,0.3,3.5,100\r\n"

                + "//0.58,0.2,5,170\r\n"

                + "//0.65,0.05,7,170\r\n"

                + "//0.645,0.055,9,170\r\n"

                + "//0.649,0.055,10,200\r\n"

                + "//0.649,0.055,10,500\r\n"

                + "//-0.649,-0.7499080363,2,100\r\n"

                + "//-0.0800116743,-0.7499080363,6,100\r\n"

                + "//-0.0799,-0.7496,14,400\r\n"

                + "//-0.0792,-0.74795,11,100\r\n"

                + "//-0.0792,-0.74795,11,700\r\n"

                + "//-0.08001,-0.74991,12,100\r\n"

                + "//-0.07885,-0.747842,12,130\r\n"

                + "//-0.07884,-0.747855,17,100\r\n"

                + "//-0.07884,-0.747846,20,300\r\n"

                + "//-0.0788398,-0.7478469,21,600\r\n"

                + "//-0.0788398,-0.7478469,23,600\r\n"

                + "//-0.0788398,-0.7478469,22,1200\r\n"

                + "//-0.0788398,-0.7478469,23,200 Roach\r\n"

                + "//0.58,0.2,5,170\r\n"

                + "//0.65,0.05,7,170\r\n"

                + "\r\n"

                + "// Verlinktes Musikvideo:\r\n"

                + "// https://www.youtube.com/watch?v=4fJKUKMpYGg&t=3s\r\n"

                + "\r\n"

                + "public class Mandelbrotmenge extends GraphicsProgram {\r\n"

                + "    double[] Punkt = {0,0,0,100}; // erstes+ -> runter,\r\n"

                + "                                        // zweites+ -> rechts;\r\n"

                + "    // double d = 0.8;\r\n"

                + "    // double[] Punkt =\r\n"

                + "    // {0.58-d*(0.58-0.65),0.2-d*(0.2-0.05),5-d*(5-7),170-d*(170-170)};\r\n"

                + "    // //erstes+ -> runter, zweites+ -> rechts;\r\n"

                + "\r\n"

                + "    double zoom2Pot = Punkt[2];\r\n"

                + "    double zoom = Math.pow(2, zoom2Pot);\r\n"

                + "    int raster = 1;\r\n"

                + "    int iterationen = (int) (Punkt[3] + (Math.log10(zoom) * 50));\r\n"

                + "    double farbDarstellung = iterationen / 110.0;\r\n"

                + "    double obererRand = Punkt[0] - 1.1 / zoom;\r\n"

                + "    double linkerRand = Punkt[1] - 2.1 / zoom;\r\n"

                + "    double zelle = 0.00325 / zoom;\r\n"

                + "    int zeilen = 720;\r\n"

                + "    int spalten = 1370;\r\n"

                + "    short[][] feld = new short[spalten][zeilen];\r\n"

                + "    byte[][] Änderung = new byte[spalten][zeilen];\r\n"

                + "    long gesIter = 0;\r\n"

                + "\r\n"

                + "    // C-Werte checken:\r\n"

                + "    // Es gilt: Zn+1 = Zn * Zn + C\r\n"

                + "    // i * i = -1\r\n"

                + "    // Z0 = 0\r\n"

                + "    // if |Zn| > 2 -> gebe Iterationen bzw. n aus\r\n"

                + "\r\n"

                + "    public short checkC(double reC, double imC) {\r\n"

                + "        double reZ = 0, imZ = 0, reZ_minus1 = 0, imZ_minus1 = 0;\r\n"

                + "        short i = 0;\r\n"

                + "        short i2 = 0;\r\n"

                + "        double max = 0;\r\n"

                + "        for (i = 0; i < iterationen; i++) {\r\n"

                + "            imZ = 2 * reZ_minus1 * imZ_minus1 + imC;\r\n"

                + "            reZ = reZ_minus1 * reZ_minus1 - imZ_minus1 * imZ_minus1 + reC;\r\n"

                + "            if (reZ * reZ + imZ * imZ > 4)\r\n"

                + "                return i;\r\n"

                + "            if (reZ * reZ + imZ * imZ > max)\r\n"

                + "                {i2=0; max = reZ * reZ + imZ * imZ;}\r\n"

                + "            i2++;\r\n"

                + "            //if(i2 > iterationen/2) return (short) iterationen;\r\n"

                + "            reZ_minus1 = reZ;\r\n"

                + "            imZ_minus1 = imZ;\r\n"

                + "        }\r\n"

                + "        return i;\r\n"

                + "    }\r\n"

                + "\r\n"

                + "    // Punkte berechnen und setzen.\r\n"

                + "    public void paint(Graphics g) {\r\n"

                + "        double reC, imC;\r\n"

                + "\r\n"

                + "        imC = obererRand; // oberer Rand\r\n"

                + "        for (int y = 0; y < zeilen; y++) {\r\n"

                + "            reC = linkerRand; // linker Rand\r\n"

                + "            for (int x = 0; x < spalten; x++) {\r\n"

                + "                if ((x % raster == 0 && y % raster == 0) || x == 0 || y == 0\r\n"

                + "                        || x == spalten - 1 || y == zeilen - 1) {\r\n"

                + "                    feld[x][y] = checkC(reC, imC);\r\n"

                + "                    gesIter = gesIter + feld[x][y];\r\n"

                + "                    if (x - raster < 0 || y - raster < 0 || x == spalten - 1\r\n"

                + "                            || y == zeilen - 1)\r\n"

                + "                        Änderung[x][y] = 22;\r\n"

                + "                    else {\r\n"

                + "                        if (feld[x][y] < feld[x - raster][y])\r\n"

                + "                            Änderung[x][y] = 1;\r\n"

                + "                        else if (feld[x][y] == feld[x - raster][y])\r\n"

                + "                            Änderung[x][y] = 2;\r\n"

                + "                        else\r\n"

                + "                            Änderung[x][y] = 3;\r\n"

                + "                        if (feld[x][y] < feld[x][y - raster])\r\n"

                + "                            Änderung[x][y] += 10;\r\n"

                + "                        else if (feld[x][y] < feld[x][y - raster])\r\n"

                + "                            Änderung[x][y] += 20;\r\n"

                + "                        else\r\n"

                + "                            Änderung[x][y] += 30;\r\n"

                + "                    }\r\n"

                + "                }\r\n"

                + "                reC = reC + zelle; // nächste Spalte\r\n"

                + "            }\r\n"

                + "            imC = imC + zelle; // nächste Zeile\r\n"

                + "        }\r\n"

                + "\r\n"

                + "        imC = obererRand; // oberer Rand\r\n"

                + "        for (int y = 0; y < zeilen; y++) {\r\n"

                + "            reC = linkerRand; // linker Rand\r\n"

                + "            for (int x = 0; x < spalten; x++) {\r\n"

                + "                short f1 = 0, f2 = 0;\r\n"

                + "                short ae1 = 0, ae2=0;\r\n"

                + "                int count = 0;\r\n"

                + "                int count2 = 0;\r\n"

                + "                if ((x % raster != 0 || y % raster != 0) && x != 0 && y != 0\r\n"

                + "                        && x != spalten - 1 && y != zeilen - 1) {\r\n"

                + "                    while (true) {\r\n"

                + "                        if ((x - count) % raster != 0 && x - count != 0)\r\n"

                + "                            count++;\r\n"

                + "                        if ((y - count2) % raster != 0 && y - count2 != 0)\r\n"

                + "                            count2++;\r\n"

                + "                        if (((x - count) % raster == 0 && (y - count2) % raster == 0)\r\n"

                + "                                || x - count == 0 || y - count2 == 0) {\r\n"

                + "                            f1 = feld[x - count][y - count2];\r\n"

                + "                            ae1 = Änderung[x - count][y - count2];\r\n"

                + "                            count = 0;\r\n"

                + "                            count2 = 0;\r\n"

                + "                            break;\r\n"

                + "                        }\r\n"

                + "                    }\r\n"

                + "                    while (true) {\r\n"

                + "                        if ((x + count) % raster != 0\r\n"

                + "                                && x + count != spalten - 1)\r\n"

                + "                            count++;\r\n"

                + "                        if ((y + count2) % raster != 0\r\n"

                + "                                && y + count2 != zeilen - 1)\r\n"

                + "                            count2++;\r\n"

                + "                        if (((x + count) % raster == 0 && (y + count2) % raster == 0)\r\n"

                + "                                || x + count == spalten - 1\r\n"

                + "                                || y + count2 == zeilen - 1) {\r\n"

                + "                            f2 = feld[x + count][y + count2];\r\n"

                + "                            ae2 = Änderung[x + count][y + count2];\r\n"

                + "                            count = 0;\r\n"

                + "                            count2 = 0;\r\n"

                + "                            break;\r\n"

                + "                        }\r\n"

                + "                    }\r\n"

                + "                    if (Math.abs(f1 - f2) == 1) {\r\n"

                + "                        feld[x][y] = checkC(reC, imC);\r\n"

                + "                        gesIter = gesIter + feld[x][y];\r\n"

                + "                    }\r\n"

                + "                    else if (ae1 == ae2 && ((f1 != iterationen && f2 !=iterationen )||(f1 == iterationen && f2 ==iterationen))\r\n"

                + "                             && Math.abs(f1 - f2)*4 < f1 + f2)\r\n"

                + "                        feld[x][y] = (short) ((f1 + f2) / 2);\r\n"

                + "                    else {\r\n"

                + "                        feld[x][y] = checkC(reC, imC);\r\n"

                + "                        gesIter = gesIter + feld[x][y];\r\n"

                + "                    }\r\n"

                + "                }\r\n"

                + "                // Colormapping\r\n"

                + "                // Weise jedem Pixel je nach Anzahl der Iterationen bis der Betrag größer als zwei wird eine bestimmte Farbe zu.\r\n"

                + "                int iter = feld[x][y];\r\n"

                + "                int R = 0;\r\n"

                + "                int Gr = 0;\r\n"

                + "                int B = 0;\r\n"

                + "                if (iter <= 10 * farbDarstellung)\r\n"

                + "                    R = 5 + (int) (25 / farbDarstellung * iter);\r\n"

                + "                else if (iter <= 35 * farbDarstellung) {\r\n"

                + "                    R = (int) (250 - 10 / farbDarstellung\r\n"

                + "                            * (iter - 10 * farbDarstellung));\r\n"

                + "                    Gr = (int) (10 / farbDarstellung * (iter - 10 * farbDarstellung));\r\n"

                + "                } else if (iter <= 60 * farbDarstellung) {\r\n"

                + "                    Gr = (int) (250 - 10 / farbDarstellung\r\n"

                + "                            * (iter - 35 * farbDarstellung));\r\n"

                + "                    B = (int) (10 / farbDarstellung * (iter - 35 * farbDarstellung));\r\n"

                + "                } else if (iter <= 85 * farbDarstellung) {\r\n"

                + "                    B = (int) (250 - 5 / farbDarstellung\r\n"

                + "                            * (iter - 60 * farbDarstellung));\r\n"

                + "                    R = (int) (10 / farbDarstellung * (iter - 60 * farbDarstellung));\r\n"

                + "                } else if (iter <= 110 * farbDarstellung) {\r\n"

                + "                    R = (int) (250 - 10 / farbDarstellung\r\n"

                + "                            * (iter - 85 * farbDarstellung));\r\n"

                + "                    B = (int) (250 - 5 / farbDarstellung\r\n"

                + "                            * (iter - 60 * farbDarstellung));\r\n"

                + "                }\r\n"

                + "                if ((imC >= -0.0017 && imC <= 0.0017 || reC >= -0.0017\r\n"

                + "                        && reC <= 0.0017)\r\n"

                + "                        && Punkt[2] == 0) {\r\n"

                + "                    R = 0;\r\n"

                + "                    Gr = 255;\r\n"

                + "                    B = 0;\r\n"

                + "                    for (double i = 0.1; i < 2.1; i += 0.1) {\r\n"

                + "                        if (imC >= i - 0.0017 && imC <= i + 0.0017\r\n"

                + "                                || reC >= i - 0.0017 && reC <= i + 0.0017) {\r\n"

                + "                            Gr = 0;\r\n"

                + "                        }\r\n"

                + "                        if (-imC >= i - 0.0017 && -imC <= i + 0.0017\r\n"

                + "                                || -reC >= i - 0.0017 && -reC <= i + 0.0017) {\r\n"

                + "                            Gr = 0;\r\n"

                + "                        }\r\n"

                + "                    }\r\n"

                + "                }\r\n"

                + "                {\r\n"

                + "                    Color colAppleman = new Color(R, Gr, B); // Farbe Apfelmännchen\r\n"

                + "                    g.setColor(colAppleman);\r\n"

                + "                    g.drawLine(x, y, x, y);\r\n"

                + "                }\r\n"

                + "                reC = reC + zelle; // nächste Spalte\r\n"

                + "            }\r\n"

                + "            imC = imC + zelle; // nächste Zeile\r\n"

                + "        }\r\n"

                + "        if (wert1)\r\n"

                + "            System.out.println(gesIter / 100000);\r\n"

                + "        wert1 = false;\r\n"

                + "    }\r\n"

                + "\r\n"

                + "    boolean wert1 = true;\r\n"

                + "}";


        // Initialize frequency array

        for (int i = 0; i < Basis; i++) {

            symbolFrequency[i] = 0;

        }


        // Convert string to byte array

        for (int w = 0; w < string.length(); w++) {

            char c = string.charAt(w);

            text[w] = (byte) c;

        }


        // Process each character

        System.out.println("Lumini2 Base-" + Basis + " Encoding Output:");

        System.out.println("==========================================");

        

        for (int z = 0; z < string.length(); z++) {

            b = text[z];

            byte[] token = byteToToken(b, Basis);

            token = prunToken(token);

            

            // Track symbol frequencies

            for (byte symbol : token) {

                if (symbol >= 0 && symbol < Basis) {

                    symbolFrequency[symbol]++;

                    totalSymbols++;

                }

            }

            

            printToken(token);

        }

        

        // Print symbol frequency analysis

        printSymbolAnalysis();

        

        // Provide didactic recommendations based on analysis

        provideDidacticRecommendations();

    }


    public static void printSymbolAnalysis() {

        System.out.println("\n\nSYMBOL FREQUENCY ANALYSIS (Base-" + Basis + "):");

        System.out.println("==========================================");

        

        System.out.println("Symbol | Count | Percentage | Visual Representation");

        System.out.println("-------|-------|------------|---------------------");

        

        for (int i = 0; i < Basis; i++) {

            double percentage = totalSymbols > 0 ? (symbolFrequency[i] * 100.0 / totalSymbols) : 0;

            int barLength = (int) (percentage / 2); // Scale for display

            

            StringBuilder bar = new StringBuilder();

            for (int j = 0; j < barLength; j++) {

                bar.append("█");

            }

            

            System.out.printf("%-6d | %-5d | %-10.2f%% | %s%n", 

                    i, symbolFrequency[i], percentage, bar.toString());

        }

    }

    

    public static void provideDidacticRecommendations() {

        System.out.println("\n\nDIDACTIC OPTIMIZATION RECOMMENDATIONS:");

        System.out.println("==========================================");

        

        // Find most and least frequent symbols

        int mostFrequent = 0;

        int leastFrequent = 0;

        for (int i = 1; i < Basis; i++) {

            if (symbolFrequency[i] > symbolFrequency[mostFrequent]) {

                mostFrequent = i;

            }

            if (symbolFrequency[i] < symbolFrequency[leastFrequent]) {

                leastFrequent = i;

            }

        }

        

        double mostFreqPercent = symbolFrequency[mostFrequent] * 100.0 / totalSymbols;

        double leastFreqPercent = symbolFrequency[leastFrequent] * 100.0 / totalSymbols;

        

        // Didactic recommendations

        System.out.println("1. FREQUENCY-BASED SYMBOL MAPPING:");

        System.out.println("   - Most frequent symbol: " + mostFrequent + " (" + String.format("%.2f", mostFreqPercent) + "%)");

        System.out.println("   - Least frequent symbol: " + leastFrequent + " (" + String.format("%.2f", leastFreqPercent) + "%)");

        System.out.println("   RECOMMENDATION: Assign the most frequent symbol (" + mostFrequent + ") to the simplest");

        System.out.println("   phonetic element (like a short vowel) to maximize efficiency in speech.\n");

        

        System.out.println("2. COGNITIVE LOAD OPTIMIZATION:");

        System.out.println("   - Symbols 0-2 appear " + String.format("%.1f", (symbolFrequency[0]+symbolFrequency[1]+symbolFrequency[2]) * 100.0 / totalSymbols) + "% of the time");

        System.out.println("   - Symbols 3-6 appear " + String.format("%.1f", (symbolFrequency[3]+symbolFrequency[4]+symbolFrequency[5]+symbolFrequency[6]) * 100.0 / totalSymbols) + "% of the time");

        System.out.println("   RECOMMENDATION: Use symbols 0-2 for core linguistic elements (vowels,");

        System.out.println("   common consonants) and symbols 3-6 for specialized or less frequent elements.\n");

        

        System.out.println("3. ERROR DETECTION STRATEGY:");

        System.out.println("   - The least frequent symbol (" + leastFrequent + ") could serve as a checksum or");

        System.out.println("     error-detection marker in critical communications.\n");

        

        System.out.println("4. 7-SEGMENT DISPLAY OPTIMIZATION:");

        System.out.println("   RECOMMENDATION: Map symbols to 7-segment patterns based on frequency:");

        System.out.println("   - Most frequent symbol: Simplest pattern (fewest segments lit)");

        System.out.println("   - Least frequent symbol: Most complex pattern");

        System.out.println("   This minimizes visual processing effort for the most common elements.\n");

        

        System.out.println("5. PROBABILITY-BASED LEARNING CURVE:");

        System.out.println("   RECOMMENDATION: Teach symbols in order of decreasing frequency:");

        System.out.println("   1. Symbol " + mostFrequent + " (most common, learn first)");

        System.out.println("   2. Next most frequent symbols...");

        System.out.println("   3. Symbol " + leastFrequent + " (least common, learn last)");

        System.out.println("   This creates the most efficient learning path for new speakers.\n");

        

        // Calculate entropy for language efficiency

        double entropy = 0;

        for (int i = 0; i < Basis; i++) {

            if (symbolFrequency[i] > 0) {

                double p = (double)symbolFrequency[i] / totalSymbols;

                entropy -= p * (Math.log(p) / Math.log(2));

            }

        }

        

        double maxEntropy = Math.log(Basis) / Math.log(2);

        double efficiency = (maxEntropy - entropy) / maxEntropy * 100;

        

        System.out.println("6. INFORMATION THEORY ANALYSIS:");

        System.out.println("   - Current entropy: " + String.format("%.3f", entropy) + " bits/symbol");

        System.out.println("   - Maximum possible entropy: " + String.format("%.3f", maxEntropy) + " bits/symbol");

        System.out.println("   - Language efficiency: " + String.format("%.1f", efficiency) + "%");

        System.out.println("   RECOMMENDATION: The language could be " + String.format("%.1f", 100-efficiency) + 

                          "% more information-dense with optimal symbol distribution.");

    }


    public static byte[] prunToken(byte[] token) {

        boolean first = false;

        int counter = 0;

        for (int i = 0; i < token.length; i++) {

            if (token[i] != 0) // Changed from '1' to '0' for proper leading zero removal

                first = true;

            if (first)

                counter++;

        }


        if (counter == 0) counter = 1; // Handle null case

        

        byte[] output = new byte[counter];

        for (int j = 0; j < counter; j++) {

            output[output.length - j - 1] = token[token.length - j - 1];

        }

        return output;

    }


    static void printToken(byte[] token) {

        for (byte b : token)

            System.out.print(b);

        System.out.print(' ');

    }


    public static byte[] byteToToken(byte b, int basis) {

        byte[] output = new byte[210];

        int counter = 0;

        int value = b & 0xFF; // Handle negative bytes properly

        

        while (value > 0) {

            counter++;

            int rest = value % basis;

            value = value / basis;

            output[output.length - counter] = (byte) rest;

        }

        

        // Handle null character

        if (counter == 0) {

            output[output.length - 1] = 0;

            counter = 1;

        }

        

        return output;

    }

}