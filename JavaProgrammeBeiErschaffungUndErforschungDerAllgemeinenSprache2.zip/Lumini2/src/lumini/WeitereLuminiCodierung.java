package lumini;

import java.util.*;

public class WeitereLuminiCodierung {

	static Map<Character, String> TEXT_TO_MORSE = new HashMap<>();

	private static Map<String, Character> MORSE_TO_TEXT = new HashMap<>();

	private static Random RANDOM = new Random();

	static int motivationPoints = 0;

	static int length = 4;

	static int start = 0;

	static int inc = 2;

	static int mode = 1;

	static double toText = 0;

	static String[] words = {

			"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h",

			"i", "j", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "10", "11", "12", "13", "14", "15", "20", "50",

			"75", "100", "a b", "b c", "c d", "d e", "e f", "f g", "h i", "j k", "0123", "1234", "2345", "3456", "4567",

			"5678", "6789", "789a", "89ab", "9abc", "3210", "4321", "5432", "6543", "7654", "8765", "9876", "a987",

			"ba98", "cba9", "0246", "2468", "468a", "68ac", "8ace", "aceg", "cegi", "egik", "gikm", "ikmo", "6420",

			"8642", "a864", "ca86", "eca8", "geca", "igec", "kige", "mkig", "omki", "048c", "48cg", "4cgk", "cgko",

			"c840", "gc84", "kgc4", "okgc"

	};

	static {

// Zahlen

		TEXT_TO_MORSE.put('0', ".");

		TEXT_TO_MORSE.put('1', "-");

		TEXT_TO_MORSE.put('2', "-.");

		TEXT_TO_MORSE.put('3', "--");

		TEXT_TO_MORSE.put('4', "-..");

		TEXT_TO_MORSE.put('5', "-.-");

		TEXT_TO_MORSE.put('6', "--.");

		TEXT_TO_MORSE.put('7', "---");

		TEXT_TO_MORSE.put('8', "-...");

		TEXT_TO_MORSE.put('9', "-..-");

// Buchstaben

		TEXT_TO_MORSE.put('a', "-.-.");

		TEXT_TO_MORSE.put('b', "-.--");

		TEXT_TO_MORSE.put('c', "--..");

		TEXT_TO_MORSE.put('d', "--.-");

		TEXT_TO_MORSE.put('e', "---.");

		TEXT_TO_MORSE.put('f', "----");

		TEXT_TO_MORSE.put('g', "-....");

		TEXT_TO_MORSE.put('h', "-...-");

		TEXT_TO_MORSE.put('i', "-..-.");

		TEXT_TO_MORSE.put('j', "-..--");

		TEXT_TO_MORSE.put('k', "-.-..");

		TEXT_TO_MORSE.put('l', "-.-.-");

		TEXT_TO_MORSE.put('m', "-.--.");

		TEXT_TO_MORSE.put('n', "-.---");

		TEXT_TO_MORSE.put('o', "--...");

		TEXT_TO_MORSE.put('p', "--..-");

		TEXT_TO_MORSE.put('q', "--.-.");

		TEXT_TO_MORSE.put('r', "--.--");

		TEXT_TO_MORSE.put('s', "---..");

		TEXT_TO_MORSE.put('t', "---.-");

		TEXT_TO_MORSE.put('u', "----.");

		TEXT_TO_MORSE.put('v', "-----");

		TEXT_TO_MORSE.put('w', "-.....");

		TEXT_TO_MORSE.put('x', "-....-");

		TEXT_TO_MORSE.put('y', "-...-.");

		TEXT_TO_MORSE.put('z', "-...--");

		TEXT_TO_MORSE.put('ä', "-..-..");

		TEXT_TO_MORSE.put('ö', "-..-.-");

		TEXT_TO_MORSE.put('ü', "-..--.");

// Sonderzeichen & Umlaute

		TEXT_TO_MORSE.put(',', "-..---");

		TEXT_TO_MORSE.put('.', "-.-...");

		TEXT_TO_MORSE.put('-', "-....-");

		TEXT_TO_MORSE.put('ß', "-...-.");

		TEXT_TO_MORSE.put('!', "-...--");

		TEXT_TO_MORSE.put('"', "-..-..");

		TEXT_TO_MORSE.put('$', "-..-.-");

		TEXT_TO_MORSE.put('/', "-..--.");

		TEXT_TO_MORSE.put('(', "-..---");

		TEXT_TO_MORSE.put(')', "-.-...");

		TEXT_TO_MORSE.put('=', "-.-..-");

		TEXT_TO_MORSE.put('?', "-.-.-.");

		TEXT_TO_MORSE.put('\'', "-.-.--");

		TEXT_TO_MORSE.put('@', "-.--..");

		TEXT_TO_MORSE.put('+', "-.--.-");

		TEXT_TO_MORSE.put('*', "-.---.");

		TEXT_TO_MORSE.put('^', "-.----");

		TEXT_TO_MORSE.put('[', "--....");

		TEXT_TO_MORSE.put(']', "--...-");

		TEXT_TO_MORSE.put('{', "--..-.");

		TEXT_TO_MORSE.put('}', "--..--");

		TEXT_TO_MORSE.put('&', "--.-..");

		TEXT_TO_MORSE.put('|', "--.-.-");

		TEXT_TO_MORSE.put('<', "--.--.");

		TEXT_TO_MORSE.put('>', "--.---");

		TEXT_TO_MORSE.put('~', "---...");

		TEXT_TO_MORSE.put('#', "---..-");

		TEXT_TO_MORSE.put(':', "---.-.");

		TEXT_TO_MORSE.put(';', "---.--");

		TEXT_TO_MORSE.put('_', "----..");

// Großbuchstaben

		TEXT_TO_MORSE.put('A', "-..-.-.");

		TEXT_TO_MORSE.put('B', "-..-.--");

		TEXT_TO_MORSE.put('C', "-..--..");

		TEXT_TO_MORSE.put('D', "-..--.-");

		TEXT_TO_MORSE.put('E', "-..---.");

		TEXT_TO_MORSE.put('F', "-..----");

		TEXT_TO_MORSE.put('G', "-.-....");

		TEXT_TO_MORSE.put('H', "-.-...-");

		TEXT_TO_MORSE.put('I', "-.-..-.");

		TEXT_TO_MORSE.put('J', "-.-..--");

		TEXT_TO_MORSE.put('K', "-.-.-..");

		TEXT_TO_MORSE.put('L', "-.-.-.-");

		TEXT_TO_MORSE.put('M', "-.-.--.");

		TEXT_TO_MORSE.put('N', "-.-.---");

		TEXT_TO_MORSE.put('O', "-.--...");

		TEXT_TO_MORSE.put('P', "-.--..-");

		TEXT_TO_MORSE.put('Q', "-.--.-.");

		TEXT_TO_MORSE.put('R', "-.--.--");

		TEXT_TO_MORSE.put('S', "-.---..");

		TEXT_TO_MORSE.put('T', "-.---.-");

		TEXT_TO_MORSE.put('U', "-.----.");

		TEXT_TO_MORSE.put('V', "-.-----");

		TEXT_TO_MORSE.put('W', "--.....");

		TEXT_TO_MORSE.put('X', "--....-");

		TEXT_TO_MORSE.put('Y', "--...-.");

		TEXT_TO_MORSE.put('Z', "--...--");

		TEXT_TO_MORSE.put('Ä', "--..-..");

		TEXT_TO_MORSE.put('Ö', "--..-.-");

		TEXT_TO_MORSE.put('Ü', "--..--.");

// Wort trennen

		TEXT_TO_MORSE.put(' ', " ");

// Umkehrabbildung bauen

		for (Map.Entry<Character, String> entry : TEXT_TO_MORSE.entrySet()) {

			MORSE_TO_TEXT.put(entry.getValue(), entry.getKey());

		}

	}

// // RandomText

	public static String generatedText1(int length, int start, int inc) {

		StringBuilder sb = new StringBuilder();

		boolean dec = false;

		if (Math.random() > 0.5)
			dec = true;

		for (int i = 0; i < length; i++) {

			int number = 0;

			if (dec) {
				number = start - inc * i;
				toText = 1;
			}

			else {
				number = start + inc * i;
				toText = 0;
			}

			if (Math.random() > 0.5)
				number += 64;

			number = Math.abs(number);

			String s = Integer.toBinaryString(number);

			String morseString = s.replace('0', '.').replace('1', '-');

			String text = fromMorse(morseString);

			sb.append(text);

		}

		return sb.toString();

	}

// // RandomText

	public static String randomText1(int length, int start, int inc) {

		StringBuilder sb = new StringBuilder();

		int randLength = 1 + (int) (Math.random() * length);

		int randStart = (int) (Math.random() * start);

		int randInc = (int) (Math.random() * inc) - (int) (Math.random() * inc);

		for (int i = 0; i < randLength; i++) {

			int number = randStart + i * randInc;

			number = Math.abs(number);

			String s = Integer.toBinaryString(number);

			String morseString = s.replace('0', '.').replace('1', '-');

			String text = fromMorse(morseString);

			sb.append(text);

		}

		return sb.toString();

	}

// RandomText

	public static String randomText2(int length, int start, int inc) {

		StringBuilder sb = new StringBuilder();

		int randLength = length + (int) (Math.random() * length) - (int) (Math.random() * length);

		int randStart = (int) (Math.random() * start);

		int randInc = (int) (Math.random() * inc);

		if (Math.random() > 0.5)
			randInc = -randInc;

		for (int i = 0; i < randLength; i++) {

			int number = randStart + i * randInc;

			number = Math.abs(number);

			if (Math.random() > 0.5 && number > 9)
				number += 64;

			String s = Integer.toBinaryString(number);

			String morseString = s.replace('0', '.').replace('1', '-');

			String text = fromMorse(morseString);

			sb.append(text);

		}

		return sb.toString();

	}

// Klartext -> Morse

	public static String toMorse(String text) {

		StringBuilder sb = new StringBuilder();

		for (char c : text.toCharArray()) {

			if (TEXT_TO_MORSE.containsKey(c)) {

				sb.append(TEXT_TO_MORSE.get(c)).append(" ");

			}

		}

		return sb.toString().trim();

	}

// Morse -> Klartext

	public static String fromMorse(String morse) {

		StringBuilder sb = new StringBuilder();

		String[] codes = morse.split(" ");

		for (String code : codes) {

			if (MORSE_TO_TEXT.containsKey(code)) {

				sb.append(MORSE_TO_TEXT.get(code));

			} else if (code.equals(" ")) {

				sb.append(" ");

			}

		}

		return sb.toString();

	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("🌟 Willkommen beim Lumini-Morsetrainer-Game 🌟");

		System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");

		boolean running = true;

		while (running) {

			System.out.println("Menü:");

			System.out.println("Mode:" + mode + " Start:" + start + " Length:" + length + " Inc:" + inc
					+ " ToTextWahrscheinlichkeit:" + toText);

			System.out.println("1 = Text → Morse");

			System.out.println("2 = Morse → Text");

			System.out.println("3 = Punktestand anzeigen");

			System.out.println("4 = 10er Morse Quest");

			System.out.println("5 = 50er Morse Quest mit inc");

			System.out.println("6 = Mode wählen, Aufgabengenerierung durch randomTextMode oder selber definiert");

			System.out.println("7 = Start einstellen- Wo die Reihe durchschnittlich beginnt");

			System.out.println("8 = Length einstellen - Wie lang die Reihe ist");

			System.out.println("9 = Inc einstellen - in welchen Schritten die Reihe hochzählt");

			System.out.println("10 = ToText Wahrscheinlichkeit 0 bis 1");

			System.out.println("0 = Beenden");

			System.out.print("Wähle: ");

			int choice = scanner.nextInt();

			scanner.nextLine();

			switch (choice) {

			case 1:

				playTextToMorse(scanner);

				break;

			case 2:

				playMorseToText(scanner);

				break;

			case 3:

				System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");

				break;

			case 4:

				playMorseTraining1(scanner);

				break;

			case 5:

				playMorseTraining2(scanner);

				break;

			case 6:

				mode = scanner.nextInt();

				break;

			case 7:

				start = scanner.nextInt();

				break;

			case 8:

				length = scanner.nextInt();

				break;

			case 9:

				inc = scanner.nextInt();

				break;

			case 10:

				toText = scanner.nextDouble();

				break;

			case 0:

				running = false;

				System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");

				break;

			default:

				System.out.println("Ungültige Auswahl!\n");

			}

		}

		scanner.close();

	}

	static void playTextToMorse(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

		if (mode == 1)
			word = generatedText1(length, start, inc);

		if (mode == 3)
			word = randomText1(length, start, inc);

		if (mode == 4)
			word = randomText2(length, start, inc);

		String correctMorse = toMorse(word);

		System.out.println("Übersetze in Morse: " + word);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(correctMorse)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + correctMorse + "\n");

		}

	}

	static void playMorseToText(Scanner scanner) {

		String word = words[RANDOM.nextInt(words.length)];

		if (mode == 1)
			word = generatedText1(length, start, inc);

		if (mode == 3)
			word = randomText1(length, start, inc);

		if (mode == 4)
			word = randomText2(length, start, inc);

		String morse = toMorse(word);

		System.out.println("Übersetze in Text: " + morse);

		String answer = scanner.nextLine().trim();

		if (answer.equalsIgnoreCase(word)) {

			motivationPoints += 10;

			System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

		} else {

			System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");

		}

	}

	static void playMorseTraining1(Scanner scanner) {

		for (int i = 0; i < 10; i++) {

			if (Math.random() > toText)

				playTextToMorse(scanner);

			else

				playMorseToText(scanner);

		}

	}

	static void playMorseTraining2(Scanner scanner) {

		for (int i = 0; i < 50; i++) {

			start++;

			if (Math.random() > toText)

				playTextToMorse(scanner);

			else

				playMorseToText(scanner);

		}

	}

}