package lumini;

import java.awt.Color;

public class ElementAtom {
	String Artikel = "--"; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
	String protonenzahl; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
	String valenzelektronen; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
	String dichte; // Vielfaches der Dichte von H2O in Lumini
	
	int ordnungszahl;
	String name;
	String symbol;
	double atomgewicht;
	double dichteDouble;
	String serie;
	double elektronegativitätDouble;
	double potentielleChemischeEnergie;
	double halbwärtszeit;
	Color rgbWerte;
	double elektrischeLeitfähigkeit;
	int[] orbitalBefüllungen;
	double häufigkeitUniversum;
	double häufigkeitSonnensystem;
	double häufigkeitErde;
	double häufigketErdoberfläche;
	
	public ElementAtom(String artikel, String protonenzahl, String valenzelektronen) {
		this.Artikel=artikel;
		this.protonenzahl=protonenzahl;
		this.valenzelektronen=valenzelektronen;
	}
	
}
