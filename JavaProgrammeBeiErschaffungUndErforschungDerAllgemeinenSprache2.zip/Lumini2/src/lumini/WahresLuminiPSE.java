package lumini;

import java.util.ArrayList;

public class WahresLuminiPSE {
	ArrayList<ElementAtom> wahresPeriodensystemDerElementeOktet = new ArrayList();
	
	public void makePSE1() {
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-","-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-.","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--","-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-..","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-.-","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","--.","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","---","-.-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-...","--."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-..-","---"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-.-.","-..."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.--","-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--..","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--.-","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","---.","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","----","-.-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-....","--."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-...-","---"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-..-.","-..."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-..--","-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.-..","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.-.-","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.--.","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.---","-.-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--...","--."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--..-","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--.-.","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--.--","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","---..","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","---.-","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","----.","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-----","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-.....","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-....-","-.-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-...-.","--."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-...--","---"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("..","-..-..","-..."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-..-.-","-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-..--.","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-..---","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.-...","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.-..-","-.-"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.-.-.","--."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.-.--","-.."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.--..","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.--.-","--"));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.---.","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","-.----","-."));
		wahresPeriodensystemDerElementeOktet.add(new ElementAtom("--","--....","-."));
		
	}
}
