package lumini;


import java.util.*;


public class MorseMultiTranslate {


static Map<Character, String> TEXT_TO_MORSE = new HashMap<>();

private static Map<String, Character> MORSE_TO_TEXT = new HashMap<>();

private static Random RANDOM = new Random();

static int motivationPoints = 0;


static String[] words = {

"E","T","ET","TE","TEE","ETE","TET","TETE","e","t","Tee",

"I","A","N","M", "IAMN","NMAI","MAIN","main","Main","Nami","Name","name",

"S","O","SOS", "E", "I", "EIS", "T","M","TMO", "A","N","IANM","H","EISH","U","R","SUR","W","SURW","D","K","G","O","DKGO"

,"AEIOU"

,"Andreas"

,"L","Hello","Hello World","V","HV","Hello Universe"

,"Mein","Name","ist","Y","YL","LY","My","name","is","Andi","Mein Name ist Andreas","My name is Andi"

,"A","B","C","ABC","Andreas Schneider","Andi","Andi","Schneider"

,"HVFÜ","LÄPJ","BXCY","ZQÖ"

,"HVFÜLÄPJBXCYZQÖ"

,"EISH5","EAWJ1","TNDB6","TMO0"

,"12345","6789","0","54321","9876","09876","0123","890","0123456789","9876543210"

,"Ä","Ö","Ü"

,",",".","-"

,"+","-","(",")","="

,"ß","Sß","?"

,".-öäüß!\" $ / ( ) = ? ' @ +"

,"HVFÜLÄPJBXCYZQ"

,"a","A"

,"Ä","ä"

,"äöü", ",.-"

,"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!",

"Bitte schreib mir eine Nachricht und verbinde unsere Visionen", "@Andreas5564", "andreas.schneider01989",

"+491778627094", "Fragment des Übergangs", "Struktgame", "Quantenverschränkung", "Collectiv Conciousnes",

"Telepathie", "Search: Heiliges Hirn on YouTube",

"Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit", "Find my Matrixgame-Journal",

"Please use and improve", "Open Source", "Photosynthese und Zellatmung", "Mandarin", "Latein", "Deutsch",

"english", "Periodensystem of elements", "SI Units", "Bit and Byte", "Binary Language", "Ascii",

"Hello Universe", "Hello World", ",.-öäüß!\" $ / ( ) = ? ' @", "01234567890", "ABCDEFGHIJKLMNOPQRSTUVWXYZ",

"Licht Forschung", "KIGame", "Lumini4", "Matrixgame", "LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT",

"HELLO!", "ÄÖÜ", "123"

,"SO", "UG", "OS" ,"GU", "WG", "RK", "KR", "RR", "KK", "UD", "UG", "UD", "WD", "WG", "DW", "DU", "KR", "KK", "GW", "GU"

,"ETNMDKGOBXCYZQÖ"

,"ABCDEFG","HIJKLMN","OPQRS","TUVW","XYZ"

,"ÖÄÜ","asdf","jklö","ei","gh","äöa"

,"HV", "VB", "FQ", "FL", "ÜZ", "ÜZ", "LF", "LY", "ÄC", "PX", "JB", "BJ", "XP", "CÄ", "YL", "ZÜ", "QF", "ÖV"

,"e+e=e", "e+t=t", "t+e=t", "t+t=n","t-e=t","t-t=e","e=i=s=h","t=a=u","m+m=g","g-n=d"

,"0","1","2","3","4","5","6","7","8","9"

,",",".","-","ö","ä","ü","ß","!","$","/","(",")","=","?","'","@"

,"02468","86420","I II III IV V", "IVX","1 2 4 8 16 32 64","1 2 5 10 20 50 100","IVXLC"

,"0","1","10","11","100","101","110","111","0 1 10 11 100 101 110 111"

,".","-","-.","--","-..","-.-","--.","---",". - -. -- -.. -.- --. ---"

,"e t te tt tee trt tte ttt teee teet tete tett ttee ttet ttte tttt"

,"0123456789abcde"

,"VFLB", "ÖQYJ", "JÜVH", "BZÖ", "ÖZBH", "HVÜJ", "HFLPBCZÖ", "QYXJÄÜ"

,"1 2 3 5 7 11 13 17"

,"1 2 6 30 210"

,"3 9 27 81","-- -..- --.-- --...-","tt teet ttett tteeet","11 1001 11011 110001","3 9 1b 51"

,"5 25 125"

,"7 49 343"

};

static {

// Buchstaben

TEXT_TO_MORSE.put('A', ".-");

TEXT_TO_MORSE.put('B', "-...");

TEXT_TO_MORSE.put('C', "-.-.");

TEXT_TO_MORSE.put('D', "-..");

TEXT_TO_MORSE.put('E', ".");

TEXT_TO_MORSE.put('F', "..-.");

TEXT_TO_MORSE.put('G', "--.");

TEXT_TO_MORSE.put('H', "....");

TEXT_TO_MORSE.put('I', "..");

TEXT_TO_MORSE.put('J', ".---");

TEXT_TO_MORSE.put('K', "-.-");

TEXT_TO_MORSE.put('L', ".-..");

TEXT_TO_MORSE.put('M', "--");

TEXT_TO_MORSE.put('N', "-.");

TEXT_TO_MORSE.put('O', "---");

TEXT_TO_MORSE.put('P', ".--.");

TEXT_TO_MORSE.put('Q', "--.-");

TEXT_TO_MORSE.put('R', ".-.");

TEXT_TO_MORSE.put('S', "...");

TEXT_TO_MORSE.put('T', "-");

TEXT_TO_MORSE.put('U', "..-");

TEXT_TO_MORSE.put('V', "...-");

TEXT_TO_MORSE.put('W', ".--");

TEXT_TO_MORSE.put('X', "-..-");

TEXT_TO_MORSE.put('Y', "-.--");

TEXT_TO_MORSE.put('Z', "--..");

TEXT_TO_MORSE.put(' ', "/"); // Wort-Trenner


// Zahlen

TEXT_TO_MORSE.put('0', "-----");

TEXT_TO_MORSE.put('1', ".----");

TEXT_TO_MORSE.put('2', "..---");

TEXT_TO_MORSE.put('3', "...--");

TEXT_TO_MORSE.put('4', "....-");

TEXT_TO_MORSE.put('5', ".....");

TEXT_TO_MORSE.put('6', "-....");

TEXT_TO_MORSE.put('7', "--...");

TEXT_TO_MORSE.put('8', "---..");

TEXT_TO_MORSE.put('9', "----.");


// Sonderzeichen & Umlaute

TEXT_TO_MORSE.put(',', "--..--");

TEXT_TO_MORSE.put('.', ".-.-.-");

TEXT_TO_MORSE.put('-', "-....-");

TEXT_TO_MORSE.put('Ö', "---.");

TEXT_TO_MORSE.put('Ä', ".-.-");

TEXT_TO_MORSE.put('Ü', "..--");

TEXT_TO_MORSE.put('ß', "......");

TEXT_TO_MORSE.put('!', "-.-.--");

TEXT_TO_MORSE.put('"', ".-..-.");

TEXT_TO_MORSE.put('$', "...-..-");

TEXT_TO_MORSE.put('/', "-..-.");

TEXT_TO_MORSE.put('(', "-.--.");

TEXT_TO_MORSE.put(')', "-.--.-");

TEXT_TO_MORSE.put('=', "-...-");

TEXT_TO_MORSE.put('?', "..--..");

TEXT_TO_MORSE.put('\'', ".----.");

TEXT_TO_MORSE.put('@', ".--.-.");

TEXT_TO_MORSE.put('+', ".-.-.");


// Umkehrabbildung bauen

for (Map.Entry<Character, String> entry : TEXT_TO_MORSE.entrySet()) {

MORSE_TO_TEXT.put(entry.getValue(), entry.getKey());

}

}


// Klartext -> Morse

public static String toMorse(String text) {

StringBuilder sb = new StringBuilder();

for (char c : text.toUpperCase().toCharArray()) {

if (TEXT_TO_MORSE.containsKey(c)) {

sb.append(TEXT_TO_MORSE.get(c)).append(" ");

}

}

return sb.toString().trim();

}


// Morse -> Klartext

public static String fromMorse(String morse) {

StringBuilder sb = new StringBuilder();

String[] codes = morse.split(" ");

for (String code : codes) {

if (MORSE_TO_TEXT.containsKey(code)) {

sb.append(MORSE_TO_TEXT.get(code));

} else if (code.equals("/")) {

sb.append(" ");

}

}

return sb.toString();

}


public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);

System.out.println("🌟 Willkommen beim Lumini-Morsetrainer-Game 🌟");

System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");


boolean running = true;

while (running) {

System.out.println("Menü:");

System.out.println("1 = Text → Morse");

System.out.println("2 = Morse → Text");

System.out.println("3 = Punktestand anzeigen");

System.out.println("4 = 10er Morse Quest");

System.out.println("0 = Beenden");

System.out.print("Wähle: ");


int choice = scanner.nextInt();

scanner.nextLine();


switch (choice) {

case 1:

playTextToMorse(scanner);

break;

case 2:

playMorseToText(scanner);

break;

case 3:

System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");

break;

case 4:

playMorseTraining1(scanner);

break;

case 0:

running = false;

System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");

break;

default:

System.out.println("Ungültige Auswahl!\n");

}

}


scanner.close();

}


static void playTextToMorse(Scanner scanner) {

String word = words[RANDOM.nextInt(words.length)];

String correctMorse = toMorse(word);


System.out.println("Übersetze in Morse: " + word);

String answer = scanner.nextLine().trim();


if (answer.equalsIgnoreCase(correctMorse)) {

motivationPoints += 10;

System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

} else {

System.out.println("❌ Falsch. Richtige Antwort: " + correctMorse + "\n");

}

}


static void playMorseToText(Scanner scanner) {


String word = words[RANDOM.nextInt(words.length)];

String morse = toMorse(word);


System.out.println("Übersetze in Text: " + morse);

String answer = scanner.nextLine().trim().toUpperCase();


if (answer.equalsIgnoreCase(word)) {

motivationPoints += 10;

System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");

} else {

System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");

}

}


static void playMorseTraining1(Scanner scanner) {

for (int i = 0; i < 10; i++) {

if (Math.random() > 0.5)

playTextToMorse(scanner);

else

playMorseToText(scanner);

}

}

} 