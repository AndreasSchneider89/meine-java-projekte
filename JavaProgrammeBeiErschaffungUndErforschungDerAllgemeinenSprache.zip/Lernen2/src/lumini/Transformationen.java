package lumini;

public class Transformationen {

	public int addBits(int i){
		if (i==1) return 1;
		double d = Math.log(i)/Math.log(2);
		int a = (d == (int)d)? (int)d : ((int)d)+1;
		return a;
	}

	public int ggt(int n1, int n2){
		n1 = Math.abs(n1);
		n2 = Math.abs(n2);
		while(n2 != 0){
			if(n1 > n2) n1 -= n2;
			else n2 -= n1;
		}
		return n1;
	}
	
	public String bruchrechnen(int ze, int ne){
		int zahl = 0;
		int teiler = ggt(ne, ze);
		ze /= teiler;
		ne /= teiler;
		if(ne == 0) return "0";
		if(ne == 1) return String.valueOf(ze);
		zahl = ze/ne;
		if(zahl != 0) return(zahl+ " "+ze % ne+"/"+ne);
		return(ze+"/"+ne);
	}
	public String bruchrechnenAdd(int z1, int n1, int z2, int n2){
		int ze = z1*n2+z2*n1;
		int ne = n1*n2;
		return bruchrechnen(ze, ne);
	}
	
	public String bruchrechnenSub(int z1, int n1, int z2, int n2){
		int ze = z1*n2-z2*n1;
		int ne = n1*n2;
		return bruchrechnen(ze, ne);
	}
	
	public String bruchrechnenMul(int z1, int n1, int z2, int n2){
		int ze = z1*z2;
		int ne = n1*n2;
		return bruchrechnen(ze, ne);
	}
	
	public String bruchrechnenDiv(int z1, int n1, int z2, int n2){
		int ze = z1*n2;
		int ne = n1*z2;
		return bruchrechnen(ze, ne);
	}
	
	public int[] zahlenreihen(int level){
		int[] reihe1 = new int[5];
		int[] reihe2 = new int[4];
		int[] reihe3 = new int[3];
		int[] reihe4 = new int[2];
		reihe1[0] = (int)(Math.random() * (level+3));
		reihe2[0] = (int)(Math.random() * (level+3));
		reihe3[0] = (int) Math.max((Math.random() * level - 0.8) , 0);
		reihe4[0] = (int) Math.max((Math.random() * level - 2.5) , 0);
		if(Math.random() < Math.min(0.5, level*0.1)) reihe1[0] *= -1;
		if(Math.random() < Math.min(0.5, level*0.1)) reihe2[0] *= -1;
		if(Math.random() < Math.min(0.5, level*0.1)) reihe3[0] *= -1;
		if(Math.random() < Math.min(0.5, level*0.1)) reihe4[0] *= -1;
		for(int i=1; i<2; i++){
			reihe4[i] = reihe4[i-1];
		}
		for(int i=1; i<3; i++){
			reihe3[i] = reihe3[i-1] + reihe4[i-1];
		}
		for(int i=1; i<4; i++){
			reihe2[i] = reihe2[i-1] + reihe3[i-1];
		}
		for(int i=1; i<5; i++){
			reihe1[i] = reihe1[i-1] + reihe2[i-1];
		}
		return reihe1;
	}
	
	double einheit2Byte(String s){
		s = s.toLowerCase();
		double z;
		if(s.contains("ebyte")){z = Double.valueOf(s.substring(0, s.indexOf("ebyte"))); return z*Math.pow(1024,6);}
		else if(s.contains("p")){z = Double.valueOf(s.substring(0, s.indexOf("p"))); return z*Math.pow(1024,5);}
		else if(s.contains("tbyte")){z = Double.valueOf(s.substring(0, s.indexOf("tbyte"))); return z*Math.pow(1024,4);}
		else if(s.contains("g")){z = Double.valueOf(s.substring(0, s.indexOf("g"))); return z*Math.pow(1024,3);}
		else if(s.contains("m")){z = Double.valueOf(s.substring(0, s.indexOf("m"))); return z*Math.pow(1024,2);}
		else if(s.contains("k")){z = Double.valueOf(s.substring(0, s.indexOf("k"))); return z*Math.pow(1024,1);}
		else if(s.contains("byte")){z = Double.valueOf(s.substring(0, s.indexOf("byte"))); return z;}
		else return Double.valueOf(s);
	}
	
	double einheit2ByteSI(String s){
		s = s.toLowerCase();
		double z;
		if(s.contains("ebyte")){z = Double.valueOf(s.substring(0, s.indexOf("ebyte"))); return z*Math.pow(1000,6);}
		else if(s.contains("p")){z = Double.valueOf(s.substring(0, s.indexOf("p"))); return z*Math.pow(1000,5);}
		else if(s.contains("tbyte")){z = Double.valueOf(s.substring(0, s.indexOf("tbyte"))); return z*Math.pow(1000,4);}
		else if(s.contains("g")){z = Double.valueOf(s.substring(0, s.indexOf("g"))); return z*Math.pow(1000,3);}
		else if(s.contains("m")){z = Double.valueOf(s.substring(0, s.indexOf("m"))); return z*Math.pow(1000,2);}
		else if(s.contains("k")){z = Double.valueOf(s.substring(0, s.indexOf("k"))); return z*Math.pow(1000,1);}
		else if(s.contains("byte")){z = Double.valueOf(s.substring(0, s.indexOf("byte"))); return z;}
		else return Double.valueOf(s);
	}
	
	String byte2Einheit(double d){
		String e="";
		String z="";
		if(d >= Math.pow(1024, 6)){e = " EByte"; z=String.valueOf(d/Math.pow(1024, 6));}
		else if(d >= Math.pow(1024, 5)){e = " PByte"; z=String.valueOf(d/Math.pow(1024, 5));}
		else if(d >= Math.pow(1024, 4)){e = " TByte"; z=String.valueOf(d/Math.pow(1024, 4));}
		else if(d >= Math.pow(1024, 5)){e = " GByte"; z=String.valueOf(d/Math.pow(1024, 3));}
		else if(d >= Math.pow(1024, 2)){e = " MByte"; z=String.valueOf(d/Math.pow(1024, 2));}
		else if(d >= Math.pow(1024, 1)){e = " KByte"; z=String.valueOf(d/Math.pow(1024, 1));}
		else                           {e = " Byte"; z=String.valueOf(d);}
		return z+e;
	}
	
	String byte2EinheitSI(double d){
		String e="";
		String z="";
		if(d >= Math.pow(1000, 6)){e = " EByte"; z=String.valueOf(d/Math.pow(1000, 6));}
		else if(d >= Math.pow(1000, 5)){e = " PByte"; z=String.valueOf(d/Math.pow(1000, 5));}
		else if(d >= Math.pow(1000, 4)){e = " TByte"; z=String.valueOf(d/Math.pow(1000, 4));}
		else if(d >= Math.pow(1000, 5)){e = " GByte"; z=String.valueOf(d/Math.pow(1000, 3));}
		else if(d >= Math.pow(1000, 2)){e = " MByte"; z=String.valueOf(d/Math.pow(1000, 2));}
		else if(d >= Math.pow(1000, 1)){e = " KByte"; z=String.valueOf(d/Math.pow(1000, 1));}
		else                           {e = " Byte"; z=String.valueOf(d);}
		return z+e;
	}
	
	public int[] nextSqrt(int i) {
		int[] t = { 0, 0, 0, 0, 0, 0 };
		int max = 0;
		int[] ret = { 0, 0 };
		while (Math.pow(t[0], 2) <= i) {
			t[0]++;
		}
		t[0]--;
		if (max < Math.pow(t[0], 2)) {
			max = (int) Math.pow(t[0], 2);
			ret[0] = t[0];
			ret[1] = 2;
		}
		while (Math.pow(t[1], 3) <= i) {
			t[1]++;
		}
		t[1]--;
		if (max < Math.pow(t[1], 3)) {
			max = (int) Math.pow(t[1], 3);
			ret[0] = t[1];
			ret[1] = 3;
		}
		while (Math.pow(t[2], 4) <= i) {
			t[2]++;
		}
		t[2]--;
		if (max < Math.pow(t[2], 4)) {
			max = (int) Math.pow(t[2], 4);
			ret[0] = t[2];
			ret[1] = 4;
		}
		while (Math.pow(t[3], 5) <= i) {
			t[3]++;
		}
		t[3]--;
		if (max < Math.pow(t[3], 5)) {
			max = (int) Math.pow(t[3], 5);
			ret[0] = t[3];
			ret[1] = 5;
		}
		while (Math.pow(t[4], 6) <= i) {
			t[4]++;
		}
		t[4]--;
		if (max < Math.pow(t[4], 6)) {
			max = (int) Math.pow(t[4], 6);
			ret[0] = t[4];
			ret[1] = 6;
		}
		while (Math.pow(t[5], 7) <= i) {
			t[5]++;
		}
		t[5]--;
		if (max < Math.pow(t[5], 7)) {
			max = (int) Math.pow(t[5], 7);
			ret[0] = t[5];
			ret[1] = 7;
		}

		return ret;

	}
	
	public int elo(int RA, int RB, int k, double SA){
		double EA = 1/(1 + Math.pow(10, (RB-RA)/400.0));
		double RAnew = RA + k * (SA - EA);
		if(RAnew >= 0) RAnew += 0.5;
		else RAnew -= 0.5;
		return (int) RAnew;
	}
	
	public double getWahrscheinlichkeit(boolean bool) {
		if (bool==true)return 1.0;
		else return 0.0;
	}
	
	public double ProcentToWahrscheinlichkeit(double prozent) {
		return prozent/100.0;
	}
	
	public int charToAsci(char c) {
		return (int)c;
	}
	
	public String binaryToLumini(String binary) {
		String luminiString = binary.replace('0', '.');
		 luminiString = luminiString.replace('1', '-');
		
		return luminiString;
	}
	
	public String luminiToBinary(String lumini) {
		String binaryString = lumini.replace('.', '0');
		 binaryString = binaryString.replace('-', '1');
		
		return binaryString;
	}
	
	public static long getLuminiBasisNeuNumbers(int LumNeuLänge, int LumNeuBasis) {
		if(LumNeuLänge==0)return 0;
		long output = -1;
		for (int i = 1; i <= LumNeuLänge; i++) {
			output += (Math.pow(LumNeuBasis, i));
		}

		return output;
	}

	public static long basisNStringToLong(String basNStr, int basis) {
		int lenge = basNStr.length();
		long output = 0;
		int symbol = 0;
		for (int i = lenge - 1; i >= 0; i--) {
			if (basNStr.charAt(i) == '0')
				symbol = 0;
			if (basNStr.charAt(i) == '1')
				symbol = 1;
			if (basNStr.charAt(i) == '2')
				symbol = 2;
			if (basNStr.charAt(i) == '3')
				symbol = 3;
			if (basNStr.charAt(i) == '4')
				symbol = 4;
			if (basNStr.charAt(i) == '5')
				symbol = 5;
			if (basNStr.charAt(i) == '6')
				symbol = 6;
			if (basNStr.charAt(i) == '7')
				symbol = 7;
			if (basNStr.charAt(i) == '8')
				symbol = 8;
			if (basNStr.charAt(i) == '9')
				symbol = 9;
			
			output+=(symbol*Math.pow(basis, (lenge - 1-i)));
		}
		return output;
	}

	public static long newLuminiNumberToDecimal(String newLuminiNumber, int basis) {
		int lenge = newLuminiNumber.length();
		long number = getLuminiBasisNeuNumbers(lenge - 1, basis)+1;
		if(lenge==1)number=0;
		number+=basisNStringToLong(newLuminiNumber,basis);
		return number;
	}
	
		
	// Beliebige Zahlentypen -> Double    (Wenn nötig schnell konvertieren können zu höherer Mathematik)
	// Alternativ alles auf public und alles auf double
	
	// Double und andere Datentypen -> String
	
	// Umrechnen von Vorkommaanteil und nachkommaanteil in beliebige Basis
	
	// String unterteilen in Elementare Zeichen
	
	// Transformationen der Zeichen in andere Zeichen etwa 0->.; 1->- (Lumini)
	
	// Transformatione Asci, Morse, Lumini
	
	// Zeichen definieren auf Pixelrechteck
	
	
	
	
}
