import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import acm.program.GraphicsProgram;

//Punkte:
//-0.0620050239,-1.256007184,33,100
//-0.0620050239,-1.256007184,6,100
//-0.062,-1.2559915,7,300
//-0.06,-1.25,9,220
//-0.062-1.4*(-0.062+0.06),-1.2559915-1.4*(-1.2559915+1.25),9.8,220
//-0.06,-1.25,4,100

//-0.9,0,4,100

//0,0,0,100

//0.55,0.3,0,100
//0.55,0.3,3.5,100
//0.58,0.2,5,170
//0.65,0.05,7,170
//0.645,0.055,9,170
//0.649,0.055,10,200
//0.649,0.055,10,500

//-0.649,-0.7499080363,2,100

//-0.0800116743,-0.7499080363,6,100
//-0.0799,-0.7496,14,400
//-0.0792,-0.74795,11,100
//-0.0792,-0.74795,11,700
//-0.08001,-0.74991,12,100
//-0.07885,-0.747842,12,130
//-0.07884,-0.747855,17,100
//-0.07884,-0.747846,20,300
//-0.0788398,-0.7478469,21,600
//-0.0788398,-0.7478469,23,600
//-0.0788398,-0.7478469,22,1200
//-0.0788398,-0.7478469,23,2000

//0.58,0.2,5,170
//0.65,0.05,7,170

// Verlinktes Musikvideo:
// https://www.youtube.com/watch?v=4fJKUKMpYGg&t=3s



public class Mandelbrotmenge extends GraphicsProgram {
	double[] Punkt = {0,0,0,100}; // erstes+ -> runter,
										// zweites+ ->
										// rechts;
	// double d = 0.8;
	// double[] Punkt =
	// {0.58-d*(0.58-0.65),0.2-d*(0.2-0.05),5-d*(5-7),170-d*(170-170)};
	// //erstes+ -> runter, zweites+ -> rechts;

	double zoom2Pot = Punkt[2];
	double zoom = Math.pow(2, zoom2Pot);
	int raster = 1;
	int iterationen = (int) (Punkt[3] + (Math.log10(zoom) * 50));
	double farbDarstellung = iterationen / 110.0;
	double obererRand = Punkt[0] - 1.1 / zoom;
	double linkerRand = Punkt[1] - 2.1 / zoom;
	double zelle = 0.00325 / zoom;
	int zeilen = 720;
	int spalten = 1370;
	short[][] feld = new short[spalten][zeilen];
	byte[][] �nderung = new byte[spalten][zeilen];
	long gesIter = 0;

	// C-Werte checken:
	// Es gilt: Zn+1 = Zn * Zn + C
	// i * i = -1
	// Z0 = 0
    // if |Zn| > 2 -> gebe Iterationen bzw. n aus
	
	public short checkC(double reC, double imC) {
		double reZ = 0, imZ = 0, reZ_minus1 = 0, imZ_minus1 = 0;
		short i = 0;
		short i2 = 0;
		double max = 0;
		for (i = 0; i < iterationen; i++) {
			imZ = 2 * reZ_minus1 * imZ_minus1 + imC;
			reZ = reZ_minus1 * reZ_minus1 - imZ_minus1 * imZ_minus1 + reC;
			if (reZ * reZ + imZ * imZ > 4)
				return i;
			if (reZ * reZ + imZ * imZ > max)
				{i2=0; max = reZ * reZ + imZ * imZ;}
			i2++;
			//if(i2 > iterationen/2) return (short) iterationen;
			reZ_minus1 = reZ;
			imZ_minus1 = imZ;
		}
		return i;
	}

	// Punkte berechnen und setzen.
	public void paint(Graphics g) {
		double reC, imC;

		imC = obererRand; // oberer Rand
		for (int y = 0; y < zeilen; y++) {
			reC = linkerRand; // linker Rand
			for (int x = 0; x < spalten; x++) {

				if ((x % raster == 0 && y % raster == 0) || x == 0 || y == 0
						|| x == spalten - 1 || y == zeilen - 1) {
					feld[x][y] = checkC(reC, imC);
					gesIter = gesIter + feld[x][y];
					if (x - raster < 0 || y - raster < 0 || x == spalten - 1
							|| y == zeilen - 1)
						�nderung[x][y] = 22;
					else {
						if (feld[x][y] < feld[x - raster][y])
							�nderung[x][y] = 1;
						else if (feld[x][y] == feld[x - raster][y])
							�nderung[x][y] = 2;
						else
							�nderung[x][y] = 3;
						if (feld[x][y] < feld[x][y - raster])
							�nderung[x][y] += 10;
						else if (feld[x][y] < feld[x][y - raster])
							�nderung[x][y] += 20;
						else
							�nderung[x][y] += 30;
					}
				}

				reC = reC + zelle; // n�chste Spalte
			}
			imC = imC + zelle; // n�chste Zeile
		}
		imC = obererRand; // oberer Rand
		for (int y = 0; y < zeilen; y++) {
			reC = linkerRand; // linker Rand
			for (int x = 0; x < spalten; x++) {
				short f1 = 0, f2 = 0;
				short ae1 = 0, ae2=0;
				int count = 0;
				int count2 = 0;
				if ((x % raster != 0 || y % raster != 0) && x != 0 && y != 0
						&& x != spalten - 1 && y != zeilen - 1) {

					while (true) {
						if ((x - count) % raster != 0 && x - count != 0)
							count++;
						if ((y - count2) % raster != 0 && y - count2 != 0)
							count2++;
						if (((x - count) % raster == 0 && (y - count2) % raster == 0)
								|| x - count == 0 || y - count2 == 0) {

							f1 = feld[x - count][y - count2];
							ae1 = �nderung[x - count][y - count2];
							count = 0;
							count2 = 0;
							break;
						}
					}

					while (true) {
						if ((x + count) % raster != 0
								&& x + count != spalten - 1)
							count++;
						if ((y + count2) % raster != 0
								&& y + count2 != zeilen - 1)
							count2++;
						if (((x + count) % raster == 0 && (y + count2) % raster == 0)
								|| x + count == spalten - 1
								|| y + count2 == zeilen - 1) {

							f2 = feld[x + count][y + count2];
							ae2 = �nderung[x + count][y + count2];
							count = 0;
							count2 = 0;
							break;
						}
					}
					 if (Math.abs(f1 - f2) == 1) {
						feld[x][y] = checkC(reC, imC);
						gesIter = gesIter + feld[x][y];
					}
					 else if (ae1 == ae2 && ((f1 != iterationen && f2 !=iterationen )||(f1 == iterationen && f2 ==iterationen))
							 && Math.abs(f1 - f2)*4 < f1 + f2)
						feld[x][y] = (short) ((f1 + f2) / 2);
					else {
						feld[x][y] = checkC(reC, imC);
						gesIter = gesIter + feld[x][y];
					}
				}

				// Colormapping
				// Weise jedem Pixel je nach Anzahl der Iterationen bis der Betrag g��er als zwei wird eine bestimmte Farbe zu.
				int iter = feld[x][y];
				int R = 0;
				int Gr = 0;
				int B = 0;
				if (iter <= 10 * farbDarstellung)
					R = 5 + (int) (25 / farbDarstellung * iter);
				else if (iter <= 35 * farbDarstellung) {
					R = (int) (250 - 10 / farbDarstellung
							* (iter - 10 * farbDarstellung));
					Gr = (int) (10 / farbDarstellung * (iter - 10 * farbDarstellung));
				} else if (iter <= 60 * farbDarstellung) {
					Gr = (int) (250 - 10 / farbDarstellung
							* (iter - 35 * farbDarstellung));
					B = (int) (10 / farbDarstellung * (iter - 35 * farbDarstellung));
				} else if (iter <= 85 * farbDarstellung) {
					B = (int) (250 - 5 / farbDarstellung
							* (iter - 60 * farbDarstellung));
					R = (int) (10 / farbDarstellung * (iter - 60 * farbDarstellung));
				} else if (iter <= 110 * farbDarstellung) {
					R = (int) (250 - 10 / farbDarstellung
							* (iter - 85 * farbDarstellung));
					B = (int) (250 - 5 / farbDarstellung
							* (iter - 60 * farbDarstellung));
				}
				if ((imC >= -0.0017 && imC <= 0.0017 || reC >= -0.0017
						&& reC <= 0.0017)
						&& Punkt[2] == 0) {
					R = 0;
					Gr = 255;
					B = 0;
					for (double i = 0.1; i < 2.1; i += 0.1) {
						if (imC >= i - 0.0017 && imC <= i + 0.0017
								|| reC >= i - 0.0017 && reC <= i + 0.0017) {
							;
							Gr = 0;
						}
						if (-imC >= i - 0.0017 && -imC <= i + 0.0017
								|| -reC >= i - 0.0017 && -reC <= i + 0.0017) {
							;
							Gr = 0;
						}
					}

				}
				{
					Color colAppleman = new Color(R, Gr, B); // Farbe
																// Apfelm�nnchen
					g.setColor(colAppleman);
					g.drawLine(x, y, x, y);
				}
				reC = reC + zelle; // n�chste Spalte
			}
			imC = imC + zelle; // n�chste Zeile
		}
		if (wert1)
			System.out.println(gesIter / 100000);
		wert1 = false;

	}

	boolean wert1 = true;
}