import java.awt.Font;
import acm.program.*;


//Beispielpunkte:
//0.000001,-1.9
//1.03,-0.16,4,100


public class Formel extends ConsoleProgram {
	public void run() {
		while (true) {
			setFont(new Font("times new roman", Font.BOLD, 18));
			double reZ = 0, imZ = 0, reZ_minus1 = 0, imZ_minus1 = 0, imC = 0, reC = 0;
			int i = 0;
			int iterationen = 100;
			int modus = readInt("1=Verlauf, 2=Formel: ");
			String punkt = readLine("reC,imC: ");
			String[] s = punkt.split(",");
			if (s.length > 0)
				reC = Double.parseDouble(s[0]);
			if (s.length > 1)
				imC = Double.parseDouble(s[1]);
			if (s.length > 2)
				iterationen = (int) (100 + Math.log10(2)
						* Double.parseDouble(s[2]) * 50);
			if (s.length > 3)
				iterationen = (int) (Double.parseDouble(s[3]) + Math.log10(2)
						* Double.parseDouble(s[2]) * 50);
			println("\n");
			if(modus > 1)println("Es gilt:\nZn+1 = Zn * Zn + C\nZ0 = 0\n|Zn| <= 2\ni * i = -1\n");
			println("Z0 = 0\n");
			for (i = 0; i < iterationen; i++) {
				imZ = 2 * reZ_minus1 * imZ_minus1 + imC;
				reZ = reZ_minus1 * reZ_minus1 - imZ_minus1 * imZ_minus1 + reC;
				if(modus > 1)println("Z" + (i + 1) + " = " + "(" + reZ_minus1 + " + "
						+ imZ_minus1 + "i" + ")^2" + " + " + reC + " + " + imC
						+ "i");
				if(modus > 1)println("    = " + "(" + reZ_minus1 + ")^2 + " + "2*("
						+ reZ_minus1 + "*" + imZ_minus1 + "i)" + " + ("
						+ imZ_minus1 + "i" + ")^2 + " + reC + " + " + imC + "i");
				if(modus > 1)println("    = " + reZ + " + " + imZ + "i");
				println("|Z" + (i + 1) + "| = "
						+ Math.pow(reZ * reZ + imZ * imZ, 0.5) + "\n");
				if (reZ * reZ + imZ * imZ > 4) {
					if(modus > 1)println("|" + reZ + " + " + imZ + "i|");
					if(modus > 1)println("= (" + reZ + "^2 + " + imZ + "^2)^0.5");
					if(modus > 1)println("= " + Math.pow(reZ * reZ + imZ * imZ, 0.5)
							+ " > 2");
					println("n = " + i+"\n");
					break;
				} else {
					reZ_minus1 = reZ;
					imZ_minus1 = imZ;
				}
			}
			if (i == iterationen) {
				println("maxIterationen");
				println("n = " + (i) + "\n");
			}
		}
	}

	/* Standard Java entry point */
	/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new Formel().start(args);
	}
}
