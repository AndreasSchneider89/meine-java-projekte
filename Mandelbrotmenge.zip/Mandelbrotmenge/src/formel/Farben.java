package formel;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import acm.program.GraphicsProgram;


public class Farben extends GraphicsProgram {
	boolean spectrum = false;
	int wert = 30;
	int iterationen = 100;
	

	String punkt = " 0";
	double zoom2Pot = 0;
	public double[] Punkt(){
		double[] Punkt = {0,0,0,100};
	String[] s = punkt.split("\\+");
	if (s.length > 0)
		if (s[0].contains("i")){s[0] = s[0].substring(0,s[0].indexOf("i")); Punkt[0] = -Double.parseDouble(s[0]);}
		else Punkt[1] = Double.parseDouble(s[0]);
	if (s.length > 1)
		if (s[1].contains("i")){s[1] = s[1].substring(0,s[1].indexOf("i")); Punkt[0] = -Double.parseDouble(s[1]);}
		else Punkt[1] = Double.parseDouble(s[1]);
	return Punkt;}
	double[] Punkt = Punkt();
      
	
	double zoom = Math.pow(2, zoom2Pot);
	double farbDarstellung = iterationen/110.0;
	double obererRand = Punkt[0]-1.1/zoom;
	double linkerRand = Punkt[1]-2.1/zoom;
	double zelle = 0.00325/zoom;
	

	// C-Werte checken nach Zn+1 = Zn^2 + C, Zo = 0. 100 Iterationen.
	public int checkC(double reC, double imC) {
		int i = wert;
		if(spectrum) i = (int) ((reC+2.1)*25);
		return i;
	}

	// Punkte berechnen und setzen.
	public void paint(Graphics g) {
		double reC, imC; 
		int x, y;

		imC = obererRand; // oberer Rand
		for (y = 0; y < 1000; y++) {
			reC = linkerRand; // linker Rand
			for (x = 0; x < 1500; x++) {
				int R = 0;
				int Gr = 0;
				int B = 0;
				if (checkC(reC, imC) <= 10*farbDarstellung) R=5+(int) (25/farbDarstellung * checkC(reC, imC));
				else if (checkC(reC, imC) <= 35*farbDarstellung){R=(int) (250-10/farbDarstellung*(checkC(reC, imC)-10*farbDarstellung)); Gr=(int) (10/farbDarstellung*(checkC(reC, imC)-10*farbDarstellung));}
				else if (checkC(reC, imC) <= 60*farbDarstellung){Gr=(int) (250-10/farbDarstellung*(checkC(reC, imC)-35*farbDarstellung)); B=(int) (10/farbDarstellung*(checkC(reC, imC)-35*farbDarstellung));}
				else if (checkC(reC, imC) <= 85*farbDarstellung){B=(int) (250-5/farbDarstellung*(checkC(reC, imC)-60*farbDarstellung)); R=(int) (10/farbDarstellung*(checkC(reC, imC)-60*farbDarstellung));}
				else if (checkC(reC, imC) <= 110*farbDarstellung){R=(int) (250-10/farbDarstellung*(checkC(reC, imC)-85*farbDarstellung));B=(int) (250-5/farbDarstellung*(checkC(reC, imC)-60*farbDarstellung));}
//				if ((imC >=-0.0017 && imC <= 0.0017 || reC >= -0.0017 &&reC <= 0.0017) && zoom2Pot == 0)  {R = 0;
//				 Gr = 255;
//				 B = 0;
//				 for(double i = 0.1; i<2.1; i+=0.1){
//					 if(imC >=i-0.0017 && imC <= i+0.0017 || reC >= i-0.0017 &&reC <= i+0.0017)
//					 {;Gr=0;}
//					 if(-imC >=i-0.0017 && -imC <= i+0.0017 || -reC >= i-0.0017 &&-reC <= i+0.0017)
//					 {;Gr=0;}
//				 }}
				
				
				
				
					{Color colAppleman = new Color(R, Gr, B); // Farbe Apfelm�nnchen
					g.setColor(colAppleman);
					g.drawLine(x, y, x, y);
				}
				reC = reC + zelle; // n�chste Spalte
			}
			imC = imC + zelle; // n�chste Zeile
		}
		
		
		
	}
}