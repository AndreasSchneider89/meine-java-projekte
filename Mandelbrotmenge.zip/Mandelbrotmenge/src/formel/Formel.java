package formel;

import java.awt.Font;
import acm.program.*;


public class Formel extends ConsoleProgram {
	public void run() {
		Bild b = new Bild();
			setFont(new Font("times new roman", Font.BOLD, 18));
			double reZ = 0, imZ = 0, reZ_minus1 = 0, imZ_minus1 = 0, imC = -b.Punkt[0], reC = b.Punkt[1];90i8
			int i = 0;
			int iterationen = b.iterationen;
			int modus = 2;
			// modus = readInt("1=Verlauf, 2=Formel: ");
			//println("\n");
			if(modus > 1)println("Es gilt:\nZn+1 = Zn * Zn + C\nZ0 = 0\n|Zn| <= 2\ni * i = -1\n");
			println("Z0 = 0\n");
			for (i = 0; i < iterationen; i++) {
				imZ = 2 * reZ_minus1 * imZ_minus1 + imC;
				reZ = reZ_minus1 * reZ_minus1 - imZ_minus1 * imZ_minus1 + reC;
				if(modus > 1)println("Z" + (i + 1) + " = " + "(" + reZ_minus1 + " + "
						+ imZ_minus1 + "i" + ")^2" + " + " + reC + " + " + imC
						+ "i");
				if(modus > 1)println("    = " + "(" + reZ_minus1 + ")^2 + " + "2*("
						+ reZ_minus1 + "*" + imZ_minus1 + "i)" + " + ("
						+ imZ_minus1 + "i" + ")^2 + " + reC + " + " + imC + "i");
				if(modus > 1)println("    = " +  reZ_minus1*reZ_minus1 +" + "+ 2*
						 reZ_minus1  *imZ_minus1 + "i" + " + "+
						 -imZ_minus1*imZ_minus1 + " + "+ reC + " + " + imC + "i");
				if(modus > 1)println("    = " + reZ + " + " + imZ + "i");
				if(modus > 1)println("|Z" + (i + 1) + "| = "+"(" + reZ + "^2 + " + imZ + "^2)^0.5");
				println("      ="+ Math.pow(reZ * reZ + imZ * imZ, 0.5) + "\n");
				if (reZ * reZ + imZ * imZ > 4) {
					if(modus > 1)println(Math.pow(reZ * reZ + imZ * imZ, 0.5)
							+ " > 2");
					println("n = " + i);
					if((double)i/iterationen==0) println("schwarz");
					else if((double)i/iterationen==0 || (double)i/iterationen <= 0.19) println("rot");
					else if((double)i/iterationen==0 || (double)i/iterationen <= 0.41) println("gr�n");
					else if((double)i/iterationen==0 || (double)i/iterationen <= 0.62) println("blau");
					else if((double)i/iterationen==0 || (double)i/iterationen <= 0.98) println("lila");
					else println("schwarz");
					
					break;
				} else {
					reZ_minus1 = reZ;
					imZ_minus1 = imZ;
				}
			}
			if (i == iterationen) {
				println("maxIterationen");
				println("n = " + (i));
				println("schwarz");
			}
		}
	

	/* Standard Java entry point */
	/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new Formel().start(args);
	}
}
