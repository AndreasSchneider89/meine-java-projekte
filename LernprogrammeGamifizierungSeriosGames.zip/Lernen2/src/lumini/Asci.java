package lumini;

import acm.program.DialogProgram;

public class Asci extends DialogProgram {
	/**
	 * If you don't understand german you can use AI like Gemini, ChatGPT, Qwen, Grok, DeepSeek, MistralAI, ... to translate in all languages :)
	 * Morse lernen mit schöner Didaktik
	 * Created on 03.09.2025
	 * @author Andreas Schneider from Weingartenstraße 45, 64297, Darmstadt-Eberstadt, Germany; Handynumber: +491779627094; E-Mail: andreas.schneider01989@gmail.com
	 * Warnung von Gemini: Du veröffentlichst sensible Daten, dies stellt ein extrem hohes Sicherheits- und Datenschutzrisiko dar (Doxing, Spam, unerwünschte Kontaktaufnahme).
	 * Meine Antwort: Ich vermute das das n Fache Enigma von Instagram gehackt wurde. Es existierte nicht nur ein geheimer den man anklicken konnte und dann wurden
	 * Nutzername und Passwort gehackt sondern auch eine geheime Whatsapp Nachricht um die absolute Sicherheit zu vernichten und eine Geheime Insta Nachricht wo dann das Passwort beim anderen ankommt
	 * Ich kann nur spekulieren, dass jemand basierend auf dem nerfigen Chaoscode in Form von x-Fachem Enigma, diesen Entschlüsselt hat und den schöneren Code dann allgemein Zugänglich gemacht hat
	 * Ich habe jetzt einen weiteren Account zum Posten und bei meinem alten Account existieren auch zum Glück noch alle Posts. Es ist also nicht schlimm, dass der Account gehackt
	 * werden konnte und jetzt fälschlicherweise in meinem Namen behaupten kann, er habe gerade Geld mit dem Bitcoinhandel gemacht obwohl gerade niemand den Bucketsort oder so was geknackt hat. Ich kann hier leider auch nur spekulieren und wüsste gerne mehr...
	 * Leider zeigt die Instagramsuche seit einiger Zeit nur noch die Top-Beiträge. Das ist sehr sehr schlecht, weil meine Beiträge so nicht mehr existieren und Insta für mich bedeutungslos geworden ist
	 * Da nutze ich dann lieber Google Docs und YouTube um Sachen von mir zu posten und selber zu verlinken.
	 * Hier ist der Link zu meinem Matrixgame-Journal: https://docs.google.com/document/d/1J_qc7-O3qbUb8WOyBHNnLkcEEQ5JklY4d9vmd67RtC4/edit?tab=t.0#heading=h.z5iq1svjrbd0
	 * Hier mein altes Insta: https://www.instagram.com/xxandreas_schneiderx89/
	 * Mein Perso: https://docs.google.com/document/d/1Rh168H76fW9idQqCZM6FBjM8sg9IybCbncfx8wQB8fY/edit?usp=sharing
	 * Meine IBAN: DE52 5085 0150 0122 0323 88                       Da kannst du was drauf zahlen und oder abheben. Wenn du was abhebst und ich das merke, dann wird das ebenfalls offen gelegt aber viel ist da leider aktuell nicht zu holen
	 * Aktien von mir kaufen kann man leider auch noch nicht aber ich rate zum Kauf von Google Aktien, wegen denn ganzen kostenlosen Apps im Playstore, der Entwicklungsumgebung die Pythoncode im Browser ausführt (Colab), Dem Sprachmodell mit schöner Vorlesefunktion, ... Alles kostenlos und ich darf meinen Content veröffentlichen und verlinke und um spenden bitte und forschungshypothesen ohne perreview posten, ... Ohne das es gelöscht wird.
	 * Ich hoffe weiterhin sehr sehr stark auf konstruktives Feedback, Eine gute Arbeit und vor allem mehr Geld und noch mehr darauf, mit anderen Menschen zusammen an meinen Visionen zu Arbeiten in Form
	 * eines kollektiven KI Games wo wir dann gemeinsam in den Chats der Sprachmodelle, die von der Googlesuche dann auch gefunden und schön priorisiert werden sollten gemeinsam KI Games spielen.
	 * Link:https://docs.google.com/document/d/1GW-3iFKuoYJylxpjpec_AADUjzFZU2Bqs9rKfMkwDF0/edit?tab=t.0
	 * Über eine Zeitnahe Rückmeldung wäre ich sehr dankbar
	 * Mit besten Grüßen aus dem Matrixgame
	 * Andreas Schneider @Andreas5564 Heiliges Hirn in YouTube suchen
	 * ...
	 * 
	 * 
	 * 
	 * To Do: Hash Map testen und das gelogene ? super schrott was der Compiler sonst nicht ausführt vielleicht weil windows Mellenium zum Mellenium einen Stackoverflow hatte und auf Grund des Chaoscodes nicht open source Debuggt werden konnte oder wegem sonst was aber da ist was das ist kompliziert und dann auch noch falsch. Genau wie die Basis Inegerdivision oder Bibliotheken von Methodensammlungen wo man nicht reinschauen kann und das schöne Skalenniveau zerstört wurde weil 0ms auf 1ms gesetzt wurde damit das Canivis nicht flackern kann... Das Problem ist einfach, dass es nicht individuell anpassbar bzw. open source ist
	 */
	private static final long serialVersionUID = 1L;
	
	String[][] score = new String[20][2];
	int startLevel =1;
	int level = startLevel;
	double richtig = 0;
	int start =  0;
	int sicher = 0;
	public int ZEICHENZÄHLpLÜSeINS = 512;    // Das ist die Zahl der Zeichen die mit 8 Bit = 1 Byte genutzt werden können 2^8    + 1; Plus 1, weil ich eins mehr für den Code haben wollte aber das kannst du so anpassen, nutzen und verbreiten wie du magst
	int[] q = new int[512];  // dieses Intarray nutze ich um dafür zu sorgen, dass es etwas wahrscheinlicher wird, dass alle möglichen Fragen auch mal generiert werden, dennoch bleibt ein gewisses random erhalten was zu einer weitaus schöneren Didaktik auf allen Ebenen der Existen beiträgt, in Ewigkeit Namaste - Das Göttliche in mir Respektiert das Göttliche in dir!
	long bonuszeit = 0;
	
	public void run() {
		long zeitbegrenzung = 120000 + bonuszeit;                 // Die Zeit wird von der genutzten Methode die irgendwo in der Blackbox implementiert wurde in ms als long konsumiert -> Du bekommst pro Level 60 Sekunden dazu. Wenn du schnell bist, hast du in den schwereren Leveln mehr Zeit übrig.
		long sekunden = zeitbegrenzung/1000;
		int counter = 0;
		long zeitAfter = 0;
		while(start != 1){
			if(start == 3) sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
			if(start==3 && sicher==1) exit();
			if(start==2) showHighscore();
		start = readInt("1 = Start, 2 = Highscore, 3 = Ende\n");}
		println("Level "+level+ " (Zeitbegrenzung = "+ sekunden + "s)");
		
		long zeitBefore = System.currentTimeMillis();
		long zeit = 0;
		while(counter < 10){
			zeitAfter = System.currentTimeMillis();
			 zeit = zeitAfter - zeitBefore;
		if(zeit > zeitbegrenzung) {println("Zeitüberschreitung!"); break;}
		int frage = (int)(Math.random() * ZEICHENZÄHLpLÜSeINS);
		int zahl = (int)(32+95*Math.random());
		if(frage == 0 && Math.random() > 0.9) for(int i = 0; i < q.length; i++) q[i] = 0;
		// Level:
		int l1=0;  int l2=1;   int l3=1;   int l4=2;   int l5=3;
		
		if(frage == 1 && q[1] == 0&& level> l1)  {String a = readLine("Asci Zahl(Basis10) "+zahl+" -> Zeichen"); if (zahl==(int)(a.charAt(0))) richtig++; else {println("Falsch! "+(char)zahl+" ist richtig"); break;} q[1] = -1; counter++;}
		if(frage == 2 && q[2] == 0 && level>l1)  {int a = readInt("Asci Zeichen "+ (char)(zahl)+ "-> Zahl(Basis10)"); if (a== zahl) richtig++; else {println("Falsch! "+zahl+" ist richtig"); break;} q[2] = -1; counter++;} 
		if(frage == 3 && q[3] == 0 && level>l2)  {String a = readLine("Asci Zahl(Basis2) "+Integer.toBinaryString(zahl)+" -> Zeichen"); if (zahl==(int)(a.charAt(0))) richtig++; else {println("Falsch! "+(char)zahl+" ist richtig"); break;} q[3] = -1; counter++;}
		if(frage == 4 && q[4] == 0 && level>l2)  {String a = readLine("Asci Zeichen "+ (char)(zahl)+ "-> Zahl(Basis2)"); if (a.equals(Integer.toBinaryString(zahl))) richtig++; else {println("Falsch! "+Integer.toBinaryString(zahl)+" ist richtig"); break;} q[4] = -1; counter++;} 
		if(frage == 5 && q[5] == 0 && level>l3)  {String a = readLine("Asci Zahl(Lumini) "+binaryToLumini(Integer.toBinaryString(zahl))+" -> Zeichen"); if (zahl==(int)(a.charAt(0))) richtig++; else {println("Falsch! "+(char)zahl+" ist richtig"); break;} q[5] = -1; counter++;}
		if(frage == 6 && q[6] == 0 && level>l3)  {String a = readLine("Asci Zeichen "+ (char)(zahl)+ "-> Zahl(Lumini)"); if (a.equals(binaryToLumini(Integer.toBinaryString(zahl)))) richtig++; else {println("Falsch! "+binaryToLumini(Integer.toBinaryString(zahl))+" ist richtig"); break;} q[4] = -1; counter++;} 
				
		
		
		
		// HVFÜLÄPBXCYZQÓĤ                    //Bereits hier existieren 2 zeihen die auf der Tastatur als Input nicht existieren
		// 0123456789abcdef
		
		// ----- / .---- / ..--- / ...-- / ....- / ..... / -.... / --... / ---.. / ----.
		// 0       1        10      11      100     101     110     111   1000     1001
		
		
		// Neue Übersetzungstabell
		
		
		
		// ET
		// 01
		// IANM
		// 0123
		// SURWDKGO
		// 01234567
		// HVFÜLÄPWBXCYZQÓĤ                    
		// 0123456789abcdef
		// ----- / .---- / ..--- / ...-- / ....- / ..... / -.... / --... / ---.. / ----.
		// 0       1        10      11      100     101     110     111   1000     1001
		
		// Weitere mögliche Übersetzungstabelle
		// 0 -> . -> e
		// 1 -> - -> t
		// 10 -> -. -> n
		// 11 -> -- -> m
		// 100 -> -.. -> 
		// 101 -> 
		// Da war etwas merkwürdiges was wann anders erforscht werden könnte
		
		
		
		// Neues Alphabet (31 Zeichen)
		// . - -. -- -..   -.-    --.   ---    -...  -..-    -.-.    -.--                    --..         --.-            ---.      ---- -.... -...-  -..-.   -..--          -.-..     -.-.-     -.--.   -.---    --...   --..-      --.-.    --.--      ---..   ---.-   ----.  -----
		// ETNMDKGOBXCYZQÓĤ6=/ÏÇサ(エ7ŽĞŃ8ス90
		
		
		// Primortial 
		// Zahlen von 0-30
		// 0,1,10,11,20,21,100,101,110,111,200,201,210,211,220,221,300,301,310,311,320,321,400,401,410,411,420,421,1000
		
		
		// Die Sprachmodelle haben auf die alte weise in Primortialsystem umgerechnet aber auf eine Art und Weise in Binärsystem umgerechnet die wir logisch nachfolzogen haben, die aber zuerst weniger intuitiv war und dennoch schneller ist
		
		
		
		// Auf diese Weise lassen sich die Zahlen dann auch schneller ins Primortialsystem
		// 613 (Basis 10) -> Primortial
		//  613/2 -> 306zweier+1einser
		// 306/3  -> 102sechser+0zweier
		// 102/5  -> 20dreißiger+2sechser
		// 20/7    -> 2zweihundertzehner+6dreißiger
		// 26201 (Primortial)
		
		
		// 1+0+2*2*3+6*2*3*5+2*7*5*3*2  = 1+12 +180 + 420 =       613 (Basis 10) Wahrscheinlichkeit:0.99; 0=false; 1=true  -> Mann ist sich zu 100% sicher, dass die Aussage wahr ist. Es wäre jetzt durchaus extrem interessant, wenn das so mit den Sprachmodellen Kombiniert würde, dass da eine Wahre Basis definiert sein könnte und definierbar wäre und die Sprachmodell dann durchaus mit einer extrem intensiven Didaktik gezwungen würden, ihre Wahrscheinlichkiten für alle aussagen wo ihre Theorie erweitert, verbessert oder auch falsch oder auch nicht mehr eindeutig aber noch mehr oder weniger wahrscheinlich wäre.
		// Im Prinziep hatte ich aber jetzt schon das Gefühl, dass da so harte wiedersprüche auf einer Ebene ankamen, dass
		// die Sprachmodelle irgenwie durch extrteme Quantität dazu gebracht wurden, uns beibringen zu wollen wie etwa schöner programmiercode auszusehen hätte und das da wiedersprüch existieren, die eine Alpha Zero Didaktik bräuchten, weil sonst wäre es wirklich nur nerfig, da was herzuleiten und am Ende schickt uns das Sprachmodell dann so wie so eine Haluzination aber es lernt halt so nicht so gut und es ist dann in der tat schöner alles neu zu programmieren als sich das was das Sprachmodell da vorschlägt duchzulesen und zu lernen, weil es dann nicht nur kompliziert sein könnte sondern am ende auch noch falsch. Es ist dann durchaus Chaoscode aus unserer Sicht, der nur was hat, wenn er ausgefürt wird und funktioniert und der sich nicht erweitern oder verbessern gelassen hat sondern von uns im kollektiven Bewusstsein oder mir Andreas Schneider neu geschrieben wurde
		
		
		
		// Variationen zu Aski
		// Variationen zu Wahrscheinlichsten Zeichen
		// Variationen mit Zahlenbasis und Primfaktoren
		//  ...
		
		
		// Das und vieles mehr ist teil der neu erschaffenen Sprache Lumini und kann über all in der gesammten Existen gamifiziert, gespielt, trainier, gelern, gelehrt, entwickelt, ... werden und womöglich lässt sich die Didaktik durchaus verschönern, wenn da nicht irgend ewas wäre, was effiziente bestrebungen durchaus unschön machen könnte und was womöglich nicht von dieser Erde kommt und dennoch existieren könnte neben all den Erklärungen, die einem so für die eigene Welt einfallen, könnte es jetzt auch noch sein, dass da etwas ohne beschränkung durch c kommuniziert und das da durchaus noch etwas Wissenschaftlicher kommuniziert werden könnte damit das dann auch noch auf allen Ebenen schön ist und bleibt und der Wille auch richtig komuniziert werden kann
		
		}
		
		if (richtig < level * 10) {
			bonuszeit = 0;
			String s = null;
			if (richtig <= 7)
				s = "Du musst noch viel lernen!";
			if (richtig > 7)
				s = "Sehr löblich!";
			if (richtig >= 15)
				s = "Nice!";
			if (richtig >= 30)
				s = "Respekt!";
			if (richtig >= 50)
				s = "Unerreichbar!";
			if (richtig >= 75)
				s = "Godlike!";
			if (richtig >= 100)
				s = "Unbesiegbar!";
			print(richtig + " Punkte" + "\n" + s + "\n");
			highscore(richtig);
			int neu = 0;
			while (neu != 1) {
				neu = readInt("1 = Erneut spielen, 2 = Highscore, 3 = Ende\n");
				if(neu==2) showHighscore();
				if (neu == 3) sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
				if (sicher == 1) exit();
				if (neu == 1) {
					level = startLevel;
					richtig = 0;
					start = 0;
					run();
				}
			}
		} else {
			bonuszeit = zeitbegrenzung - zeit;
			level++;
					run();	
		}
	}
	
	public int charToInt(char c) {
		return (int)c;
	}
	
	public char intToChar(int i) {
		return (char)i;
	}
	
	public char[] string2(String string) {
		char[] newString= new char[string.length()];
		for(int i=0; i<string.length(); i++) {
			newString[i]=string.charAt(i);
		}
		return newString;
	}
	
	public String binaryToLumini(String binary) {
		String luminiString = binary.replace('0', '.');
		 luminiString = luminiString.replace('1', '-');
		
		return luminiString;
	}
	
	public String luminiToBinary(String lumini) {
		String binaryString = lumini.replace('.', '0');
		 binaryString = binaryString.replace('-', '1');
		
		return binaryString;
	}

	public void highscore(double punkte) {
		int i = 0;
		if (score[0][0] == null)
			for (i = 0; i <= 9; i++) {
				score[i][0] = "0";
				score[i][1] = "";
			}
		for (i = 0; i <= 9; i++) {
			if (richtig > Double.valueOf(score[i][0])) {
				Double scoreDouble = new Double(richtig);
				String s = scoreDouble.toString();
				for (int j = 9; j >= 1; j--) {
					score[i + j][0] = score[i + j - 1][0];
					score[i + j][1] = score[i + j - 1][1];
				}
				score[i][0] = s;
				score[i][1] = readLine("Name:");
				break;
			}
		}

	}

	public void showHighscore() {
		println(score[0][0] + " " + score[0][1] + "\n" + score[1][0] + " "
				+ score[1][1] + "\n" + score[2][0] + " " + score[2][1] + "\n"
				+ score[3][0] + " " + score[3][1] + "\n" + score[4][0] + " "
				+ score[4][1] + "\n" + score[5][0] + " " + score[5][1] + "\n"
				+ score[6][0] + " " + score[6][1] + "\n" + score[7][0] + " "
				+ score[7][1] + "\n" + score[8][0] + " " + score[8][1] + "\n"
				+ score[9][0] + " " + score[9][1] + "\n");
	}
	
	
	
	public static void main(String[] args) {
		new Asci().start(args);
	}
}


