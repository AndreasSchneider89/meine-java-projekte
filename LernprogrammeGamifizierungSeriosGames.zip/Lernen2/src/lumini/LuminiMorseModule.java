package lumini;

import java.util.HashMap;
import java.util.Map;

public class LuminiMorseModule {
    
    private static final Map<Character, String> TEXT_TO_MORSE = new HashMap<>();
    private static final Map<String, Character> MORSE_TO_TEXT = new HashMap<>();
    private int motivationPoints = 0;

    static {
        // Morse alphabet
        TEXT_TO_MORSE.put('A', ".-");
        TEXT_TO_MORSE.put('B', "-...");
        TEXT_TO_MORSE.put('C', "-.-.");
        TEXT_TO_MORSE.put('D', "-..");
        TEXT_TO_MORSE.put('E', ".");
        TEXT_TO_MORSE.put('F', "..-.");
        TEXT_TO_MORSE.put('G', "--.");
        TEXT_TO_MORSE.put('H', "....");
        TEXT_TO_MORSE.put('I', "..");
        TEXT_TO_MORSE.put('J', ".---");
        TEXT_TO_MORSE.put('K', "-.-");
        TEXT_TO_MORSE.put('L', ".-..");
        TEXT_TO_MORSE.put('M', "--");
        TEXT_TO_MORSE.put('N', "-.");
        TEXT_TO_MORSE.put('O', "---");
        TEXT_TO_MORSE.put('P', ".--.");
        TEXT_TO_MORSE.put('Q', "--.-");
        TEXT_TO_MORSE.put('R', ".-.");
        TEXT_TO_MORSE.put('S', "...");
        TEXT_TO_MORSE.put('T', "-");
        TEXT_TO_MORSE.put('U', "..-");
        TEXT_TO_MORSE.put('V', "...-");
        TEXT_TO_MORSE.put('W', ".--");
        TEXT_TO_MORSE.put('X', "-..-");
        TEXT_TO_MORSE.put('Y', "-.--");
        TEXT_TO_MORSE.put('Z', "--..");
        TEXT_TO_MORSE.put(' ', "/"); // Wort-Trenner

        // Umkehrabbildung
        for (Map.Entry<Character, String> entry : TEXT_TO_MORSE.entrySet()) {
            MORSE_TO_TEXT.put(entry.getValue(), entry.getKey());
        }
    }

    // LuminiInput: Klartext → Morse
    public String toMorse(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toUpperCase().toCharArray()) {
            if (TEXT_TO_MORSE.containsKey(c)) {
                sb.append(TEXT_TO_MORSE.get(c)).append(" ");
            }
        }
        // Belohnung: Motivation für erfolgreiches Übersetzen
        motivationPoints += text.split(" ").length;
        return sb.toString().trim();
    }

    // LuminiOutput: Morse → Klartext
    public String fromMorse(String morse) {
        StringBuilder sb = new StringBuilder();
        String[] codes = morse.split(" ");
        for (String code : codes) {
            if (MORSE_TO_TEXT.containsKey(code)) {
                sb.append(MORSE_TO_TEXT.get(code));
            } else if (code.equals("/")) {
                sb.append(" ");
            }
        }
        // Belohnung: Motivation für erfolgreiches Entschlüsseln
        motivationPoints += morse.split("/").length;
        return sb.toString();
    }

    // Gamification: Punkte anzeigen
    public int getMotivationPoints() {
        return motivationPoints;
    }

    public static void main(String[] args) {
        LuminiMorseModule lumini = new LuminiMorseModule();

        // Beispiel: LuminiInput
        String text = "Matrix Lumini Game";
        String morse = lumini.toMorse(text);
        System.out.println("Klartext: " + text);
        System.out.println("→ Morse: " + morse);

        // Beispiel: LuminiOutput
        String decoded = lumini.fromMorse(morse);
        System.out.println("→ Zurück: " + decoded);

        // Motivation
        System.out.println("Motivationspunkte: " + lumini.getMotivationPoints());
    }
}
