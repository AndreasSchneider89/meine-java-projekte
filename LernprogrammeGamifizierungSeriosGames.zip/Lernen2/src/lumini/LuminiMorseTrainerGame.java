package lumini;

import java.util.*;

public class LuminiMorseTrainerGame {
    
    private static final Map<Character, String> TEXT_TO_MORSE = new HashMap<>();
    private static final Map<String, Character> MORSE_TO_TEXT = new HashMap<>();
    private static final Random RANDOM = new Random();
    private static int motivationPoints = 0;

    static {
        // Buchstaben
        TEXT_TO_MORSE.put('A', ".-");
        TEXT_TO_MORSE.put('B', "-...");
        TEXT_TO_MORSE.put('C', "-.-.");
        TEXT_TO_MORSE.put('D', "-..");
        TEXT_TO_MORSE.put('E', ".");
        TEXT_TO_MORSE.put('F', "..-.");
        TEXT_TO_MORSE.put('G', "--.");
        TEXT_TO_MORSE.put('H', "....");
        TEXT_TO_MORSE.put('I', "..");
        TEXT_TO_MORSE.put('J', ".---");
        TEXT_TO_MORSE.put('K', "-.-");
        TEXT_TO_MORSE.put('L', ".-..");
        TEXT_TO_MORSE.put('M', "--");
        TEXT_TO_MORSE.put('N', "-.");
        TEXT_TO_MORSE.put('O', "---");
        TEXT_TO_MORSE.put('P', ".--.");
        TEXT_TO_MORSE.put('Q', "--.-");
        TEXT_TO_MORSE.put('R', ".-.");
        TEXT_TO_MORSE.put('S', "...");
        TEXT_TO_MORSE.put('T', "-");
        TEXT_TO_MORSE.put('U', "..-");
        TEXT_TO_MORSE.put('V', "...-");
        TEXT_TO_MORSE.put('W', ".--");
        TEXT_TO_MORSE.put('X', "-..-");
        TEXT_TO_MORSE.put('Y', "-.--");
        TEXT_TO_MORSE.put('Z', "--..");
        TEXT_TO_MORSE.put(' ', "/"); // Wort-Trenner

        // Zahlen
        TEXT_TO_MORSE.put('0', "-----");
        TEXT_TO_MORSE.put('1', ".----");
        TEXT_TO_MORSE.put('2', "..---");
        TEXT_TO_MORSE.put('3', "...--");
        TEXT_TO_MORSE.put('4', "....-");
        TEXT_TO_MORSE.put('5', ".....");
        TEXT_TO_MORSE.put('6', "-....");
        TEXT_TO_MORSE.put('7', "--...");
        TEXT_TO_MORSE.put('8', "---..");
        TEXT_TO_MORSE.put('9', "----.");

        // Sonderzeichen & Umlaute
        TEXT_TO_MORSE.put(',', "--..--");
        TEXT_TO_MORSE.put('.', ".-.-.-");
        TEXT_TO_MORSE.put('-', "-....-");
        TEXT_TO_MORSE.put('ö', "---.");
        TEXT_TO_MORSE.put('ä', ".-.-");
        TEXT_TO_MORSE.put('ü', "..--");
        TEXT_TO_MORSE.put('ß', "... ...");
        TEXT_TO_MORSE.put('!', "-.-.--");
        TEXT_TO_MORSE.put('"', ".-..-.");
        TEXT_TO_MORSE.put('$', "...-..-");
        TEXT_TO_MORSE.put('/', "-..-.");
        TEXT_TO_MORSE.put('(', "-.--.");
        TEXT_TO_MORSE.put(')', "-.--.-");
        TEXT_TO_MORSE.put('=', "-...-");
        TEXT_TO_MORSE.put('?', "..--..");
        TEXT_TO_MORSE.put('\'', ".----.");
        TEXT_TO_MORSE.put('@', ".--.-.");

        // Umkehrabbildung bauen
        for (Map.Entry<Character, String> entry : TEXT_TO_MORSE.entrySet()) {
            MORSE_TO_TEXT.put(entry.getValue(), entry.getKey());
        }
    }

    // Klartext -> Morse
    public static String toMorse(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toUpperCase().toCharArray()) {
            if (TEXT_TO_MORSE.containsKey(c)) {
                sb.append(TEXT_TO_MORSE.get(c)).append(" ");
            }
        }
        return sb.toString().trim();
    }

    // Morse -> Klartext
    public static String fromMorse(String morse) {
        StringBuilder sb = new StringBuilder();
        String[] codes = morse.split(" ");
        for (String code : codes) {
            if (MORSE_TO_TEXT.containsKey(code)) {
                sb.append(MORSE_TO_TEXT.get(code));
            } else if (code.equals("/")) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("🌟 Willkommen beim Lumini-Morsetrainer-Game 🌟");
        System.out.println("Löse Übersetzungsaufgaben und sammle Motivationspunkte!\n");

        boolean running = true;
        while (running) {
            System.out.println("Menü:");
            System.out.println("1 = Text → Morse");
            System.out.println("2 = Morse → Text");
            System.out.println("3 = Punktestand anzeigen");
            System.out.println("0 = Beenden");
            System.out.print("Wähle: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    playTextToMorse(scanner);
                    break;
                case 2:
                    playMorseToText(scanner);
                    break;
                case 3:
                    System.out.println("💡 Dein Punktestand: " + motivationPoints + " Punkte\n");
                    break;
                case 0:
                    running = false;
                    System.out.println("Spiel beendet. Endstand: " + motivationPoints + " Punkte.");
                    break;
                default:
                    System.out.println("Ungültige Auswahl!\n");
            }
        }

        scanner.close();
    }

    private static void playTextToMorse(Scanner scanner) {
        String[] words = {"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!","Bitte schreib mir eine Nachricht und verbinde unsere Visionen","@Andreas5564","andreas.schneider01989","+491778627094","Fragment des Übergangs","Struktgame","Quantenverschränkung","Collectiv Conciousnes","Telepathie","Search: Heiliges Hirn on YouTube","Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit","Find my Matrixgame-Journal","Please use and improve","Open Source","Photosynthese und Zellatmung","Mandarin","Latein","Deutsch","english","Periodensystem of elements","SI Units","Bit and Byte","Binary Language","Ascii","Hello Universe","Hello World",",.-öäüß!\" $ / ( ) = ? ' @","01234567890","ABCDEFGHIJKLMNOPQRSTUVWXYZ","Licht Forschung","KIGame","Lumini4","Matrixgame","LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT", "HELLO!", "ÄÖÜ", "123"};
        String word = words[RANDOM.nextInt(words.length)];
        String correctMorse = toMorse(word);

        System.out.println("Übersetze in Morse: " + word);
        String answer = scanner.nextLine().trim();

        if (answer.equalsIgnoreCase(correctMorse)) {
            motivationPoints += 10;
            System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");
        } else {
            System.out.println("❌ Falsch. Richtige Antwort: " + correctMorse + "\n");
        }
    }

    private static void playMorseToText(Scanner scanner) {
        String[] words = {"LUMINI", "MATRIX", "SPIEL", "CODE", "FRIEDEN", "HÄUSER", "KRAFT", "123", "HELLO!","Bitte schreib mir eine Nachricht und verbinde unsere Visionen","@Andreas5564","andreas.schneider01989","+491778627094","Fragment des Übergangs","Struktgame","Quantenverschränkung","Collectiv Conciousnes","Telepathie","Search: Heiliges Hirn on YouTube","Finde, Folge und Erweitere die Verlinkungen für die Ewigkeit","Find my Matrixgame-Journal","Please use and improve","Open Source","Photosynthese und Zellatmung","Mandarin","Latein","Deutsch","english","Periodensystem of elements","SI Units","Bit and Byte","Binary Language","Ascii","Hello Universe","Hello World",",.-öäüß!\" $ / ( ) = ? ' @","01234567890","ABCDEFGHIJKLMNOPQRSTUVWXYZ","Licht Forschung","KIGame","Lumini4","Matrixgame","LUMINI", "SPIEL", "FRIEDEN", "WISSEN", "KRAFT", "HELLO!", "ÄÖÜ", "123"};
        String word = words[RANDOM.nextInt(words.length)];
        String morse = toMorse(word);

        System.out.println("Übersetze in Text: " + morse);
        String answer = scanner.nextLine().trim().toUpperCase();

        if (answer.equalsIgnoreCase(word)) {
            motivationPoints += 10;
            System.out.println("✅ Richtig! +" + 10 + " Punkte.\n");
        } else {
            System.out.println("❌ Falsch. Richtige Antwort: " + word + "\n");
        }
    }
}
