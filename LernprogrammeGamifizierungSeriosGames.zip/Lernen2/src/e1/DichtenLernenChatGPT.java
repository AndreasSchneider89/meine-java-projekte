package e1;

import java.util.*;
import acm.program.DialogProgram;

public class DichtenLernenChatGPT extends DialogProgram {
    private static final long serialVersionUID = 1L;

    // Datenstruktur für die Fragen: Name -> Dichte
    private static final Map<String, Double> dichten = new LinkedHashMap<>();
    static {
        dichten.put("Eisen", 7.87);
        dichten.put("Aluminium", 2.7);
        dichten.put("Kupfer", 8.92);
        dichten.put("Silber", 10.49);
        dichten.put("Zinn", 7.26);
        dichten.put("Platin", 21.45);
        dichten.put("Gold", 19.32);
        dichten.put("Blei", 11.35);
        dichten.put("Natrium", 0.97);
        dichten.put("Magnesium", 1.74);
        dichten.put("Kalium", 0.86);
        dichten.put("Chrom", 7.14);
        dichten.put("Wasser", 1.0);
        dichten.put("Kohlenstoff", 2.26);
        dichten.put("Sauerstoff", 0.0014);
        dichten.put("Helium", 0.00018);
        dichten.put("Wasserstoff", 0.00009);
        dichten.put("Neon", 0.0009);
        dichten.put("Titan", 4.5);
        dichten.put("Schwefel", 2.07);
        // ➕ Weitere Elemente lassen sich hier einfach hinzufügen
    }

    private int level = 1;
    private double richtig = 0;

    public void run() {
        println("Level " + level + " – gib die Dichten ein!");
        List<String> elemente = new ArrayList<>(dichten.keySet());
        Collections.shuffle(elemente); // zufällige Reihenfolge

        int counter = 0;
        for (String name : elemente) {
            if (counter >= 10) break; // nur 10 Fragen pro Runde

            double antwort = readDouble("Dichte von " + name + ": ");
            double korrekt = dichten.get(name);

            if (Math.abs(antwort - korrekt) < 0.0001) {
                println("✅ Richtig!");
                richtig++;
            } else {
                println("❌ Falsch! Richtig wäre: " + korrekt);
                break; // Runde beenden bei Fehler
            }
            counter++;
        }

        println("Du hast " + richtig + " richtige Antworten geschafft.");
        bewertung();
    }

    private void bewertung() {
        if (richtig <= 7) println("Du musst noch viel lernen!");
        else if (richtig > 7 && richtig < 15) println("Sehr löblich!");
        else if (richtig >= 15 && richtig < 30) println("Nice!");
        else if (richtig >= 30 && richtig < 50) println("Respekt!");
        else if (richtig >= 50 && richtig < 75) println("Unerreichbar!");
        else if (richtig >= 75 && richtig < 100) println("Godlike!");
        else if (richtig >= 100) println("Unbesiegbar!");
    }

    public static void main(String[] args) {
        new DichtenLernenChatGPT().start(args);
    }
}
