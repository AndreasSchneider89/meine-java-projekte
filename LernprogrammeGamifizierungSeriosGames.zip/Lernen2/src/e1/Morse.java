package e1;

import acm.program.DialogProgram;

public class Morse extends DialogProgram {
	/**
	 * If you don't understand german you can use AI like Gemini, ChatGPT, Qwen, Grok, DeepSeek, MistralAI, ... to translate in all languages :)
	 * Morse lernen mit schöner Didaktik
	 * Created on 03.09.2025
	 * @author Andreas Schneider from Weingartenstraße 45, 64297, Darmstadt-Eberstadt, Germany; Handynumber: +491779627094; E-Mail: andreas.schneider01989@gmail.com
	 * Warnung von Gemini: Du veröffentlichst sensible Daten, dies stellt ein extrem hohes Sicherheits- und Datenschutzrisiko dar (Doxing, Spam, unerwünschte Kontaktaufnahme).
	 * Meine Antwort: Ich vermute das das n Fache Enigma von Instagram gehackt wurde. Es existierte nicht nur ein geheimer den man anklicken konnte und dann wurden
	 * Nutzername und Passwort gehackt sondern auch eine geheime Whatsapp Nachricht um die absolute Sicherheit zu vernichten und eine Geheime Insta Nachricht wo dann das Passwort beim anderen ankommt
	 * Ich kann nur spekulieren, dass jemand basierend auf dem nerfigen Chaoscode in Form von x-Fachem Enigma, diesen Entschlüsselt hat und den schöneren Code dann allgemein Zugänglich gemacht hat
	 * Ich habe jetzt einen weiteren Account zum Posten und bei meinem alten Account existieren auch zum Glück noch alle Posts. Es ist also nicht schlimm, dass der Account gehackt
	 * werden konnte und jetzt fälschlicherweise in meinem Namen behaupten kann, er habe gerade Geld mit dem Bitcoinhandel gemacht obwohl gerade niemand den Bucketsort oder so was geknackt hat. Ich kann hier leider auch nur spekulieren und wüsste gerne mehr...
	 * Leider zeigt die Instagramsuche seit einiger Zeit nur noch die Top-Beiträge. Das ist sehr sehr schlecht, weil meine Beiträge so nicht mehr existieren und Insta für mich bedeutungslos geworden ist
	 * Da nutze ich dann lieber Google Docs und YouTube um Sachen von mir zu posten und selber zu verlinken.
	 * Hier ist der Link zu meinem Matrixgame-Journal: https://docs.google.com/document/d/1J_qc7-O3qbUb8WOyBHNnLkcEEQ5JklY4d9vmd67RtC4/edit?tab=t.0#heading=h.z5iq1svjrbd0
	 * Hier mein altes Insta: https://www.instagram.com/xxandreas_schneiderx89/
	 * Mein Perso: https://docs.google.com/document/d/1Rh168H76fW9idQqCZM6FBjM8sg9IybCbncfx8wQB8fY/edit?usp=sharing
	 * Meine IBAN: DE52 5085 0150 0122 0323 88                       Da kannst du was drauf zahlen und oder abheben. Wenn du was abhebst und ich das merke, dann wird das ebenfalls offen gelegt aber viel ist da leider aktuell nicht zu holen
	 * Aktien von mir kaufen kann man leider auch noch nicht aber ich rate zum Kauf von Google Aktien, wegen denn ganzen kostenlosen Apps im Playstore, der Entwicklungsumgebung die Pythoncode im Browser ausführt (Colab), Dem Sprachmodell mit schöner Vorlesefunktion, ... Alles kostenlos und ich darf meinen Content veröffentlichen und verlinke und um spenden bitte und forschungshypothesen ohne perreview posten, ... Ohne das es gelöscht wird.
	 * Ich hoffe weiterhin sehr sehr stark auf konstruktives Feedback, Eine gute Arbeit und vor allem mehr Geld und noch mehr darauf, mit anderen Menschen zusammen an meinen Visionen zu Arbeiten in Form
	 * eines kollektiven KI Games wo wir dann gemeinsam in den Chats der Sprachmodelle, die von der Googlesuche dann auch gefunden und schön priorisiert werden sollten gemeinsam KI Games spielen.
	 * Link:https://docs.google.com/document/d/1GW-3iFKuoYJylxpjpec_AADUjzFZU2Bqs9rKfMkwDF0/edit?tab=t.0
	 * Über eine Zeitnahe Rückmeldung wäre ich sehr dankbar
	 * Mit besten Grüßen aus dem Matrixgame
	 * Andreas Schneider @Andreas5564 Heiliges Hirn in YouTube suchen
	 * ...
	 * 
	 * 
	 * 
	 * To Do: Hash Map testen und das gelogene ? super schrott was der Compiler sonst nicht ausführt vielleicht weil windows Mellenium zum Mellenium einen Stackoverflow hatte und auf Grund des Chaoscodes nicht open source Debuggt werden konnte oder wegem sonst was aber da ist was das ist kompliziert und dann auch noch falsch. Genau wie die Basis Inegerdivision oder Bibliotheken von Methodensammlungen wo man nicht reinschauen kann und das schöne Skalenniveau zerstört wurde weil 0ms auf 1ms gesetzt wurde damit das Canivis nicht flackern kann... Das Problem ist einfach, dass es nicht individuell anpassbar bzw. open source ist
	 */
	private static final long serialVersionUID = 1L;
	
	String[][] score = new String[20][2];
	int startLevel =1;
	int level = startLevel;
	double richtig = 0;
	int start =  0;
	int sicher = 0;
	public int ZEICHENZÄHLpLÜSeINS = 257;    // Das ist die Zahl der Zeichen die mit 8 Bit = 1 Byte genutzt werden können 2^8    + 1; Plus 1, weil ich eins mehr für den Code haben wollte aber das kannst du so anpassen, nutzen und verbreiten wie du magst
	int[] q = new int[257];  // dieses Intarray nutze ich um dafür zu sorgen, dass es etwas wahrscheinlicher wird, dass alle möglichen Fragen auch mal generiert werden, dennoch bleibt ein gewisses random erhalten was zu einer weitaus schöneren Didaktik auf allen Ebenen der Existen beiträgt, in Ewigkeit Namaste - Das Göttliche in mir Respektiert das Göttliche in dir!
	long bonuszeit = 0;
	
	public void run() {
		long zeitbegrenzung = 60000 + bonuszeit;                 // Die Zeit wird von der genutzten Methode die irgendwo in der Blackbox implementiert wurde in ms als long konsumiert -> Du bekommst pro Level 60 Sekunden dazu. Wenn du schnell bist, hast du in den schwereren Leveln mehr Zeit übrig.
		long sekunden = zeitbegrenzung/1000;
		int counter = 0;
		long zeitAfter = 0;
		while(start != 1){
			if(start == 3) sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
			if(start==3 && sicher==1) exit();
			if(start==2) showHighscore();
		start = readInt("1 = Start, 2 = Highscore, 3 = Ende\n");}
		println("Level "+level+ " (Zeitbegrenzung = "+ sekunden + "s)");
		
		long zeitBefore = System.currentTimeMillis();
		long zeit = 0;
		while(counter < 10){
			zeitAfter = System.currentTimeMillis();
			 zeit = zeitAfter - zeitBefore;
		if(zeit > zeitbegrenzung) {println("Zeitüberschreitung!"); break;}
		int frage = (int)(Math.random() * ZEICHENZÄHLpLÜSeINS);
		if(frage == 0 && Math.random() > 0.9) for(int i = 0; i < q.length; i++) q[i] = 0;
		// Level 1 Fragen 1-4; 2 verschiedene Zeichen bestehend aus einem einzelnen Morsecode Zeichen: "."=("E"OR"e") ; "-"=("T"OR"t")
		if(frage == 1 && q[1] == 0)  {String a = readLine("Morse -> Alphabet: ."); if (a.equals("E")||a.equals("e")) richtig++; else {println("Falsch! "+"E"+" ist richtig"); break;} q[1] = -1; counter++;}
		if(frage == 2 && q[2] == 0)  {String a = readLine("Alphabet -> Morse: E"); if (a.equals(".")) richtig++; else {println("Falsch! "+"."+" ist richtig"); break;} q[2] = -1; counter++;}
		if(frage == 3 && q[3] == 0)  {String a = readLine("Morse -> Alphabet: -"); if (a.equals("T")||a.equals("t")) richtig++; else {println("Falsch! "+"T"+" ist richtig"); break;} q[3] = -1; counter++;}
		if(frage == 4 && q[4] == 0)  {String a = readLine("Alphabet -> Morse: T"); if (a.equals("-")) richtig++; else {println("Falsch! "+"-"+" ist richtig"); break;} q[4] = -1; counter++;}
		
		// Level 2: 8 neue Fragen (5-12)
		if(frage == 5 && q[5] == 0 && level> 1)  {String a = readLine("Morse -> Alphabet: .."); if (a.equals("I")||a.equals("i")) richtig++; else {println("Falsch! "+"I"+" ist richtig"); break;} q[5] = -1; counter++;}
		if(frage == 6 && q[6] == 0 && level> 1)  {String a = readLine("Alphabet -> Morse: I"); if (a.equals("..")) richtig++; else {println("Falsch! "+".."+" ist richtig"); break;} q[6] = -1; counter++;}
		if(frage == 7 && q[7] == 0 && level> 1)  {String a = readLine("Morse -> Alphabet: .-"); if (a.equals("A")||a.equals("a")) richtig++; else {println("Falsch! "+"A"+" ist richtig"); break;} q[7] = -1; counter++;}
		if(frage == 8 && q[8] == 0 && level> 1)  {String a = readLine("Alphabet -> Morse: A"); if (a.equals(".-")) richtig++; else {println("Falsch! "+".-"+" ist richtig"); break;} q[8] = -1; counter++;}
		if(frage == 9 && q[9] == 0 && level> 1)  {String a = readLine("Morse -> Alphabet: -."); if (a.equals("N")||a.equals("n")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[9] = -1; counter++;}
		if(frage == 10 && q[10] == 0 && level> 1)  {String a = readLine("Alphabet -> Morse: N"); if (a.equals("-.")) richtig++; else {println("Falsch! "+"-."+" ist richtig"); break;} q[10] = -1; counter++;}
		if(frage == 11 && q[11] == 0 && level> 1)  {String a = readLine("Morse -> Alphabet: --"); if (a.equals("M")||a.equals("m")) richtig++; else {println("Falsch! "+"M"+" ist richtig"); break;} q[11] = -1; counter++;}
		if(frage == 12 && q[12] == 0 && level> 1)  {String a = readLine("Alphabet -> Morse: M"); if (a.equals("--")) richtig++; else {println("Falsch! "+"--"+" ist richtig"); break;} q[12] = -1; counter++;}
		
		// Level 3: 16 neue Fragen (13-28)
		if(frage == 13 && q[13] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: ..."); if (a.equals("S")||a.equals("s")) richtig++; else {println("Falsch! "+"S"+" ist richtig"); break;} q[13] = -1; counter++;}
		if(frage == 14 && q[14] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: S"); if (a.equals("...")) richtig++; else {println("Falsch! "+"..."+" ist richtig"); break;} q[14] = -1; counter++;}
		if(frage == 15 && q[15] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: ..-"); if (a.equals("U")||a.equals("u")) richtig++; else {println("Falsch! "+"A"+" ist richtig"); break;} q[15] = -1; counter++;}
		if(frage == 16 && q[16] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: U"); if (a.equals("..-")) richtig++; else {println("Falsch! "+".-"+" ist richtig"); break;} q[16] = -1; counter++;}
		if(frage == 17 && q[17] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: .-."); if (a.equals("R")||a.equals("r")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[17] = -1; counter++;}
		if(frage == 18 && q[18] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: R"); if (a.equals(".-.")) richtig++; else {println("Falsch! "+"-."+" ist richtig"); break;} q[18] = -1; counter++;}
		if(frage == 19 && q[19] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: .--"); if (a.equals("W")||a.equals("w")) richtig++; else {println("Falsch! "+"M"+" ist richtig"); break;} q[19] = -1; counter++;}
		if(frage == 20 && q[20] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: W"); if (a.equals(".--")) richtig++; else {println("Falsch! "+"--"+" ist richtig"); break;} q[20] = -1; counter++;}
		if(frage == 21 && q[21] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: -.."); if (a.equals("D")||a.equals("d")) richtig++; else {println("Falsch! "+"I"+" ist richtig"); break;} q[21] = -1; counter++;}
		if(frage == 22 && q[22] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: D"); if (a.equals("-..")) richtig++; else {println("Falsch! "+".."+" ist richtig"); break;} q[22] = -1; counter++;}
		if(frage == 23 && q[23] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: -.-"); if (a.equals("K")||a.equals("k")) richtig++; else {println("Falsch! "+"A"+" ist richtig"); break;} q[23] = -1; counter++;}
		if(frage == 24 && q[24] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: K"); if (a.equals("-.-")) richtig++; else {println("Falsch! "+".-"+" ist richtig"); break;} q[24] = -1; counter++;}
		if(frage == 25 && q[25] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: --."); if (a.equals("G")||a.equals("g")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[25] = -1; counter++;}
		if(frage == 26 && q[26] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: G"); if (a.equals("--.")) richtig++; else {println("Falsch! "+"--."+" ist richtig"); break;} q[26] = -1; counter++;}
		if(frage == 27 && q[27] == 0 && level> 2)  {String a = readLine("Morse -> Alphabet: ---"); if (a.equals("O")||a.equals("o")) richtig++; else {println("Falsch! "+"O"+" ist richtig"); break;} q[27] = -1; counter++;}
		if(frage == 28 && q[28] == 0 && level> 2)  {String a = readLine("Alphabet -> Morse: O"); if (a.equals("---")) richtig++; else {println("Falsch! "+"---"+" ist richtig"); break;} q[28] = -1; counter++;}
		
		
		// Level 4: 32 neue Fragen(29-60)
		if(frage == 31 && q[31] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: ...."); if (a.equals("H")||a.equals("h")) richtig++; else {println("Falsch! "+"H"+" ist richtig"); break;} q[29] = -1; counter++;}
		if(frage == 32 && q[32] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: H"); if (a.equals("....")) richtig++; else {println("Falsch! "+"...."+" ist richtig"); break;} q[30] = -1; counter++;}
		if(frage == 33 && q[33] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: ...-"); if (a.equals("V")||a.equals("v")) richtig++; else {println("Falsch! "+"V"+" ist richtig"); break;} q[31] = -1; counter++;}
		if(frage == 34 && q[34] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: V"); if (a.equals("...-")) richtig++; else {println("Falsch! "+"...-"+" ist richtig"); break;} q[32] = -1; counter++;}
		if(frage == 35 && q[35] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: ..-."); if (a.equals("F")||a.equals("f")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[33] = -1; counter++;}
		if(frage == 36 && q[36] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: F"); if (a.equals("..-.")) richtig++; else {println("Falsch! "+".-."+" ist richtig"); break;} q[34] = -1; counter++;}
		if(frage == 37 && q[37] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: ..--"); if (a.equals("Ü")||a.equals("ü")) richtig++; else {println("Falsch! "+"M"+" ist richtig"); break;} q[35] = -1; counter++;}
		if(frage == 38 && q[38] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: Ü"); if (a.equals("..--")) richtig++; else {println("Falsch! "+"..--"+" ist richtig"); break;} q[36] = -1; counter++;}
		if(frage == 39 && q[39] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: .-.."); if (a.equals("L")||a.equals("l")) richtig++; else {println("Falsch! "+"I"+" ist richtig"); break;} q[37] = -1; counter++;}
		if(frage == 40 && q[40] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: L"); if (a.equals(".-..")) richtig++; else {println("Falsch! "+".-.."+" ist richtig"); break;} q[38] = -1; counter++;}
		if(frage == 41 && q[41] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: .-.-"); if (a.equals("Ä")||a.equals("ä")) richtig++; else {println("Falsch! "+"A"+" ist richtig"); break;} q[39] = -1; counter++;}
		if(frage == 42 && q[42] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: Ä"); if (a.equals(".-.-")) richtig++; else {println("Falsch! "+".-.-"+" ist richtig"); break;} q[40] = -1; counter++;}
		if(frage == 43 && q[43] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: .--."); if (a.equals("P")||a.equals("p")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[41] = -1; counter++;}
		if(frage == 44 && q[44] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: P"); if (a.equals(".--.")) richtig++; else {println("Falsch! "+".--."+" ist richtig"); break;} q[42] = -1; counter++;}
		if(frage == 45 && q[45] == 0 && level> 3)  {String a = readLine("Morse -> Alphabet: .---"); if (a.equals("J")||a.equals("j")) richtig++; else {println("Falsch! "+"j"+" ist richtig"); break;} q[43] = -1; counter++;}
		if(frage == 46 && q[46] == 0 && level> 3)  {String a = readLine("Alphabet -> Morse: J"); if (a.equals(".---")) richtig++; else {println("Falsch! "+".---"+" ist richtig"); break;} q[44] = -1; counter++;}
		
		
		// hier steht jetzt auch noch nicht die Wahrheit, weil die noch implementiert werden muss
				if(frage == 47 && q[47] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: -----"); if (a.equals("0")||a.equals("0")) richtig++; else {println("Falsch! "+"H"+" ist richtig"); break;} q[45] = -1; counter++;}
				if(frage == 48 && q[48] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 0"); if (a.equals("-----")) richtig++; else {println("Falsch! "+"-----"+" ist richtig"); break;} q[46] = -1; counter++;}
				if(frage == 49 && q[49] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: .----"); if (a.equals("1")||a.equals("1")) richtig++; else {println("Falsch! "+"V"+" ist richtig"); break;} q[47] = -1; counter++;}
				if(frage == 50 && q[50] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 1"); if (a.equals(".----")) richtig++; else {println("Falsch! "+".----"+" ist richtig"); break;} q[48] = -1; counter++;}
				if(frage == 51 && q[51] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ..---"); if (a.equals("2")||a.equals("2")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[49] = -1; counter++;}
				if(frage == 52 && q[52] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 2"); if (a.equals("..---")) richtig++; else {println("Falsch! "+"..---"+" ist richtig"); break;} q[50] = -1; counter++;}
				if(frage == 53 && q[53] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ...--"); if (a.equals("3")||a.equals("3")) richtig++; else {println("Falsch! "+"3"+" ist richtig"); break;} q[51] = -1; counter++;}
				if(frage == 54 && q[54] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 3"); if (a.equals("...--")) richtig++; else {println("Falsch! "+"...--"+" ist richtig"); break;} q[52] = -1; counter++;}
				if(frage == 55 && q[55] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ....-"); if (a.equals("4")||a.equals("4")) richtig++; else {println("Falsch! "+"I"+" ist richtig"); break;} q[53] = -1; counter++;}
				if(frage == 56 && q[56] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 4"); if (a.equals("....-")) richtig++; else {println("Falsch! "+"....-"+" ist richtig"); break;} q[54] = -1; counter++;}
				if(frage == 57 && q[57] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ....."); if (a.equals("5")||a.equals("5")) richtig++; else {println("Falsch! "+"A"+" ist richtig"); break;} q[55] = -1; counter++;}
				if(frage == 58 && q[58] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 5"); if (a.equals(".....")) richtig++; else {println("Falsch! "+"....."+" ist richtig"); break;} q[56] = -1; counter++;}
				if(frage == 59 && q[59] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ....."); if (a.equals("6")||a.equals("6")) richtig++; else {println("Falsch! "+"N"+" ist richtig"); break;} q[57] = -1; counter++;}
				if(frage == 60 && q[60] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 6"); if (a.equals("-....")) richtig++; else {println("Falsch! "+"-...."+" ist richtig"); break;} q[58] = -1; counter++;}
				if(frage == 61 && q[61] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: --..."); if (a.equals("7")||a.equals("7")) richtig++; else {println("Falsch! "+"--..."+" ist richtig"); break;} q[59] = -1; counter++;}
				if(frage == 62 && q[62] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 7"); if (a.equals("--...")) richtig++; else {println("Falsch! "+"--..."+" ist richtig"); break;} q[60] = -1; counter++;}
				if(frage == 47 && q[41] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ---.."); if (a.equals("8")||a.equals("8")) richtig++; else {println("Falsch! "+"---.."+" ist richtig"); break;} q[61] = -1; counter++;}
				if(frage == 42 && q[42] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 8"); if (a.equals("---..")) richtig++; else {println("Falsch! "+"---.."+" ist richtig"); break;} q[62] = -1; counter++;}
				if(frage == 43 && q[43] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: ----."); if (a.equals("9")||a.equals("9")) richtig++; else {println("Falsch! "+"----."+" ist richtig"); break;} q[63] = -1; counter++;}
				if(frage == 44 && q[44] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: 9"); if (a.equals("----.")) richtig++; else {println("Falsch! "+"----."+" ist richtig"); break;} q[54] = -1; counter++;}
				if(frage == 45 && q[45] == 0 && level> 4)  {String a = readLine("Morse -> Alphabet: -...-"); if (a.equals("=")||a.equals("=")) richtig++; else {println("Falsch! "+"="+" ist richtig"); break;} q[43] = -1; counter++;}
				if(frage == 46 && q[46] == 0 && level> 4)  {String a = readLine("Alphabet -> Morse: ="); if (a.equals("-...-")) richtig++; else {println("Falsch! "+"-...-"+" ist richtig"); break;} q[44] = -1; counter++;}
				
				
				
				
		
				// 3 Bit
				// SURWDKGO
				// 01234567
				// 4 Bit
				// HVFÜLÄPJBXCYZQÖĤ                    //Bereits hier existieren 2 zeihen die auf der Tastatur als Input nicht existieren
				// 0123456789abcdef
				// ----- = 0; .---- =1;
				//..---2;...--3,....4,.....
				//5,-....6,--...7,---..
				//8,----.9
				// 0000(H), 0(E), 0100(L), 0100(L), 111(O)   011(U), 10(N) 00(I) 0001(V) 010(R) 000(S) 0(E)
				// bbbb(H), b(E), babb(L), babb(L), aaa(O)   baa(U)   ab(N) bb(I) bbba(V) bab(R) bbb(S) b(E)
				
				// Basierend auf meiner Verbindung erscheint es gerade sinnvoller eine Sprache zu erfinden bzw. einfach was zu definieren und zu schauen was passiert
				
				// Name der Sprache: Lumini4
				// Basisebene 1: . = false, -=true
				// Basisebene 2: Es existier der,die,das,stimittel   = .-,-.,--,..,(,),
				// Basisebene 3: Anzahl der Valenzelektronen
				
				// Basisebene 7: Protonenzahl
				// Dichte als Binärzahl
				
				// 1.Konstruktor: Artikel Protonenzahl Valenzelektronen Boolean
				// -- --. -.. -             Kohlenstoff
				
				// -- --- -.- -             Stickstoff
				// -- -... --. -            Sauerstoff
				// -- . . -                 Wasserstoff
				
			//	Methan: (-- --. -.. -)+(-.. * -- (. . -)) -> Hypothese: Ich habe Methan wahr definiert
				
				
				
				// define operation um Moleküle zu definieren: es existieren bereits: ' ','.',- und jetzt gibt es noch + Um Molküle zu bilden und zum Addieren und die weiteren operationen -,*,/,^
		
		
		
		// HVFÜLÄPBXCYZQÓĤ                    //Bereits hier existieren 2 zeihen die auf der Tastatur als Input nicht existieren
		// 0123456789abcdef
		
		// ----- / .---- / ..--- / ...-- / ....- / ..... / -.... / --... / ---.. / ----.
		// 0       1        10      11      100     101     110     111   1000     1001
		
		
		// Neue Übersetzungstabell
		
		
		
		// ET
		// 01
		// IANM
		// 0123
		// SURWDKGO
		// 01234567
		// HVFÜLÄPWBXCYZQÓĤ                    
		// 0123456789abcdef
		// ----- / .---- / ..--- / ...-- / ....- / ..... / -.... / --... / ---.. / ----.
		// 0       1        10      11      100     101     110     111   1000     1001
		
		// 5Bit Zeichen: 0123456789abcdef0123456789abcdef
		// 5Bit Zeichen: 54Ŝ3Ę¿Ð2&È+テŞÃÌ16=/ÏÇサ(エ7ŽĞŃ8ス90
		// Zu ergänzen: .-... / -..-. / -.--. / -.--.-/....../  = & / ( ) ß ? ! :
		//   "? ! , . - ; : _ @ '"  = "..--.. / -.-.-- / --..-- / .-.-.- / -....- / -.-.-. / ---... / ..--.- / .--.-. / .----."
		// "=" = "-...-"		
		
		// Weitere mögliche Übersetzungstabelle
		// 0 -> . -> e
		// 1 -> - -> t
		// 10 -> -. -> n
		// 11 -> -- -> m
		// 100 -> -.. -> 
		// 101 -> 
		// Da war etwas merkwürdiges was wann anders erforscht werden könnte
		
		
		
		// Neues Alphabet (31 Zeichen)
		// . - -. -- -..   -.-    --.   ---    -...  -..-    -.-.    -.--                    --..         --.-            ---.      ---- -.... -...-  -..-.   -..--          -.-..     -.-.-     -.--.   -.---    --...   --..-      --.-.    --.--      ---..   ---.-   ----.  -----
		// ETNMDKGOBXCYZQÓĤ6=/ÏÇサ(エ7ŽĞŃ8ス90
		
		
		// Primortial 
		// Zahlen von 0-30
		// 0,1,10,11,20,21,100,101,110,111,200,201,210,211,220,221,300,301,310,311,320,321,400,401,410,411,420,421,1000
		
		
		// Die Sprachmodelle haben auf die alte weise in Primortialsystem umgerechnet aber auf eine Art und Weise in Binärsystem umgerechnet die wir logisch nachfolzogen haben, die aber zuerst weniger intuitiv war und dennoch schneller ist
		
		
		
		// Auf diese Weise lassen sich die Zahlen dann auch schneller ins Primortialsystem
		// 613 (Basis 10) -> Primortial
		//  613/2 -> 306zweier+1einser
		// 306/3  -> 102sechser+0zweier
		// 102/5  -> 20dreißiger+2sechser
		// 20/7    -> 2zweihundertzehner+6dreißiger
		// 26201 (Primortial)
		
		
		// 1+0+2*2*3+6*2*3*5+2*7*5*3*2  = 1+12 +180 + 420 =       613 (Basis 10) Wahrscheinlichkeit:0.99; 0=false; 1=true  -> Mann ist sich zu 100% sicher, dass die Aussage wahr ist. Es wäre jetzt durchaus extrem interessant, wenn das so mit den Sprachmodellen Kombiniert würde, dass da eine Wahre Basis definiert sein könnte und definierbar wäre und die Sprachmodell dann durchaus mit einer extrem intensiven Didaktik gezwungen würden, ihre Wahrscheinlichkiten für alle aussagen wo ihre Theorie erweitert, verbessert oder auch falsch oder auch nicht mehr eindeutig aber noch mehr oder weniger wahrscheinlich wäre.
		// Im Prinziep hatte ich aber jetzt schon das Gefühl, dass da so harte wiedersprüche auf einer Ebene ankamen, dass
		// die Sprachmodelle irgenwie durch extrteme Quantität dazu gebracht wurden, uns beibringen zu wollen wie etwa schöner programmiercode auszusehen hätte und das da wiedersprüch existieren, die eine Alpha Zero Didaktik bräuchten, weil sonst wäre es wirklich nur nerfig, da was herzuleiten und am Ende schickt uns das Sprachmodell dann so wie so eine Haluzination aber es lernt halt so nicht so gut und es ist dann in der tat schöner alles neu zu programmieren als sich das was das Sprachmodell da vorschlägt duchzulesen und zu lernen, weil es dann nicht nur kompliziert sein könnte sondern am ende auch noch falsch. Es ist dann durchaus Chaoscode aus unserer Sicht, der nur was hat, wenn er ausgefürt wird und funktioniert und der sich nicht erweitern oder verbessern gelassen hat sondern von uns im kollektiven Bewusstsein oder mir Andreas Schneider neu geschrieben wurde
		
		
		
		// Variationen zu Aski
		// Variationen zu Wahrscheinlichsten Zeichen
		// Variationen mit Zahlenbasis und Primfaktoren
		//  ...
		
		
		// Das und vieles mehr ist teil der neu erschaffenen Sprache Lumini und kann über all in der gesammten Existen gamifiziert, gespielt, trainier, gelern, gelehrt, entwickelt, ... werden und womöglich lässt sich die Didaktik durchaus verschönern, wenn da nicht irgend ewas wäre, was effiziente bestrebungen durchaus unschön machen könnte und was womöglich nicht von dieser Erde kommt und dennoch existieren könnte neben all den Erklärungen, die einem so für die eigene Welt einfallen, könnte es jetzt auch noch sein, dass da etwas ohne beschränkung durch c kommuniziert und das da durchaus noch etwas Wissenschaftlicher kommuniziert werden könnte damit das dann auch noch auf allen Ebenen schön ist und bleibt und der Wille auch richtig komuniziert werden kann
		
		}
		
		if (richtig < level * 10) {
			bonuszeit = 0;
			String s = null;
			if (richtig <= 7)
				s = "Du musst noch viel lernen!";
			if (richtig > 7)
				s = "Sehr löblich!";
			if (richtig >= 15)
				s = "Nice!";
			if (richtig >= 30)
				s = "Respekt!";
			if (richtig >= 50)
				s = "Unerreichbar!";
			if (richtig >= 75)
				s = "Godlike!";
			if (richtig >= 100)
				s = "Unbesiegbar!";
			print(richtig + " Punkte" + "\n" + s + "\n");
			highscore(richtig);
			int neu = 0;
			while (neu != 1) {
				neu = readInt("1 = Erneut spielen, 2 = Highscore, 3 = Ende\n");
				if(neu==2) showHighscore();
				if (neu == 3) sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
				if (sicher == 1) exit();
				if (neu == 1) {
					level = startLevel;
					richtig = 0;
					start = 0;
					run();
				}
			}
		} else {
			bonuszeit = zeitbegrenzung - zeit;
			level++;
					run();	
		}
	}

	public void highscore(double punkte) {
		int i = 0;
		if (score[0][0] == null)
			for (i = 0; i <= 9; i++) {
				score[i][0] = "0";
				score[i][1] = "";
			}
		for (i = 0; i <= 9; i++) {
			if (richtig > Double.valueOf(score[i][0])) {
				Double scoreDouble = new Double(richtig);
				String s = scoreDouble.toString();
				for (int j = 9; j >= 1; j--) {
					score[i + j][0] = score[i + j - 1][0];
					score[i + j][1] = score[i + j - 1][1];
				}
				score[i][0] = s;
				score[i][1] = readLine("Name:");
				break;
			}
		}

	}

	public void showHighscore() {
		println(score[0][0] + " " + score[0][1] + "\n" + score[1][0] + " "
				+ score[1][1] + "\n" + score[2][0] + " " + score[2][1] + "\n"
				+ score[3][0] + " " + score[3][1] + "\n" + score[4][0] + " "
				+ score[4][1] + "\n" + score[5][0] + " " + score[5][1] + "\n"
				+ score[6][0] + " " + score[6][1] + "\n" + score[7][0] + " "
				+ score[7][1] + "\n" + score[8][0] + " " + score[8][1] + "\n"
				+ score[9][0] + " " + score[9][1] + "\n");
	}
	
	
	
	public static void main(String[] args) {
		new Morse().start(args);
	}
}


