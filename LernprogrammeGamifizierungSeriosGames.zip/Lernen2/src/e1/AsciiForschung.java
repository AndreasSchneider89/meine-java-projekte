package e1;

public class AsciiForschung {
	public static void main(String[] args) {
		System.out.println("a");
	}
}
