package e1;

import java.util.Scanner;
import java.util.Arrays;

public class MatrixTrainingDimension {
    // Übernommene Variablen und Methoden aus MatheFuerInformatiker (angepasst für Konsoleneingabe)
    // ...
    
    // Beispiel: Angepasste run()-Methode
    public static void starteTraining() {
        Scanner scanner = new Scanner(System.in);
        // ... (Logik aus MatheFuerInformatiker, ersetzt readInt() durch scanner.nextInt() usw.)
    }
    
    // Alle Hilfsmethoden (ggt, bruchrechnenAdd, etc.) bleiben erhalten
}