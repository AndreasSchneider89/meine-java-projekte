package e1;

import acm.program.DialogProgram;
import java.util.*;

/**
 * Vereinfachte und bereinigte Version des Morse-Lernspiels.
 * - entfernt persönliche Daten aus Kommentaren
 * - nutzt Arrays/Maps statt riesiger if-Kaskaden
 * - vermeidet Rekursion in run()
 * - stabilere Highscore-Verwaltung
 *
 * Erstellt als Refactor von einem größeren Originalfile (Autorenhinweise wurden entfernt).
 */
public class a extends DialogProgram {
    private static final long serialVersionUID = 1L;

    // Highscore: [0]=punkte als String, [1]=name
    private final String[][] score = new String[10][2];

    // Basis-Morse-Tabelle (Großbuchstaben). Erweiterungen möglich.
    private final LinkedHashMap<String, String> morseMap = new LinkedHashMap<>();

    private final Random rnd = new Random();

    // Spielvariablen
    private int startLevel = 1;
    private int level = startLevel;
    private double richtig = 0;
    private long bonuszeit = 0;

    public a() {
        initMorse();
        initHighscore();
    }

    private void initMorse() {
        // Grundalphabet (A-Z) + Umlaute + Ziffern bei Bedarf
        add("E", ".");
        add("T", "-");
        add("I", "..");
        add("A", ".-");
        add("N", "-.");
        add("M", "--");
        add("S", "...");
        add("U", "..-");
        add("R", ".-.");
        add("W", ".--");
        add("D", "-..");
        add("K", "-.-");
        add("G", "--.");
        add("O", "---");
        add("H", "....");
        add("V", "...-");
        add("F", "..-." );
        add("L", ".-.." );
        add("P", ".--." );
        add("J", ".---" );
        // Zahlen
        add("0", "-----");
        add("1", ".----");
        add("2", "..---");
        add("3", "...--");
        add("4", "....-");
        add("5", ".....");
        add("6", "-....");
        add("7", "--...");
        add("8", "---..");
        add("9", "----.");
    }

    private void add(String letter, String morse) {
        morseMap.put(letter, morse);
    }

    private void initHighscore() {
        for (int i = 0; i < score.length; i++) {
            score[i][0] = "0";
            score[i][1] = "";
        }
    }

    public void run() {
        while (true) {
            int start = readInt("1 = Start, 2 = Highscore, 3 = Ende\n");
            if (start == 3) {
                int sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
                if (sicher == 1) break;
                else continue;
            }
            if (start == 2) {
                showHighscore();
                continue;
            }
            if (start == 1) playSession();
        }
        println("Spiel beendet. Danke fürs Mitmachen!");
    }

    private void playSession() {
        level = startLevel;
        richtig = 0;
        bonuszeit = 0;

        boolean continuePlaying = true;
        while (continuePlaying) {
            long zeitbegrenzung = 60_000 + bonuszeit; // ms
            long zeitBefore = System.currentTimeMillis();
            println("Level " + level + " (Zeitbegrenzung = " + (zeitbegrenzung / 1000) + "s)");

            int fragenToPlay = Math.min(10, morseMap.size());
            List<String> pool = buildPoolForLevel(level);
            Collections.shuffle(pool, rnd);

            int counter = 0;
            while (counter < fragenToPlay) {
                long zeitNow = System.currentTimeMillis();
                if (zeitNow - zeitBefore > zeitbegrenzung) {
                    println("Zeitüberschreitung!");
                    break;
                }

                String item = pool.get(counter % pool.size());
                boolean askMorseToAlphabet = rnd.nextBoolean();

                if (askMorseToAlphabet) {
                    String answer = readLine("Morse -> Alphabet: " + morseMap.get(item) + "\n");
                    if (answer.equalsIgnoreCase(item)) {
                        richtig++;
                    } else {
                        println("Falsch! \"" + item + "\" ist richtig");
                        break;
                    }
                } else {
                    String answer = readLine("Alphabet -> Morse: " + item + "\n");
                    if (answer.equals(morseMap.get(item))) {
                        richtig++;
                    } else {
                        println("Falsch! \"" + morseMap.get(item) + "\" ist richtig");
                        break;
                    }
                }
                counter++;
            }

            if (richtig < level * 10) {
                bonuszeit = 0;
                String s = feedback(richtig);
                println(richtig + " Punkte\n" + s + "\n");
                highscore(richtig);

                int neu = readInt("1 = Erneut spielen, 2 = Highscore, 3 = Ende\n");
                if (neu == 2) showHighscore();
                if (neu == 3) {
                    int sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
                    if (sicher == 1) { System.exit(0); }
                }
                if (neu == 1) {
                    level = startLevel;
                    richtig = 0;
                    // Schleife beginnt von vorn
                }
                continuePlaying = false; // beende Session (wer will, kann neu starten)
            } else {
                // bestanden -> Bonuszeit und nächstes Level
                long zeitAfter = System.currentTimeMillis();
                bonuszeit = (60_000 + bonuszeit) - (zeitAfter - zeitBefore);
                level++;
                println("Level geschafft! Nächster Level: " + level + " (Bonuszeit = " + (bonuszeit/1000) + "s)");
                // weiter zur nächsten Level-Runde
            }
        }
    }

    private List<String> buildPoolForLevel(int lvl) {
        // Je höher das Level, desto größer der Pool (einfaches Beispiel)
        List<String> all = new ArrayList<>(morseMap.keySet());
        int size = Math.min(all.size(), Math.max(4, lvl * 4));
        return all.subList(0, size);
    }

    private String feedback(double richtig) {
        if (richtig <= 7) return "Du musst noch viel lernen!";
        if (richtig <= 14) return "Sehr löblich!";
        if (richtig <= 29) return "Nice!";
        if (richtig <= 49) return "Respekt!";
        if (richtig <= 74) return "Unerreichbar!";
        if (richtig <= 99) return "Godlike!";
        return "Unbesiegbar!";
    }

    public void highscore(double punkte) {
        double p = punkte;
        for (int i = 0; i < score.length; i++) {
            double cur = Double.parseDouble(score[i][0]);
            if (p > cur) {
                // Einfügen an Position i, nach unten verschieben
                for (int j = score.length - 1; j > i; j--) {
                    score[j][0] = score[j - 1][0];
                    score[j][1] = score[j - 1][1];
                }
                score[i][0] = String.valueOf(p);
                score[i][1] = readLine("Name:\n");
                break;
            }
        }
    }

    public void showHighscore() {
        println("--- Highscore ---");
        for (int i = 0; i < score.length; i++) {
            println((i+1) + ". " + score[i][0] + " " + score[i][1]);
        }
    }

    public static void main(String[] args) {
        new a().start(args);
    }
}
