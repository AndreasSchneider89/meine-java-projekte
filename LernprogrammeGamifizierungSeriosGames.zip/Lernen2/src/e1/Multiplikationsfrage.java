package e1;
public class Multiplikationsfrage {

    // --- Variablen (Felder) ---
    // 'private' bedeutet, dass nur diese Klasse darauf zugreifen kann.
    private int faktor1;
    private int faktor2;
    private int korrekteAntwort;

    // --- Konstruktor ---
    // Wird aufgerufen, um ein neues "Frage-Objekt" zu erstellen.
    // Hier kommen die Zufallszahlen rein.
    public Multiplikationsfrage(int level) {
        // DEIN CODE HIER
    }

    // --- Methoden ---

    // Gibt nur den Text der Frage zurück, z.B. "12 * 5"
    public String getFrageText() {
		return "";
        // DEIN CODE HIER
    }

    // Prüft die Antwort und gibt true (richtig) oder false (falsch) zurück
    public boolean pruefeAntwort(int inputAntwort) {
        return inputAntwort == korrekteAntwort;
    }

    // Gibt die richtige Antwort zurück, falls die Eingabe falsch war
    public int getKorrekteAntwort() {
        return korrekteAntwort;
    }
}