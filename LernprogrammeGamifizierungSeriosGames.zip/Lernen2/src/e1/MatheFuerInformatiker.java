package e1;

import java.util.Arrays;

import acm.program.DialogProgram;
import acm.program.GraphicsProgram;

public class MatheFuerInformatiker extends DialogProgram {
	/**
	 * PartyTest Created on Mar 14, 2015
	 * 
	 * @author Andreas
	 */
	private static final long serialVersionUID = 1L;

	String[][] score = new String[20][2];
	int level = 1;
	double richtig = 0;
	int start = 0;
	int sicher = 0;
	int[] q = new int[50];
	long bonuszeit = 0;

	public void run() {
		long zeitbegrenzung = 60000 + bonuszeit;
		long sekunden = zeitbegrenzung / 1000;
		int counter = 0;
		long zeitAfter = 0;
		while (start != 1) {
			if (start == 3)
				sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
			if (start == 3 && sicher == 1)
				exit();
			if (start == 2)
				showHighscore();
			start = readInt("1 = Start, 2 = Highscore, 3 = Ende\n");
		}
		println("Level " + level + " (Zeitbegrenzung = " + sekunden + "s)");

		long zeitBefore = System.currentTimeMillis();
		long zeit = 0;
		while (counter < 10) {
			zeitAfter = System.currentTimeMillis();
			zeit = zeitAfter - zeitBefore;
			if (zeit > zeitbegrenzung) {
				println("Zeitüberschreitung!");
				break;
			}
			int frage = (int) (Math.random() * 50);
			if (frage == 0 && Math.random() > 0.9)
				for (int i = 0; i < q.length; i++)
					q[i] = 0;
			if (frage == 1 && q[1] == 0) {
				int x1 = (int) (Math.random() * (9 + 2 * level));
				int x2 = (int) (Math.random() * (9 + 2 * level));
				int a = readInt(x1 + " * " + x2 + "\n");
				if (a == x1 * x2)
					richtig++;
				else {
					println("Falsch! " + x1 * x2 + " ist richtig");
					break;
				}
				q[1] = -1;
				counter++;
			}
			if (frage == 2 && q[2] == 0) {
				int x1 = 1 + (int) (Math.random() * (8 + 2 * level));
				int x2 = (int) (Math.random() * (9 + 2 * level)) * x1;
				int a = readInt(x2 + " / " + x1 + "\n");
				if (a == x2 / x1)
					richtig++;
				else {
					println("Falsch! " + x2 / x1 + " ist richtig");
					break;
				}
				q[2] = -1;
				counter++;
			}
			if (frage == 3 && q[3] == 0) {
				int x1 = (int) (Math.random() * 10 * Math.pow(2, level));
				int x2 = (int) (Math.random() * 10 * Math.pow(2, level));
				int a = readInt(x1 + " + " + x2 + "\n");
				if (a == x1 + x2)
					richtig++;
				else {
					println("Falsch! " + (x1 + x2) + " ist richtig");
					break;
				}
				q[3] = -1;
				counter++;
			}
			if (frage == 4 && q[4] == 0) {
				int x1 = (int) (Math.random() * 10 * Math.pow(2, level));
				int x2 = (int) (Math.random() * 10 * Math.pow(2, level));
				int a = readInt(x1 + " - " + x2 + "\n");
				if (a == x1 - x2)
					richtig++;
				else {
					println("Falsch! " + (x1 - x2) + " ist richtig");
					break;
				}
				q[4] = -1;
				counter++;
			}
			if (frage == 5 && q[5] == 0) {
				int x1 = (int) (Math.random() * (1 + 2 * level));
				int x2 = (int) (Math.random() * 5);
				int a = readInt(x1 + " ^ " + x2 + "\n");
				if (a == Math.pow(x1, x2))
					richtig++;
				else {
					println("Falsch! " + Math.pow(x1, x2) + " ist richtig");
					break;
				}
				q[5] = -1;
				counter++;
			}
			if (frage == 6 && q[6] == 0) {
				int x1 = (int) (Math.random() * (1 + 2 * level));
				int x2 = 2 + (int) (Math.random() * 3);
				int a = readInt((int) Math.pow(x1, x2) + " ^ " + "1/" + x2 + "\n");
				if (a == x1)
					richtig++;
				else {
					println("Falsch! " + x1 + " ist richtig");
					break;
				}
				q[6] = -1;
				counter++;
			}
			if (frage == 7 && q[7] == 0) {
				int x1 = 2;
				int x2 = (int) (Math.random() * (1 + 2 * level));
				int a = readInt(x1 + " ^ " + x2 + "\n");
				if (a == Math.pow(x1, x2))
					richtig++;
				else {
					println("Falsch! " + Math.pow(x1, x2) + " ist richtig");
					break;
				}
				q[7] = -1;
				counter++;
			}
			if (frage == 8 && q[8] == 0) {
				int x1 = 2;
				int x2 = (int) (Math.random() * 10 * Math.pow(3, level)) * x1;
				int a = readInt(x2 + " / " + x1 + "\n");
				if (a == x2 / x1)
					richtig++;
				else {
					println("Falsch! " + x2 / x1 + " ist richtig");
					break;
				}
				q[8] = -1;
				counter++;
			}
			if (frage == 9 && q[9] == 0) {
				int x1 = (int) (Math.random() * (9 + 4 * level));
				int x2 = 2;
				int a = readInt((int) Math.pow(x1, x2) + " ^ " + "1/" + x2 + "\n");
				if (a == x1)
					richtig++;
				else {
					println("Falsch! " + x1 + " ist richtig");
					break;
				}
				q[9] = -1;
				counter++;
			}
			if (frage == 10 && q[10] == 0) {
				int x1 = (int) (Math.random() * 3 * Math.pow(1.5, level));
				int a = readInt("Dezimal zu Binär(" + x1 + ")\n");
				if (Integer.toString(a).equals(Integer.toBinaryString(x1)))
					richtig++;
				else {
					println("Falsch! " + Integer.toBinaryString(x1) + " ist richtig");
					break;
				}
				q[10] = -1;
				counter++;
			}
			if (frage == 11 && q[11] == 0) {
				int x1 = (int) (Math.random() * 3 * Math.pow(1.5, level));
				int a = readInt("Binär zu Dezimal(" + Integer.toBinaryString(x1) + ")\n");
				if (a == x1)
					richtig++;
				else {
					println("Falsch! " + x1 + " ist richtig");
					break;
				}
				q[11] = -1;
				counter++;
			}
			if (frage == 12 && q[12] == 0) {
				int x1 = (int) (Math.random() * 10 * Math.pow(1.5, level));
				String a = readLine("Dezimal zu Hexadezimal(" + x1 + ")\n");
				if (a.equals(Integer.toHexString(x1)))
					richtig++;
				else {
					println("Falsch! " + Integer.toHexString(x1) + " ist richtig");
					break;
				}
				q[12] = -1;
				counter++;
			}
			if (frage == 13 && q[13] == 0) {
				int x1 = (int) (Math.random() * 10 * Math.pow(1.5, level));
				int a = readInt("Hexadezimal zu Dezimal(" + Integer.toHexString(x1) + ")\n");
				if (a == x1)
					richtig++;
				else {
					println("Falsch! " + x1 + " ist richtig");
					break;
				}
				q[13] = -1;
				counter++;
			}
			if (frage == 14 && q[14] == 0) {
				int x1 = 1 + (int) (Math.random() * 10);
				int x2 = (int) (Math.random() * 5 * Math.pow(2, level)) * x1;
				int a = readInt(x2 + " / " + x1 + "\n");
				if (a == x2 / x1)
					richtig++;
				else {
					println("Falsch! " + x2 / x1 + " ist richtig");
					break;
				}
				q[14] = -1;
				counter++;
			}
			if (frage == 15 && q[15] == 0) {
				int x1 = (int) (Math.random() * 11);
				int x2 = (int) (Math.random() * 7 * Math.pow(1.5, level));
				int a = readInt(x1 + " * " + x2 + "\n");
				if (a == x1 * x2)
					richtig++;
				else {
					println("Falsch! " + x1 * x2 + " ist richtig");
					break;
				}
				q[15] = -1;
				counter++;
			}
			if (frage == 16 && q[16] == 0) {
				int x1 = (int) (Math.random() * 7 * Math.pow(1.5, level));
				int x2 = (int) (Math.random() * 11);
				int a = readInt(x1 + " * " + x2 + "\n");
				if (a == x1 * x2)
					richtig++;
				else {
					println("Falsch! " + x1 * x2 + " ist richtig");
					break;
				}
				q[16] = -1;
				counter++;
			}
			if (frage == 17 && q[17] == 0) {
				double x1 = 1 + (int) (Math.random() * 2 * level);
				int x2 = (int) (Math.random() * (9 + 2 * level));
				double a = readDouble(x2 + " / " + (int) x1 + "\n");
				if (Math.round(a * 10000) == Math.round(x2 / x1 * 10000))
					richtig++;
				else {
					println("Falsch! " + Math.round(x2 / x1 * 10000) / 10000.0 + " ist richtig");
					break;
				}
				q[17] = -1;
				counter++;
			}
			if (frage == 18 && q[18] == 0) {
				int x1 = -25 * level * level + (int) (Math.random() * level * 50 * level);
				int x2 = 1 + (int) (Math.random() * (8 + 2 * level));
				int a = readInt(x1 + " mod " + x2 + "\n");
				if (a == x1 % x2)
					richtig++;
				else {
					println("Falsch! " + x1 % x2 + " ist richtig");
					break;
				}
				q[18] = -1;
				counter++;
			}
			if (frage == 19 && q[19] == 0) {
				int x1 = 1 + (int) (Math.random() * 10 * Math.pow(2, level));
				int a = readInt("Ein Computersystem besitzt " + x1
						+ " virtuelle Seiten\nWie viele Bits werden für die Adressierung von diesen benötigt?");
				if (a == addBits(x1))
					richtig++;
				else {
					println("Falsch! " + addBits(x1) + " ist richtig");
					break;
				}
				q[19] = -1;
				counter++;
			}
			if (frage == 20 && q[20] == 0) {
				int x1 = (int) Math.pow(2, (int) (Math.random() * (level + 2)));
				int x2 = 1 + (int) (Math.random() * (level + 2));
				String a = readLine("Ein Computersystem besitzt " + x1 + " virtuelle Seiten und " + x2
						+ " Bit Seitenoffset(Byteadressierung)\nWie viel virtuellen Speicher hat das System?");
				if (einheit2Byte(a) == x1 * Math.pow(2, x2))
					richtig++;
				else {
					println("Falsch! " + x1 * Math.pow(2, x2) + " ist richtig");
					break;
				}
				q[20] = -1;
				counter++;
			}
			if (frage == 21 && q[21] == 0) {
				int x1 = 1 + (int) (Math.random() * 10 * Math.pow(2, level));
				int a = readInt("Ein Computersystem besitzt " + x1
						+ " physische Seiten\nWie viele Bits werden für die Adressierung von diesen benötigt?");
				if (a == addBits(x1))
					richtig++;
				else {
					println("Falsch! " + addBits(x1) + " ist richtig");
					break;
				}
				q[21] = -1;
				counter++;
			}
			if (frage == 22 && q[22] == 0) {
				int x1 = (int) Math.pow(2, (int) (Math.random() * (level + 2)));
				int x2 = 1 + (int) (Math.random() * (level + 2));
				String a = readLine("Ein Computersystem besitzt " + x1 + " physische Seiten und " + x2
						+ " Bit Seitenoffset(Byteadressierung)\nWie viel physischen Speicher(Byte) hat das System?");
				if (einheit2Byte(a) == x1 * Math.pow(2, x2))
					richtig++;
				else {
					println("Falsch! " + x1 * Math.pow(2, x2) + " ist richtig");
					break;
				}
				q[22] = -1;
				counter++;
			}
			if (frage == 23 && q[23] == 0) {
				int x1 = 1 + (int) (Math.random() * 1.5 * level);
				int x2 = (int) (Math.random() * 1.5 * level);
				int x3 = 1 + (int) (Math.random() * 1.5 * level);
				int x4 = (int) (Math.random() * 1.5 * level);
				String a = readLine(x2 + "/" + x1 + " + " + x4 + "/" + x3 + "\n");
				if (a.equals(bruchrechnenAdd(x2, x1, x4, x3)))
					richtig++;
				else {
					println("Falsch! " + bruchrechnenAdd(x2, x1, x4, x3) + " ist richtig");
					break;
				}
				q[23] = -1;
				counter++;
			}
			if (frage == 24 && q[24] == 0) {
				int x1 = 1 + (int) (Math.random() * 1.5 * level);
				int x2 = (int) (Math.random() * 1.5 * level);
				int x3 = 1 + (int) (Math.random() * 1.5 * level);
				int x4 = (int) (Math.random() * 1.5 * level);
				String a = readLine(x2 + "/" + x1 + " - " + x4 + "/" + x3 + "\n");
				if (a.equals(bruchrechnenSub(x2, x1, x4, x3)))
					richtig++;
				else {
					println("Falsch! " + bruchrechnenSub(x2, x1, x4, x3) + " ist richtig");
					break;
				}
				q[24] = -1;
				counter++;
			}
			if (frage == 25 && q[25] == 0) {
				int x1 = 1 + (int) (Math.random() * 2 * level);
				int x2 = (int) (Math.random() * 2 * level);
				int x3 = 1 + (int) (Math.random() * 2 * level);
				int x4 = (int) (Math.random() * 2 * level);
				String a = readLine(x2 + "/" + x1 + " * " + x4 + "/" + x3 + "\n");
				if (a.equals(bruchrechnenMul(x2, x1, x4, x3)))
					richtig++;
				else {
					println("Falsch! " + bruchrechnenMul(x2, x1, x4, x3) + " ist richtig");
					break;
				}
				q[25] = -1;
				counter++;
			}
			if (frage == 26 && q[26] == 0) {
				int x1 = 1 + (int) (Math.random() * 2 * level);
				int x2 = (int) (Math.random() * 2 * level);
				int x3 = 1 + (int) (Math.random() * 2 * level);
				int x4 = 1 + (int) (Math.random() * 2 * level);
				String a = readLine(x2 + "/" + x1 + " : " + x4 + "/" + x3 + "\n");
				if (a.equals(bruchrechnenDiv(x2, x1, x4, x3)))
					richtig++;
				else {
					println("Falsch! " + bruchrechnenDiv(x2, x1, x4, x3) + " ist richtig");
					break;
				}
				q[26] = -1;
				counter++;
			}
			if (frage == 27 && q[27] == 0) {
				int x1 = 1 + (int) (Math.random() * (8 + 2 * level * level));
				int x2 = 1 + (int) (Math.random() * (8 + 2 * level * level));
				int a = readInt("größter gemeinsamer Teiler von " + x1 + " und " + x2 + "\n");
				if (a == ggt(x1, x2))
					richtig++;
				else {
					println("Falsch! " + ggt(x1, x2) + " ist richtig");
					break;
				}
				q[27] = -1;
				counter++;
			}
			if (frage == 28 && q[28] == 0) {
				int x1 = 1 + (int) (Math.random() * (8 + 2 * level));
				int x2 = 1 + (int) (Math.random() * (8 + 2 * level));
				int a = readInt("kleinstes gemeinsames Vielfaches von " + x1 + " und " + x2 + "\n");
				if (a == x1 * x2 / ggt(x1, x2))
					richtig++;
				else {
					println("Falsch! " + x1 * x2 / ggt(x1, x2) + " ist richtig");
					break;
				}
				q[28] = -1;
				counter++;
			}
			if (frage == 29 && q[29] == 0) {
				int[] reihe = zahlenreihen(level);
				int[] rh = new int[4];
				for (int i = 0; i < 4; i++)
					rh[i] = reihe[i];
				String s = Arrays.toString(rh);
				int a = readInt("nächste Zahl der Reihe: " + s + "\n");
				if (a == reihe[4])
					richtig++;
				else {
					println("Falsch! " + reihe[4] + " ist richtig");
					break;
				}
				q[29] = -1;
				counter++;
			}
			if (frage == 30 && q[30] == 0) {
				int x1 = 1 + (int) (Math.random() * (2 + 0.5 * level));
				int x2 = 1 + (int) (Math.random() * (2 + 0.5 * level));
				int x3 = 1 + (int) (Math.random() * (2 + 0.5 * level));
				int x4 = (int) (Math.random() * (3 + 0.5 * level));
				String a = readLine("Welche Kapazität (K) hat eine Festplatte mit " + x1 + " Platten, " + x2
						+ " Zylindern, durchschnittlich " + x3 + " Sektoren pro Spurund " + x4 + " Byte pro Sektor?");
				if (einheit2ByteSI(a) == x1 * x2 * x3 * 2 * x4)
					richtig++;
				else {
					println("Falsch! " + x1 * x2 * x3 * 2 * x4 + " Byte ist richtig");
					break;
				}
				q[30] = -1;
				counter++;
			}
			if (frage == 31 && q[31] == 0) {
				int x1 = (int) (Math.random() * (30 + 4 * level));
				String a = readLine("2 ^ " + x1 + " Byte\n");
				if (einheit2Byte(a) == Math.pow(2, x1))
					richtig++;
				else {
					println("Falsch! " + byte2Einheit(Math.pow(2, x1)) + " ist richtig");
					break;
				}
				q[31] = -1;
				counter++;
			}
			if (frage == 32 && q[32] == 0) {
				int x1 = (int) (Math.random() * 3 * Math.pow(1.5, level));
				String a = readLine("Binär zu Hexadezimal(" + Integer.toBinaryString(x1) + ")\n");
				if (a.equals(Integer.toHexString(x1)))
					richtig++;
				else {
					println("Falsch! " + Integer.toHexString(x1) + " ist richtig");
					break;
				}
				q[32] = -1;
				counter++;
			}
			if (frage == 33 && q[33] == 0) {
				int x1 = (int) (Math.random() * 3 * Math.pow(1.5, level));
				String a = readLine("Hexadezimal zu Binär(" + Integer.toHexString(x1) + ")\n");
				if (a.contains("1"))
					a = a.substring(a.indexOf("1"));
				else
					a = "0";
				if (a.equals(Integer.toBinaryString(x1)))
					richtig++;
				else {
					println("Falsch! " + Integer.toBinaryString(x1) + " ist richtig");
					break;
				}
				q[33] = -1;
				counter++;
			}
			if (frage == 34 && q[34] == 0) {
				int x1 = 1 + (int) (Math.random() * (1 + 2 * level));
				int a = readInt("Bais einer Gleitkommazahl mit " + x1 + " Bit Exponent\n");
				if (a == Math.pow(2, x1 - 1) - 1)
					richtig++;
				else {
					println("Falsch! " + (Math.pow(2, x1 - 1) - 1) + " ist richtig");
					break;
				}
				q[34] = -1;
				counter++;
			}
			if (frage == 35 && q[35] == 0) {
				int x1 = 2;
				int x2 = -1 - (int) (Math.random() * (2 + level));
				double a = readDouble(x1 + " ^ " + x2 + "\n");
				if (a == Math.pow(x1, x2))
					richtig++;
				else {
					println("Falsch! " + Math.pow(x1, x2) + " ist richtig");
					break;
				}
				q[35] = -1;
				counter++;
			}
			if (frage == 36 && q[36] == 0) {
				int x1, x2, x3, x4;
				x1 = 1 + (int) (Math.random() * (4 + level));
				x2 = 1 + (int) (Math.random() * (4 + level));
				x4 = (int) (Math.random() * (5 + level));
				if (Math.random() < 0.5)
					x3 = x1;
				else
					x3 = x2;
				int a = readInt(x1 + " * " + x2 + " + " + x3 + " * " + x4);
				if (a == x1 * x2 + x3 * x4)
					richtig++;
				else {
					println("Falsch! " + (x1 * x2 + x3 * x4) + " ist richtig");
					break;
				}
				q[36] = -1;
				counter++;
			}
//			if (frage == 37 && q[37] == 0) {
//				int x1 = 500 + (int) (Math.random() * 2000);
//				int x2 = 500 + (int) (Math.random() * 2000);
//				int x3 = (int) (Math.random() * (level + 1));
//				double x4 = ((int) (Math.random() * 3)) / 2.0;
//				double a = readInt("Elo A: " + x1 + "  Elo B: " + x2 + "  k: " + x3 + "  SA: " + x4);
//				if (a == elo(x1, x2, x3, x4))
//					richtig++;
//				else {
//					println("Falsch! " + elo(x1, x2, x3, x4) + " ist richtig");
//					break;
//				}
//				q[37] = -1;
//				counter++;
//			}
		}

		if (richtig < level * 10) {
			bonuszeit = 0;
			String s = null;
			if (richtig <= 7)
				s = "Du musst noch viel lernen!";
			if (richtig > 7)
				s = "Sehr löblich!";
			if (richtig >= 15)
				s = "Nice!";
			if (richtig >= 30)
				s = "Respekt!";
			if (richtig >= 50)
				s = "Unerreichbar!";
			if (richtig >= 100)
				s = "Unbesiegbar!";
			print(richtig + " Punkte" + "\n" + s + "\n");
			highscore(richtig);
			int neu = 0;
			while (neu != 1) {
				neu = readInt("1 = Erneut spielen, 2 = Highscore, 3 = Ende\n");
				if (neu == 2)
					showHighscore();
				if (neu == 3)
					sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
				if (sicher == 1)
					exit();
				if (neu == 1) {
					level = 1;
					richtig = 0;
					start = 0;
					run();
				}
			}
		} else {
			bonuszeit = zeitbegrenzung - zeit;
			level++;
			run();
		}
	}

	public void highscore(double punkte) {
		int i = 0;
		if (score[0][0] == null)
			for (i = 0; i <= 9; i++) {
				score[i][0] = "0";
				score[i][1] = "";
			}
		for (i = 0; i <= 9; i++) {
			if (richtig > Double.valueOf(score[i][0])) {
				Double scoreDouble = new Double(richtig);
				String s = scoreDouble.toString();
				for (int j = 9; j >= 1; j--) {
					score[i + j][0] = score[i + j - 1][0];
					score[i + j][1] = score[i + j - 1][1];
				}
				score[i][0] = s;
				score[i][1] = readLine("Name:");
				break;
			}
		}

	}

	public void showHighscore() {
		println(score[0][0] + " " + score[0][1] + "\n" + score[1][0] + " " + score[1][1] + "\n" + score[2][0] + " "
				+ score[2][1] + "\n" + score[3][0] + " " + score[3][1] + "\n" + score[4][0] + " " + score[4][1] + "\n"
				+ score[5][0] + " " + score[5][1] + "\n" + score[6][0] + " " + score[6][1] + "\n" + score[7][0] + " "
				+ score[7][1] + "\n" + score[8][0] + " " + score[8][1] + "\n" + score[9][0] + " " + score[9][1] + "\n");
	}

	public int addBits(int i) {
		if (i == 1)
			return 1;
		double d = Math.log(i) / Math.log(2);
		int a = (d == (int) d) ? (int) d : ((int) d) + 1;
		return a;
	}

	public int ggt(int n1, int n2) {
		n1 = Math.abs(n1);
		n2 = Math.abs(n2);
		while (n2 != 0) {
			if (n1 > n2)
				n1 -= n2;
			else
				n2 -= n1;
		}
		return n1;
	}

	public String bruchrechnen(int ze, int ne) {
		int zahl = 0;
		int teiler = ggt(ne, ze);
		ze /= teiler;
		ne /= teiler;
		if (ne == 0)
			return "0";
		if (ne == 1)
			return String.valueOf(ze);
		zahl = ze / ne;
		if (zahl != 0)
			return (zahl + " " + ze % ne + "/" + ne);
		return (ze + "/" + ne);
	}

	public String bruchrechnenAdd(int z1, int n1, int z2, int n2) {
		int ze = z1 * n2 + z2 * n1;
		int ne = n1 * n2;
		return bruchrechnen(ze, ne);
	}

	public String bruchrechnenSub(int z1, int n1, int z2, int n2) {
		int ze = z1 * n2 - z2 * n1;
		int ne = n1 * n2;
		return bruchrechnen(ze, ne);
	}

	public String bruchrechnenMul(int z1, int n1, int z2, int n2) {
		int ze = z1 * z2;
		int ne = n1 * n2;
		return bruchrechnen(ze, ne);
	}

	public String bruchrechnenDiv(int z1, int n1, int z2, int n2) {
		int ze = z1 * n2;
		int ne = n1 * z2;
		return bruchrechnen(ze, ne);
	}

	public int[] zahlenreihen(int level) {
		int[] reihe1 = new int[5];
		int[] reihe2 = new int[4];
		int[] reihe3 = new int[3];
		int[] reihe4 = new int[2];
		reihe1[0] = (int) (Math.random() * (level + 3));
		reihe2[0] = (int) (Math.random() * (level + 3));
		reihe3[0] = (int) Math.max((Math.random() * level - 0.8), 0);
		reihe4[0] = (int) Math.max((Math.random() * level - 2.5), 0);
		if (Math.random() < Math.min(0.5, level * 0.1))
			reihe1[0] *= -1;
		if (Math.random() < Math.min(0.5, level * 0.1))
			reihe2[0] *= -1;
		if (Math.random() < Math.min(0.5, level * 0.1))
			reihe3[0] *= -1;
		if (Math.random() < Math.min(0.5, level * 0.1))
			reihe4[0] *= -1;
		for (int i = 1; i < 2; i++) {
			reihe4[i] = reihe4[i - 1];
		}
		for (int i = 1; i < 3; i++) {
			reihe3[i] = reihe3[i - 1] + reihe4[i - 1];
		}
		for (int i = 1; i < 4; i++) {
			reihe2[i] = reihe2[i - 1] + reihe3[i - 1];
		}
		for (int i = 1; i < 5; i++) {
			reihe1[i] = reihe1[i - 1] + reihe2[i - 1];
		}
		return reihe1;
	}

	double einheit2Byte(String s) {
		s = s.toLowerCase();
		double z;
		if (s.contains("ebyte")) {
			z = Double.valueOf(s.substring(0, s.indexOf("ebyte")));
			return z * Math.pow(1024, 6);
		} else if (s.contains("p")) {
			z = Double.valueOf(s.substring(0, s.indexOf("p")));
			return z * Math.pow(1024, 5);
		} else if (s.contains("tbyte")) {
			z = Double.valueOf(s.substring(0, s.indexOf("tbyte")));
			return z * Math.pow(1024, 4);
		} else if (s.contains("g")) {
			z = Double.valueOf(s.substring(0, s.indexOf("g")));
			return z * Math.pow(1024, 3);
		} else if (s.contains("m")) {
			z = Double.valueOf(s.substring(0, s.indexOf("m")));
			return z * Math.pow(1024, 2);
		} else if (s.contains("k")) {
			z = Double.valueOf(s.substring(0, s.indexOf("k")));
			return z * Math.pow(1024, 1);
		} else if (s.contains("byte")) {
			z = Double.valueOf(s.substring(0, s.indexOf("byte")));
			return z;
		} else
			return Double.valueOf(s);
	}

	double einheit2ByteSI(String s) {
		s = s.toLowerCase();
		double z;
		if (s.contains("ebyte")) {
			z = Double.valueOf(s.substring(0, s.indexOf("ebyte")));
			return z * Math.pow(1000, 6);
		} else if (s.contains("p")) {
			z = Double.valueOf(s.substring(0, s.indexOf("p")));
			return z * Math.pow(1000, 5);
		} else if (s.contains("tbyte")) {
			z = Double.valueOf(s.substring(0, s.indexOf("tbyte")));
			return z * Math.pow(1000, 4);
		} else if (s.contains("g")) {
			z = Double.valueOf(s.substring(0, s.indexOf("g")));
			return z * Math.pow(1000, 3);
		} else if (s.contains("m")) {
			z = Double.valueOf(s.substring(0, s.indexOf("m")));
			return z * Math.pow(1000, 2);
		} else if (s.contains("k")) {
			z = Double.valueOf(s.substring(0, s.indexOf("k")));
			return z * Math.pow(1000, 1);
		} else if (s.contains("byte")) {
			z = Double.valueOf(s.substring(0, s.indexOf("byte")));
			return z;
		} else
			return Double.valueOf(s);
	}

	String byte2Einheit(double d) {
		String e = "";
		String z = "";
		if (d >= Math.pow(1024, 6)) {
			e = " EByte";
			z = String.valueOf(d / Math.pow(1024, 6));
		} else if (d >= Math.pow(1024, 5)) {
			e = " PByte";
			z = String.valueOf(d / Math.pow(1024, 5));
		} else if (d >= Math.pow(1024, 4)) {
			e = " TByte";
			z = String.valueOf(d / Math.pow(1024, 4));
		} else if (d >= Math.pow(1024, 5)) {
			e = " GByte";
			z = String.valueOf(d / Math.pow(1024, 3));
		} else if (d >= Math.pow(1024, 2)) {
			e = " MByte";
			z = String.valueOf(d / Math.pow(1024, 2));
		} else if (d >= Math.pow(1024, 1)) {
			e = " KByte";
			z = String.valueOf(d / Math.pow(1024, 1));
		} else {
			e = " Byte";
			z = String.valueOf(d);
		}
		return z + e;
	}

	String byte2EinheitSI(double d) {
		String e = "";
		String z = "";
		if (d >= Math.pow(1000, 6)) {
			e = " EByte";
			z = String.valueOf(d / Math.pow(1000, 6));
		} else if (d >= Math.pow(1000, 5)) {
			e = " PByte";
			z = String.valueOf(d / Math.pow(1000, 5));
		} else if (d >= Math.pow(1000, 4)) {
			e = " TByte";
			z = String.valueOf(d / Math.pow(1000, 4));
		} else if (d >= Math.pow(1000, 5)) {
			e = " GByte";
			z = String.valueOf(d / Math.pow(1000, 3));
		} else if (d >= Math.pow(1000, 2)) {
			e = " MByte";
			z = String.valueOf(d / Math.pow(1000, 2));
		} else if (d >= Math.pow(1000, 1)) {
			e = " KByte";
			z = String.valueOf(d / Math.pow(1000, 1));
		} else {
			e = " Byte";
			z = String.valueOf(d);
		}
		return z + e;
	}

	public int[] nextSqrt(int i) {
		int[] t = { 0, 0, 0, 0, 0, 0 };
		int max = 0;
		int[] ret = { 0, 0 };
		while (Math.pow(t[0], 2) <= i) {
			t[0]++;
		}
		t[0]--;
		if (max < Math.pow(t[0], 2)) {
			max = (int) Math.pow(t[0], 2);
			ret[0] = t[0];
			ret[1] = 2;
		}
		while (Math.pow(t[1], 3) <= i) {
			t[1]++;
		}
		t[1]--;
		if (max < Math.pow(t[1], 3)) {
			max = (int) Math.pow(t[1], 3);
			ret[0] = t[1];
			ret[1] = 3;
		}
		while (Math.pow(t[2], 4) <= i) {
			t[2]++;
		}
		t[2]--;
		if (max < Math.pow(t[2], 4)) {
			max = (int) Math.pow(t[2], 4);
			ret[0] = t[2];
			ret[1] = 4;
		}
		while (Math.pow(t[3], 5) <= i) {
			t[3]++;
		}
		t[3]--;
		if (max < Math.pow(t[3], 5)) {
			max = (int) Math.pow(t[3], 5);
			ret[0] = t[3];
			ret[1] = 5;
		}
		while (Math.pow(t[4], 6) <= i) {
			t[4]++;
		}
		t[4]--;
		if (max < Math.pow(t[4], 6)) {
			max = (int) Math.pow(t[4], 6);
			ret[0] = t[4];
			ret[1] = 6;
		}
		while (Math.pow(t[5], 7) <= i) {
			t[5]++;
		}
		t[5]--;
		if (max < Math.pow(t[5], 7)) {
			max = (int) Math.pow(t[5], 7);
			ret[0] = t[5];
			ret[1] = 7;
		}

		return ret;

	}

	public int elo(int RA, int RB, int k, double SA) {
		double EA = 1 / (1 + Math.pow(10, (RB - RA) / 400.0));
		double RAnew = RA + k * (SA - EA);
		if (RAnew >= 0)
			RAnew += 0.5;
		else
			RAnew -= 0.5;
		return (int) RAnew;
	}
	
	
	

	public static void main(String[] args) {
		new MatheFuerInformatiker().start(args);
	}
}
