// Dichten lernen Java
package e1;

import java.util.Arrays;

import acm.program.DialogProgram;
import acm.program.GraphicsProgram;

public class Dichten extends DialogProgram {
	/**
	 * PartyTest
	 * Created on Mar 14, 2015
	 * @author Andreas
	 */
	private static final long serialVersionUID = 1L;
	
	String[][] score = new String[20][2];
	int level = 1;
	double richtig = 0;
	int start =  0;
	int sicher = 0;
	int[] q = new int[50];
	long bonuszeit = 0;
	int vierBlock1=0;
	int vierBlock2=0;
	int vierBlock3=1;
	int vierBlock4=2;
	
	public void run() {
		long zeitbegrenzung = 60000 + bonuszeit;
		long sekunden = zeitbegrenzung/1000;
		int counter = 0;
		long zeitAfter = 0;
		while(start != 1){
			if(start == 3) sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
			if(start==3 && sicher==1) exit();
			if(start==2) showHighscore();
		start = readInt("1 = Start, 2 = Highscore, 3 = Ende\n");}
		println("Level "+level+ " (Zeitbegrenzung = "+ sekunden + "s)");
		
		long zeitBefore = System.currentTimeMillis();
		long zeit = 0;
		while(counter < 10){
			zeitAfter = System.currentTimeMillis();
			 zeit = zeitAfter - zeitBefore;
		if(zeit > zeitbegrenzung) {println("Zeitüberschreitung!"); break;}
		int frage = (int)(Math.random() * 50);
		if(frage == 0 && Math.random() > 0.9) for(int i = 0; i < q.length; i++) q[i] = 0;
		if(frage == 1 && q[1] == 0)  {double a = readDouble("Dichte von Eisen: "); if (a==7.87) richtig++; else {println("Falsch! " + 7.87+ " ist richtig"); break;} q[1] = -1; counter++;}
		if(frage == 2 && q[2] == 0)  {double a = readDouble("Dichte von Aluminium: "); if (a==2.7) richtig++; else {println("Falsch! " + 2.7+ " ist richtig"); break;} q[2] = -1; counter++;}
		if(frage == 3 && q[3] == 0)  {double a = readDouble("Dichte von Kupfer: "); if (a==8.92) richtig++; else {println("Falsch! " + 8.92+ " ist richtig"); break;} q[3] = -1; counter++;}
		if(frage == 4 && q[4] == 0)  {double a = readDouble("Dichte von Silber: "); if (a==10.49) richtig++; else {println("Falsch! " + 10.49+ " ist richtig"); break;} q[4] = -1; counter++;}
		if(frage == 5 && q[5] == 0 && level>vierBlock1)  {double a = readDouble("Dichte von Zinn: "); if (a==7.26) richtig++; else {println("Falsch! " + 7.26+ " ist richtig"); break;} q[5] = -1; counter++;}
		if(frage == 6 && q[6] == 0&& level>vierBlock1)  {double a = readDouble("Dichte von Platin: "); if (a==21.45) richtig++; else {println("Falsch! " + 21.45+ " ist richtig"); break;} q[6] = -1; counter++;}
		if(frage == 7 && q[7] == 0&& level>vierBlock1)  {double a = readDouble("Dichte von Gold: "); if (a==19.32) richtig++; else {println("Falsch! " + 19.32+ " ist richtig"); break;} q[7] = -1; counter++;}
		if(frage == 8 && q[8] == 0&& level>vierBlock1)  {double a = readDouble("Dichte von Blei: "); if (a==11.35) richtig++; else {println("Falsch! " + 11.35+ " ist richtig"); break;} q[8] = -1; counter++;}
		if(frage == 9 && q[9] == 0&& level>vierBlock2)  {double a = readDouble("Dichte von Natrium: "); if (a==0.97) richtig++; else {println("Falsch! " + 0.97+ " ist richtig"); break;} q[9] = -1; counter++;}
		if(frage == 10 && q[10] == 0&& level>vierBlock2)  {double a = readDouble("Dichte von Magnesium: "); if (a==1.74) richtig++; else {println("Falsch! " + 1.74+ " ist richtig"); break;} q[10] = -1; counter++;}
		if(frage == 11 && q[11] == 0&& level>vierBlock2)  {double a = readDouble("Dichte von Kalium: "); if (a==0.86) richtig++; else {println("Falsch! " + 0.86+ " ist richtig"); break;} q[11] = -1; counter++;}
		if(frage == 12 && q[12] == 0&& level>vierBlock2)  {double a = readDouble("Dichte von Chrom: "); if (a==7.14) richtig++; else {println("Falsch! " + 7.14+ " ist richtig"); break;} q[12] = -1; counter++;}
		if(frage == 13 && q[13] == 0&& level>vierBlock3)  {double a = readDouble("Dichte von Wasser: "); if (a==1) richtig++; else {println("Falsch! " + 1+ " ist richtig"); break;} q[13] = -1; counter++;}
		if(frage == 14 && q[14] == 0&& level>vierBlock3)  {double a = readDouble("Dichte von Kohlenstoff: "); if (a==2.26) richtig++; else {println("Falsch! " + 2.26+ " ist richtig"); break;} q[14] = -1; counter++;}
		if(frage == 15 && q[15] == 0&& level>vierBlock3)  {double a = readDouble("Dichte von Sauerstoff: "); if (a==0.0014) richtig++; else {println("Falsch! " + 0.0014+ " ist richtig"); break;} q[15] = -1; counter++;}
		if(frage == 16 && q[16] == 0&& level>vierBlock3)  {double a = readDouble("Dichte von Helium: "); if (a==0.00018) richtig++; else {println("Falsch! " + 0.00018+ " ist richtig"); break;} q[16] = -1; counter++;}
		if(frage == 17 && q[17] == 0&& level>vierBlock4)  {double a = readDouble("Dichte von Wasserstoff: "); if (a==0.00009) richtig++; else {println("Falsch! " + 0.00009+ " ist richtig"); break;} q[17] = -1; counter++;}
		if(frage == 18 && q[18] == 0&& level>vierBlock4)  {double a = readDouble("Dichte von Neon: "); if (a==0.0009) richtig++; else {println("Falsch! " + 0.0009+ " ist richtig"); break;} q[18] = -1; counter++;}
		if(frage == 19 && q[19] == 0&& level>vierBlock4)  {double a = readDouble("Dichte von Titan: "); if (a==4.5) richtig++; else {println("Falsch! " + 4.5+ " ist richtig"); break;} q[19] = -1; counter++;}
		if(frage == 20 && q[20] == 0&& level>vierBlock4)  {double a = readDouble("Dichte von Schwefel: "); if (a==2.07) richtig++; else {println("Falsch! " + 2.07+ " ist richtig"); break;} q[20] = -1; counter++;}
		}
		
		if (richtig < level * 10) {
			bonuszeit = 0;
			String s = null;
			if (richtig <= 7)
				s = "Du musst noch viel lernen!";
			if (richtig > 7)
				s = "Sehr löblich!";
			if (richtig >= 15)
				s = "Nice!";
			if (richtig >= 30)
				s = "Respekt!";
			if (richtig >= 50)
				s = "Unerreichbar!";
			if (richtig >= 75)
				s = "Godlike!";
			if (richtig >= 100)
				s = "Unbesiegbar!";
			print(richtig + " Punkte" + "\n" + s + "\n");
			highscore(richtig);
			int neu = 0;
			while (neu != 1) {
				neu = readInt("1 = Erneut spielen, 2 = Highscore, 3 = Ende\n");
				if(neu==2) showHighscore();
				if (neu == 3) sicher = readInt("Wirklich beenden?\n1 = Ja, 2 = Nein\n");
				if (sicher == 1) exit();
				if (neu == 1) {
					level = 1;
					richtig = 0;
					start = 0;
					run();
				}
			}
		} else {
			bonuszeit = zeitbegrenzung - zeit;
			level++;
					run();	
		}
	}

	public void highscore(double punkte) {
		int i = 0;
		if (score[0][0] == null)
			for (i = 0; i <= 9; i++) {
				score[i][0] = "0";
				score[i][1] = "";
			}
		for (i = 0; i <= 9; i++) {
			if (richtig > Double.valueOf(score[i][0])) {
				Double scoreDouble = new Double(richtig);
				String s = scoreDouble.toString();
				for (int j = 9; j >= 1; j--) {
					score[i + j][0] = score[i + j - 1][0];
					score[i + j][1] = score[i + j - 1][1];
				}
				score[i][0] = s;
				score[i][1] = readLine("Name:");
				break;
			}
		}

	}

	public void showHighscore() {
		println(score[0][0] + " " + score[0][1] + "\n" + score[1][0] + " "
				+ score[1][1] + "\n" + score[2][0] + " " + score[2][1] + "\n"
				+ score[3][0] + " " + score[3][1] + "\n" + score[4][0] + " "
				+ score[4][1] + "\n" + score[5][0] + " " + score[5][1] + "\n"
				+ score[6][0] + " " + score[6][1] + "\n" + score[7][0] + " "
				+ score[7][1] + "\n" + score[8][0] + " " + score[8][1] + "\n"
				+ score[9][0] + " " + score[9][1] + "\n");
	}
	
	public int addBits(int i){
		if (i==1) return 1;
		double d = Math.log(i)/Math.log(2);
		int a = (d == (int)d)? (int)d : ((int)d)+1;
		return a;
	}

	public int ggt(int n1, int n2){
		n1 = Math.abs(n1);
		n2 = Math.abs(n2);
		while(n2 != 0){
			if(n1 > n2) n1 -= n2;
			else n2 -= n1;
		}
		return n1;
	}
	
	public String bruchrechnen(int ze, int ne){
		int zahl = 0;
		int teiler = ggt(ne, ze);
		ze /= teiler;
		ne /= teiler;
		if(ne == 0) return "0";
		if(ne == 1) return String.valueOf(ze);
		zahl = ze/ne;
		if(zahl != 0) return(zahl+ " "+ze % ne+"/"+ne);
		return(ze+"/"+ne);
	}
	public String bruchrechnenAdd(int z1, int n1, int z2, int n2){
		int ze = z1*n2+z2*n1;
		int ne = n1*n2;
		return bruchrechnen(ze, ne);
	}
	
	public String bruchrechnenSub(int z1, int n1, int z2, int n2){
		int ze = z1*n2-z2*n1;
		int ne = n1*n2;
		return bruchrechnen(ze, ne);
	}
	
	public String bruchrechnenMul(int z1, int n1, int z2, int n2){
		int ze = z1*z2;
		int ne = n1*n2;
		return bruchrechnen(ze, ne);
	}
	
	public String bruchrechnenDiv(int z1, int n1, int z2, int n2){
		int ze = z1*n2;
		int ne = n1*z2;
		return bruchrechnen(ze, ne);
	}
	
	public int[] zahlenreihen(int level){
		int[] reihe1 = new int[5];
		int[] reihe2 = new int[4];
		int[] reihe3 = new int[3];
		int[] reihe4 = new int[2];
		reihe1[0] = (int)(Math.random() * (level+3));
		reihe2[0] = (int)(Math.random() * (level+3));
		reihe3[0] = (int) Math.max((Math.random() * level - 0.8) , 0);
		reihe4[0] = (int) Math.max((Math.random() * level - 2.5) , 0);
		if(Math.random() < Math.min(0.5, level*0.1)) reihe1[0] *= -1;
		if(Math.random() < Math.min(0.5, level*0.1)) reihe2[0] *= -1;
		if(Math.random() < Math.min(0.5, level*0.1)) reihe3[0] *= -1;
		if(Math.random() < Math.min(0.5, level*0.1)) reihe4[0] *= -1;
		for(int i=1; i<2; i++){
			reihe4[i] = reihe4[i-1];
		}
		for(int i=1; i<3; i++){
			reihe3[i] = reihe3[i-1] + reihe4[i-1];
		}
		for(int i=1; i<4; i++){
			reihe2[i] = reihe2[i-1] + reihe3[i-1];
		}
		for(int i=1; i<5; i++){
			reihe1[i] = reihe1[i-1] + reihe2[i-1];
		}
		return reihe1;
	}
	
	double einheit2Byte(String s){
		s = s.toLowerCase();
		double z;
		if(s.contains("ebyte")){z = Double.valueOf(s.substring(0, s.indexOf("ebyte"))); return z*Math.pow(1024,6);}
		else if(s.contains("p")){z = Double.valueOf(s.substring(0, s.indexOf("p"))); return z*Math.pow(1024,5);}
		else if(s.contains("tbyte")){z = Double.valueOf(s.substring(0, s.indexOf("tbyte"))); return z*Math.pow(1024,4);}
		else if(s.contains("g")){z = Double.valueOf(s.substring(0, s.indexOf("g"))); return z*Math.pow(1024,3);}
		else if(s.contains("m")){z = Double.valueOf(s.substring(0, s.indexOf("m"))); return z*Math.pow(1024,2);}
		else if(s.contains("k")){z = Double.valueOf(s.substring(0, s.indexOf("k"))); return z*Math.pow(1024,1);}
		else if(s.contains("byte")){z = Double.valueOf(s.substring(0, s.indexOf("byte"))); return z;}
		else return Double.valueOf(s);
	}
	
	double einheit2ByteSI(String s){
		s = s.toLowerCase();
		double z;
		if(s.contains("ebyte")){z = Double.valueOf(s.substring(0, s.indexOf("ebyte"))); return z*Math.pow(1000,6);}
		else if(s.contains("p")){z = Double.valueOf(s.substring(0, s.indexOf("p"))); return z*Math.pow(1000,5);}
		else if(s.contains("tbyte")){z = Double.valueOf(s.substring(0, s.indexOf("tbyte"))); return z*Math.pow(1000,4);}
		else if(s.contains("g")){z = Double.valueOf(s.substring(0, s.indexOf("g"))); return z*Math.pow(1000,3);}
		else if(s.contains("m")){z = Double.valueOf(s.substring(0, s.indexOf("m"))); return z*Math.pow(1000,2);}
		else if(s.contains("k")){z = Double.valueOf(s.substring(0, s.indexOf("k"))); return z*Math.pow(1000,1);}
		else if(s.contains("byte")){z = Double.valueOf(s.substring(0, s.indexOf("byte"))); return z;}
		else return Double.valueOf(s);
	}
	
	String byte2Einheit(double d){
		String e="";
		String z="";
		if(d >= Math.pow(1024, 6)){e = " EByte"; z=String.valueOf(d/Math.pow(1024, 6));}
		else if(d >= Math.pow(1024, 5)){e = " PByte"; z=String.valueOf(d/Math.pow(1024, 5));}
		else if(d >= Math.pow(1024, 4)){e = " TByte"; z=String.valueOf(d/Math.pow(1024, 4));}
		else if(d >= Math.pow(1024, 5)){e = " GByte"; z=String.valueOf(d/Math.pow(1024, 3));}
		else if(d >= Math.pow(1024, 2)){e = " MByte"; z=String.valueOf(d/Math.pow(1024, 2));}
		else if(d >= Math.pow(1024, 1)){e = " KByte"; z=String.valueOf(d/Math.pow(1024, 1));}
		else                           {e = " Byte"; z=String.valueOf(d);}
		return z+e;
	}
	
	String byte2EinheitSI(double d){
		String e="";
		String z="";
		if(d >= Math.pow(1000, 6)){e = " EByte"; z=String.valueOf(d/Math.pow(1000, 6));}
		else if(d >= Math.pow(1000, 5)){e = " PByte"; z=String.valueOf(d/Math.pow(1000, 5));}
		else if(d >= Math.pow(1000, 4)){e = " TByte"; z=String.valueOf(d/Math.pow(1000, 4));}
		else if(d >= Math.pow(1000, 5)){e = " GByte"; z=String.valueOf(d/Math.pow(1000, 3));}
		else if(d >= Math.pow(1000, 2)){e = " MByte"; z=String.valueOf(d/Math.pow(1000, 2));}
		else if(d >= Math.pow(1000, 1)){e = " KByte"; z=String.valueOf(d/Math.pow(1000, 1));}
		else                           {e = " Byte"; z=String.valueOf(d);}
		return z+e;
	}
	
	public int[] nextSqrt(int i) {
		int[] t = { 0, 0, 0, 0, 0, 0 };
		int max = 0;
		int[] ret = { 0, 0 };
		while (Math.pow(t[0], 2) <= i) {
			t[0]++;
		}
		t[0]--;
		if (max < Math.pow(t[0], 2)) {
			max = (int) Math.pow(t[0], 2);
			ret[0] = t[0];
			ret[1] = 2;
		}
		while (Math.pow(t[1], 3) <= i) {
			t[1]++;
		}
		t[1]--;
		if (max < Math.pow(t[1], 3)) {
			max = (int) Math.pow(t[1], 3);
			ret[0] = t[1];
			ret[1] = 3;
		}
		while (Math.pow(t[2], 4) <= i) {
			t[2]++;
		}
		t[2]--;
		if (max < Math.pow(t[2], 4)) {
			max = (int) Math.pow(t[2], 4);
			ret[0] = t[2];
			ret[1] = 4;
		}
		while (Math.pow(t[3], 5) <= i) {
			t[3]++;
		}
		t[3]--;
		if (max < Math.pow(t[3], 5)) {
			max = (int) Math.pow(t[3], 5);
			ret[0] = t[3];
			ret[1] = 5;
		}
		while (Math.pow(t[4], 6) <= i) {
			t[4]++;
		}
		t[4]--;
		if (max < Math.pow(t[4], 6)) {
			max = (int) Math.pow(t[4], 6);
			ret[0] = t[4];
			ret[1] = 6;
		}
		while (Math.pow(t[5], 7) <= i) {
			t[5]++;
		}
		t[5]--;
		if (max < Math.pow(t[5], 7)) {
			max = (int) Math.pow(t[5], 7);
			ret[0] = t[5];
			ret[1] = 7;
		}

		return ret;

	}
	
	public int elo(int RA, int RB, int k, double SA){
		double EA = 1/(1 + Math.pow(10, (RB-RA)/400.0));
		double RAnew = RA + k * (SA - EA);
		if(RAnew >= 0) RAnew += 0.5;
		else RAnew -= 0.5;
		return (int) RAnew;
	}
	
	public static void main(String[] args) {
		new Dichten().start(args);
	}
}


