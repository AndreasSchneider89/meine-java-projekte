package p1;

import java.awt.Color;
import java.util.ArrayList;

public class MasseKugel {
//	public int basisEntro;
	public double basisEntroDouble;
	public double[] basisentros = new double[100];
	
	ArrayList<Double> angleichungswerte = new ArrayList<>(); //Ist noch unklar
	// Im Prinziep double[][] angleichungsmatrix x,y,z;vx,vy,vz,ax,ay,az mit entsprechenden updates pro Zeiteinheit
	
    public double x, y, z, vx, vy, vz, ax, ay, az, mass;
    public int radius;
    
    double time=255.0;
    
    // ToDo Integration der SI Basiseinheiten
//    4.1. SI-Basiseinheiten
//    Die 7 fundamentalen, voneinander unabhängigen Einheiten, auf denen das gesamte System aufbaut:
//    Sekunde (s) für die Zeit (T)
//    Meter (m) für die Länge (L)
//    Kilogramm (kg) für die Masse (M)
//    Ampere (A) für die elektrische Stromstärke (I)
//    Kelvin (K) für die Temperatur (Θ)
//    Mol (mol) für die Stoffmenge (N)
//    Candela (cd) für die Lichtstärke (J)
//    4.2. Abgeleitete SI-Einheiten (Auswahl)
//    Für die Praxis wichtige Einheiten, die aus den Basiseinheiten zusammengesetzt sind:
//    Hertz (Hz): Frequenz (s−1)
//    Newton (N): Kraft (kg⋅m⋅s−2)
//    Joule (J): Energie, Arbeit (kg⋅m2⋅s−2)
//    Watt (W): Leistung (kg⋅m2⋅s−3)
//    Volt (V): Elektrische Spannung (kg⋅m2⋅s−3⋅A−1)
//    Ohm (Ω): Elektrischer Widerstand (kg⋅m2⋅s−3⋅A−2)
//    Diese strukturierte Übersicht dient als Grundlage für die weitere Vereinheitlichung und den Ausbau deines "Matrixgames".

// Basisrotationen bzw. s-Orbitale bzw. zwei gegenüberliegende Planeten auf selber Umlaufbahn generieren
// Verlinkung zu kollektive Formelsammlung für das Matrixgame: https://docs.google.com/document/d/1dl1S4BTTNPSfTwKtxjbzwsjAxb3qWdeJceMTZKlln_g/edit?tab=t.0#heading=h.el3y6lpq67iw
    
    double rot;
    double green;
    double blue;
    
    public Color color;
    public boolean movable;
    
    double oberflächentemperatur;
	double erdbeschleunigung;
	boolean rotationsgebunden;
	boolean leben;
	boolean sonnenlicht;

    public MasseKugel(double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        this.mass = mass;
        this.radius = radius;
        this.color = color;
        this.movable=true;
        
        rot=color.getRed();
        green=color.getGreen();
        blue=color.getBlue();
        
        
    }
    
    public MasseKugel(double x, double y, double z, double vx, double vy, double vz, double mass, int radius) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        this.mass = mass;
        this.radius = radius;
       
        
        
    }

    public MasseKugel(double x, double y, double vx, double vy, double masse,  int radius, Color color2,
			boolean movable2) {
		// TODO Auto-generated constructor stub
    	 rot=color.getRed();
         green=color.getGreen();
         blue=color.getBlue();
	}
    
    public void angleichen(int typ,double faktor) {
    	faktor*=time*0.001;
		if (typ == 1) {
			double übertrag = basisEntroDouble - x;
			x += (übertrag * Math.random()*faktor);
			basisEntroDouble-=(übertrag * Math.random()*faktor);
		}
		if (typ == 2) {
			double übertrag = basisEntroDouble - y;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			y += (übertrag * Math.random()*faktor);
		}
		if (typ == 3) {
			double übertrag = basisEntroDouble - z;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			z += (übertrag * Math.random()*faktor);
		}
		if (typ == 4) {
			double übertrag =basisEntroDouble - vx;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			vx += (übertrag * Math.random()*faktor);
		}
		if (typ == 5) {
			double übertrag = basisEntroDouble - vy;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			vy += (übertrag * Math.random()*faktor);
		}
		if (typ == 6) {
			double übertrag = basisEntroDouble - vz;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			vz += (übertrag * Math.random()*faktor);
		}
		if (typ == 7) {
			double übertrag = basisEntroDouble - rot;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			rot += (übertrag * Math.random()*faktor);
		}
		if (typ == 8) {
			double übertrag = basisEntroDouble - green;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			green += (übertrag * Math.random()*faktor);
		}
		if (typ == 9) {
			double übertrag = basisEntroDouble - blue;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			blue += (übertrag * Math.random()*faktor);
		}
		
		if (typ == 10) {
			double übertrag = basisEntroDouble - time;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			time += (übertrag * Math.random()*faktor);
		}
		
		if (typ == 11) {
			double übertrag = basisEntroDouble - mass;
			basisEntroDouble -= (übertrag * Math.random()*faktor);
			mass += (übertrag * Math.random()*faktor);
		}
		
		// Weitere SI Einheiten und Einheiten aus Physik sowie kollektivem Bewusstsein und eigene Einheiten für das kollektive Matrixgame
		
		
		double übertrag = basisEntroDouble - basisentros[typ];
		basisEntroDouble -= (übertrag * Math.random()*faktor);
		basisentros[typ] += (übertrag * Math.random()*faktor);

	}
    
    public void basisRand(double time) {
		
			
			basisEntroDouble+=(Math.random()/Math.random()*time);
			basisEntroDouble-=(Math.random()/Math.random()*time);
			x+=(Math.random()/Math.random()*time);
			x-=(Math.random()/Math.random()*time);
			y+=(Math.random()/Math.random()*time);
			y-=(Math.random()/Math.random()*time);
			z+=(Math.random()/Math.random()*time);
			z-=(Math.random()/Math.random()*time);
			
			for(int i=0; i<basisentros.length; i++) {
				basisentros[i]+=(Math.random()/Math.random()*time);
				basisentros[i]-=(Math.random()/Math.random()*time);
			}
		
		
		
	}
    
    // unklar
    public void angleichen(MasseKugel mk, int typ, double faktor) {
		if (typ == 1) {
			double übertrag = basisEntroDouble - mk.basisEntroDouble;
			mk.basisEntroDouble -= (übertrag * Math.random()*faktor);
			basisEntroDouble += (übertrag * Math.random()*faktor);
		}
		if (typ == 2) {
			double übertrag = x - mk.x;
			mk.x += (übertrag * Math.random()*faktor);
			x -= (übertrag * Math.random()*faktor);
		}
		if (typ == 3) {
			double übertrag = y - mk.y;
			mk.y += (übertrag * Math.random()*faktor);
			y -= (übertrag * Math.random()*faktor);
		}
		if (typ == 4) {
			double übertrag = z - mk.z;
			mk.z += (übertrag * Math.random()*faktor);
			z -= (übertrag * Math.random()*faktor);
		}
		if (typ == 5) {
			double übertrag = vx - mk.vx;
			mk.vx += (übertrag * Math.random()*faktor);
			vx -= (übertrag * Math.random()*faktor);
		}
		if (typ == 6) {
			double übertrag = vy - mk.vy;
			mk.vy += (übertrag * Math.random()*faktor);
			vy -= (übertrag * Math.random()*faktor);
		}
		if (typ == 7) {
			double übertrag = vz - mk.vz;
			mk.vz += (übertrag * Math.random()*faktor);
			vz -= (übertrag * Math.random()*faktor);
		}
		if (typ == 8) {
			double übertrag = rot - mk.rot;
			mk.rot += (übertrag * Math.random()*faktor);
			rot -= (übertrag * Math.random()*faktor);
		}
		if (typ == 9) {
			double übertrag = green - mk.green;
			mk.green += (übertrag * Math.random()*faktor);
			green -= (übertrag * Math.random()*faktor);
		}
		if (typ == 10) {
			double übertrag = blue - mk.blue;
			mk.green += (übertrag * Math.random()*faktor);
			blue -= (übertrag * Math.random()*faktor);
		}
	}
    
    
    // Gleichungen aus den Naturwissenschaften, Lumini und Matrixgame einbauen
    double G = 0.01;
    public void gravity(MasseKugel masse2, double time) {
    	time*=this.time;
    	double distance = getDistance(masse2);
    	if(distance==0)return;
//    	System.out.println(distance);
    	double Kraft = mass*masse2.mass/distance/distance*G;
    	double Xdist = masse2.x-x;
    	double Ydist = masse2.y-y;
    	double Zdist = masse2.z-z;
    	
    	
    	double normX=Xdist/distance;
    	double normY=Ydist/distance;
    	double normZ=Zdist/distance;
    	
    	// Kraft
    	//F=m*a
    	//a=F/m
    	double beschleunigung=Kraft/mass;
    	// v=a*t
    	// vn = a*t*normN
    	
    	vx=vx+beschleunigung*time*normX;
    	vy=vy+beschleunigung*time*normY;
    	vz=vz+beschleunigung*time*normZ;
    	
    	// Gegenkraft
    	double gegenKraft=-Kraft;
    	//F=m*a
    	//a=F/m
    	double GegenBeschleunigung=gegenKraft/masse2.mass;
    	// v=a*t
    	// vn = a*t*normN
    	
    	masse2.vx=masse2.vx+GegenBeschleunigung*time*normX;
    	masse2.vy=masse2.vy+GegenBeschleunigung*time*normY;
    	masse2.vz=masse2.vz+GegenBeschleunigung*time*normZ;
    	
    	// Positionen Upgraden
//    	updatePosition(time);
//    	masse2.updatePosition(time);
    	update(time);
    	masse2.update(time);
    }
    
    public void gravity2(MasseKugel masse2, double time) {
    	time*=this.time;
    	double distance = getDistance(masse2);
    	if(distance==0)return;
//    	System.out.println(distance);
    	double Kraft = mass*masse2.mass/distance/distance*G;
    	double Xdist = masse2.x-x;
    	double Ydist = masse2.y-y;
    	double Zdist = masse2.z-z;
    	
    	
    	double normX=Xdist/distance;
    	double normY=Ydist/distance;
    	double normZ=Zdist/distance;
    	
    	// Kraft
    	//F=m*a
    	//a=F/m
    	double beschleunigung=Kraft/mass;
    	// v=a*t
    	// vn = a*t*normN
    	// an = a*normN
    	
    	ax=ax+beschleunigung*normX;
    	ay=ay+beschleunigung*normY;
    	az=az+beschleunigung*normZ;
    	
    	// Gegenkraft
    	double gegenKraft=-Kraft;
    	//F=m*a
    	//a=F/m
    	double GegenBeschleunigung=gegenKraft/masse2.mass;
    	// v=a*t
    	// vn = a*t*normN
    	// an = a*normN
    	
    	masse2.ax=masse2.ax+GegenBeschleunigung*normX;
    	masse2.ay=masse2.ay+GegenBeschleunigung*normY;
    	masse2.az=masse2.az+GegenBeschleunigung*normZ;
    	
    	// Positionen Upgraden
//    	updatePosition(time);
//    	masse2.updatePosition(time);
    	update(time);
    	masse2.update(time);
    }


	public void update(double time) {
		updateV(time);
		updatePosition(time);
		updateColor();		
	}
	
	public void updateColor() {
		int r=0;
		int g=0;
		int b=0;
		
		r=(int) Math.round(rot);
		if(r<0)r=Math.absExact(r);
		if(r>255)r=255;
		g=(int) Math.round(green);
		if(g<0)g=Math.absExact(g);
		if(g>255)g=255;
		if(b<0)b=Math.absExact(b);
		if(b>255)b=255;
		
		
		color=new Color(r,g,b);
	}
	
	
    
    public void updatePosition(double time) {
        this.x += (this.vx*time);
        this.y += (this.vy*time);
        this.z += (this.vz*time);
    }
	
	public void updateV(double time) {
        this.vx += (this.ax*time);
        this.vy += (this.ay*time);
        this.vz += (this.az*time);
    }

	
	
	public double getDistance(MasseKugel masseKugel2) {
        double distanceSQR = (masseKugel2.x-x)*(masseKugel2.x-x) + (masseKugel2.y-y)*(masseKugel2.y-y) + (masseKugel2.z-z)*(masseKugel2.z-z);
        double dist= Math.pow(distanceSQR, 0.5);
        return dist;
    }
	
	
    public double getEKin() {
        double speedSq = this.vx * this.vx + this.vy * this.vy + this.vz * this.vz;
        return 0.5 * this.mass * speedSq;
    }
    
//    public void updateColorBasedOnTemperature() {
//	    // Temperaturschwellen in Celsius
//	    final double TOO_COLD_FOR_LAND_LIFE_CELSIUS = -50.0;
//	    final double FREEZING_POINT_CELSIUS = 0.0;
//	    final double STEAM_SAUNA_CELSIUS = 50.0;
//	    final double ONLY_OCEAN_LIFE_CELSIUS = 80.0;
//	    final double EVAPORATION_POINT_CELSIUS = 100.0;
//	    
//	   
//
//	    // Logik zur Farbanpassung basierend auf der Temperatur
//	    if (oberflächentemperatur < TOO_COLD_FOR_LAND_LIFE_CELSIUS) {
//	        // Alles gefroren und sehr kalt
//	        this.color = new Color(150, 150, 255); // Hellblau, "eisig"
//	    } else if (oberflächentemperatur < FREEZING_POINT_CELSIUS) {
//	        // Gefrorene Pole, vielleicht flüssiges Wasser am Äquator
//	        this.color = new Color(200, 200, 255); // Blassblau
//	    } else if (oberflächentemperatur < STEAM_SAUNA_CELSIUS) {
//	        // "Normale" bewohnbare Zone wie die Erde
//	        this.color = Color.GREEN;
//	    } else if (oberflächentemperatur < ONLY_OCEAN_LIFE_CELSIUS) {
//	        // "Dampfsauna": Land ist zu heiß, Leben nur noch in Wasser-Nähe und Höhlen
//	        this.color = new Color(100, 200, 100); // Dunkelgrün
//	    } else if (oberflächentemperatur < EVAPORATION_POINT_CELSIUS) {
//	        // "Heiße Ozeane": Leben nur noch im Meer möglich
//	        this.color = new Color(0, 100, 100); // Türkis
//	    } else {
//	        // "Ozeane verdampft": Extrem heiß, Wüstenplanet
//	        this.color = Color.ORANGE;
//	    }
//	}
}