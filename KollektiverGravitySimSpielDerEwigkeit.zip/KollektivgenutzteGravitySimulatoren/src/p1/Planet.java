package p1;

import java.awt.Color;

public class Planet extends MasseKugel{
	
	double oberflächentemperatur;
	double erdbeschleunigung;
	boolean rotationsgebunden;
	boolean leben;
	boolean sonnenlicht;

	public Planet(double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color
			) {
		super(x, y, z, vx, vy, vz, mass, radius, color);
		// TODO Auto-generated constructor stub
	}
	
	public void updateColorBasedOnTemperature() {
	    // Temperaturschwellen in Celsius
	    final double TOO_COLD_FOR_LAND_LIFE_CELSIUS = -50.0;
	    final double FREEZING_POINT_CELSIUS = 0.0;
	    final double STEAM_SAUNA_CELSIUS = 50.0;
	    final double ONLY_OCEAN_LIFE_CELSIUS = 80.0;
	    final double EVAPORATION_POINT_CELSIUS = 100.0;
	    
	   

	    // Logik zur Farbanpassung basierend auf der Temperatur
	    if (oberflächentemperatur < TOO_COLD_FOR_LAND_LIFE_CELSIUS) {
	        // Alles gefroren und sehr kalt
	        this.color = new Color(150, 150, 255); // Hellblau, "eisig"
	    } else if (oberflächentemperatur < FREEZING_POINT_CELSIUS) {
	        // Gefrorene Pole, vielleicht flüssiges Wasser am Äquator
	        this.color = new Color(200, 200, 255); // Blassblau
	    } else if (oberflächentemperatur < STEAM_SAUNA_CELSIUS) {
	        // "Normale" bewohnbare Zone wie die Erde
	        this.color = Color.GREEN;
	    } else if (oberflächentemperatur < ONLY_OCEAN_LIFE_CELSIUS) {
	        // "Dampfsauna": Land ist zu heiß, Leben nur noch in Wasser-Nähe und Höhlen
	        this.color = new Color(100, 200, 100); // Dunkelgrün
	    } else if (oberflächentemperatur < EVAPORATION_POINT_CELSIUS) {
	        // "Heiße Ozeane": Leben nur noch im Meer möglich
	        this.color = new Color(0, 100, 100); // Türkis
	    } else {
	        // "Ozeane verdampft": Extrem heiß, Wüstenplanet
	        this.color = Color.ORANGE;
	    }
	}

}
