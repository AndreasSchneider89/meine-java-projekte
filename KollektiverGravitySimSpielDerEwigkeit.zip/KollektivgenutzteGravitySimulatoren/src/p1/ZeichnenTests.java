package p1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ZeichnenTests extends JPanel implements ActionListener{
	int FRAME_WIDTH = 1920;
	int FRAME_HEIGHT = 1080;

	// --- Zoom-Variablen ---
	private double zoomFactor = 1.0;

	double zoomCenterX = 0;
	double zoomCenterY = 0;
	private static final double ZOOM_STEP = 1.2;
	private static final int MIN_RADIUS_DRAW = 2;

	double feinheit = 70;
	double PAN_STEP = feinheit * zoomFactor; // Verschiebung pro Button-Klick
	
	
	// --- Pan-Methoden ---
		public void panLeft() {
			zoomCenterX += PAN_STEP;
			repaint();
		}

		public void panRight() {
			zoomCenterX -= PAN_STEP;
			repaint();
		}

		public void panUp() {
			zoomCenterY += PAN_STEP;
			repaint();
		}

		public void panDown() {
			zoomCenterY -= PAN_STEP;
			repaint();
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			g2.setColor(Color.BLACK);
			g2.fillRect(0, 0, getWidth(), getHeight());}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			repaint();
		}
		
		public static void Main(String[] args) {

			SwingUtilities.invokeLater(() -> {
				JFrame frame = new JFrame("N-Body Sonnensystem-Simulation (QDBV-Modul)");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				main2 simPanel = new main2();
				frame.setLayout(new BorderLayout());
				frame.add(simPanel, BorderLayout.CENTER);

				// 1. Alle Buttons erstellen
				JButton zoomIn = new JButton("Zoom In");
				JButton zoomOut = new JButton("Zoom Out");
				JButton speedUp = new JButton("Speed Up");
				JButton speedDown = new JButton("Speed Down");
				JButton panLeft = new JButton("← Links");
				JButton panRight = new JButton("Rechts →");
				JButton panUp = new JButton("↑ Hoch");
				JButton panDown = new JButton("↓ Runter");
				JButton resetButton = new JButton("Zurücksetzen (Init)");

				// Neue Buttons für Impulse
				JButton impulseTowardsStar = new JButton("Impuls: Zum Stern (Xylos I)"); // Umbenannt für Klarheit
				JButton impulseAwayFromStar = new JButton("Impuls: Vom Stern weg (Xylos I)"); // Umbenannt für Klarheit
				JButton impulsePrograde = new JButton("Impuls: Umlaufrichtung (Xylos I)");
				JButton impulseRetrograde = new JButton("Impuls: Gegen Umlaufrichtung (Xylos I)");

				
				

				// 2. ActionListener zuweisen
				zoomIn.addActionListener(e -> simPanel.zoomIn());
				zoomOut.addActionListener(e -> simPanel.zoomOut());
				speedUp.addActionListener(e -> simPanel.increaseSimulationSpeed());
				speedDown.addActionListener(e -> simPanel.decreaseSimulationSpeed());
				panLeft.addActionListener(e -> simPanel.panLeft());
				panRight.addActionListener(e -> simPanel.panRight());
				panUp.addActionListener(e -> simPanel.panUp());
				panDown.addActionListener(e -> simPanel.panDown());
				resetButton.addActionListener(e -> simPanel.resetSimulationToInitialState());

				// ActionListener für neue Impuls-Buttons (Namen korrigiert)
				impulseTowardsStar.addActionListener(e -> simPanel.applyImpulseTowardsStar()); // "Rotation" war
																								// missverständlich
				impulseAwayFromStar.addActionListener(e -> simPanel.applyImpulseAwayFromStar()); // "Gegen Rotation" war
																									// missverständlich
				impulsePrograde.addActionListener(e -> simPanel.applyImpulsePrograde());
				impulseRetrograde.addActionListener(e -> simPanel.applyImpulseRetrograde());

				
			

				// 3. Buttons und Textfeld zum Control-Panel hinzufügen
				JPanel control = new JPanel();
				control.add(zoomIn);
				control.add(zoomOut);
				control.add(speedUp);
				control.add(speedDown);
				control.add(panLeft);
				control.add(panRight);
				control.add(panUp);
				control.add(panDown);
				control.add(resetButton);

				

				// Impuls-Buttons
				control.add(impulseTowardsStar);
				control.add(impulseAwayFromStar);
				control.add(impulsePrograde);
				control.add(impulseRetrograde);

			

				frame.add(control, BorderLayout.NORTH);
				frame.setSize(1920, 1080); // Höherer Rahmen für Buttons
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			});
		
		}
}
