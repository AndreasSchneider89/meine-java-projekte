package p1;

import java.util.*;

public class LuminiGameGPT {
    static Random random = new Random();
    static int points = 0;
    static int level = 1;
    static Map<Character, String> textToMorse = new HashMap<>();
    static Map<String, Character> morseToText = new HashMap<>();
    static Map<Character, Integer> mistakes = new HashMap<>();

    public static void main(String[] args) {
        initMappings();
        Scanner sc = new Scanner(System.in);

        while (true) {
            showMenu();
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1": training(sc); break;
                case "2": test(sc); break;
                case "3": showStats(); break;
                case "q": System.out.println("Auf Wiedersehen!"); return;
                default: System.out.println("Ungültige Eingabe!");
            }
        }
    }

    static void showMenu() {
        System.out.println("\n=== Lumini 2.0 ===");
        System.out.println("Level: " + level + " | Punkte: " + points);
        System.out.println("1. Training (zufällige Zeichen)");
        System.out.println("2. Test (Fehlerfokus)");
        System.out.println("3. Statistik ansehen");
        System.out.println("q. Beenden");
        System.out.print("Deine Wahl: ");
    }

    static void training(Scanner sc) {
        char c = getRandomChar();
        System.out.println("Wandle dieses Zeichen in Morse um: " + c);
        String answer = sc.nextLine().trim();

        if (answer.equals(textToMorse.get(c))) {
            System.out.println("✅ Richtig!");
            addPoints(10);
        } else {
            System.out.println("❌ Falsch. Richtige Antwort: " + textToMorse.get(c));
            mistakes.put(c, mistakes.getOrDefault(c, 0) + 1);
        }
    }

    static void test(Scanner sc) {
        if (mistakes.isEmpty()) {
            System.out.println("Keine Fehler gespeichert – gut gemacht!");
            return;
        }

        // Nimm den schwierigsten Buchstaben (höchste Fehlerzahl)
        char hardest = mistakes.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .get().getKey();

        System.out.println("Schwerster Buchstabe: " + hardest);
        System.out.println("Wandle um: " + hardest);
        String answer = sc.nextLine().trim();

        if (answer.equals(textToMorse.get(hardest))) {
            System.out.println("✅ Richtig!");
            addPoints(20);
            mistakes.put(hardest, mistakes.get(hardest) - 1);
        } else {
            System.out.println("❌ Falsch. Richtige Antwort: " + textToMorse.get(hardest));
            mistakes.put(hardest, mistakes.get(hardest) + 1);
        }
    }

    static void addPoints(int p) {
        points += p;
        if (points > 300) level = 3;
        else if (points > 150) level = 2;
    }

    static void showStats() {
        System.out.println("=== Statistik ===");
        System.out.println("Level: " + level);
        System.out.println("Punkte: " + points);
        System.out.println("Fehlerhistorie: " + mistakes);
    }

    static char getRandomChar() {
        List<Character> keys = new ArrayList<>(textToMorse.keySet());
        return keys.get(random.nextInt(keys.size()));
    }

    static void initMappings() {
        textToMorse.put('A', ".-");
        textToMorse.put('B', "-...");
        textToMorse.put('C', "-.-.");
        textToMorse.put('E', ".");
        textToMorse.put('T', "-");

        for (var e : textToMorse.entrySet()) {
            morseToText.put(e.getValue(), e.getKey());
        }
    }
}
