package lumini;

import lumini.ElementAtom;
import lumini.exporter.LuminiPeriodentabelleExporter;
import lumini.adapters.LuminiSymbolAdapter;
import lumini.BioLuminiEvolutionEngine;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 🌌 MatrixgameIntegrator – Epoche 2B: Bewusstseinsverknüpfung
 * 
 * Verbindet:
 * - Physikalische Daten (Elemente, Resonanz)
 * - Bewusstseinsmodell (5 Ebenen, Binärbäume)
 * - Spielmechanik (SQL: Spieler, Missionen)
 * - Planetensimulation (HabitatEngine)
 * 
 * Andreas Schneider – Matrixgame Fragment des Übergangs 6
 */
public class MatrixgameIntegrator {

    // === Datenquellen ===
    private final LuminiSymbolAdapter adapter = new LuminiSymbolAdapter();
    private final Map<Integer, ElementAtom> elemente = new HashMap<>();
    private final Map<String, BewusstseinsKnoten> bewusstseinsNetz = new HashMap<>();
    private Connection sqlConnection;

    // === Bewusstseinsmodell ===
    public static class BewusstseinsKnoten {
        public String id;
        public int ebene; // 1–5
        public String typ; // "Prokaryot", "Planet", "KI", "Gruppe"
        public double influence, coherence, anxiety;
        public List<String> verbundeneKnoten = new ArrayList<>();
        public String planetTyp; // "Erde", "AlteWelt", "Neutronenstern", etc.
        public double raumX, raumY, raumZ;
        public long zeitpunkt;

        public BewusstseinsKnoten(String id, int ebene, String typ) {
            this.id = id; this.ebene = ebene; this.typ = typ;
        }
    }

    // === Initialisierung ===
    public void init() throws IOException, SQLException {
        // 1. Lade Elemente aus JSON (kann auch aus SQL gelesen werden)
        loadElementsFromJSON("output/lumini_periodensystem.json");

        // 2. Baue Bewusstseinsnetz auf (vereinfacht: 1 Element = 1 Knoten)
        buildBewusstseinsNetz();

        // 3. Verbinde mit SQL-Datenbank (Level 2)
        initSQLConnection();
    }

    private void loadElementsFromJSON(String path) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
            // Sehr einfacher JSON-Parser (für Demo – in Produktion: Jackson/Gson)
            String[] entries = content.toString().replace("[", "").replace("]", "").split("\\},\\{");
            for (String entry : entries) {
                entry = entry.replace("{", "").replace("}", "");
                String[] pairs = entry.split(",");
                ElementAtom e = new ElementAtom(1); // Dummy
                for (String pair : pairs) {
                    if (pair.contains("ordnungszahl")) {
                        int z = Integer.parseInt(pair.split(":")[1].trim());
                        e = new ElementAtom(z);
                        elemente.put(z, e);
                    } else if (pair.contains("name")) {
                        e.name = extractValue(pair);
                    } else if (pair.contains("symbol")) {
                        e.symbol = extractValue(pair);
                    } else if (pair.contains("atomgewicht")) {
                        e.atomgewicht = Double.parseDouble(extractValue(pair));
                    } else if (pair.contains("dichte")) {
                        e.dichteDouble = Double.parseDouble(extractValue(pair));
                    } else if (pair.contains("elektronegativitaet")) {
                        e.elektronegativitätDouble = Double.parseDouble(extractValue(pair));
                    }
                }
            }
        }
        System.out.println("✅ " + elemente.size() + " Elemente geladen.");
    }

    private String extractValue(String pair) {
        return pair.split(":")[1].trim().replace("\"", "");
    }

    private void buildBewusstseinsNetz() {
        // Beispiel: Verknüpfe einige Schlüsselelemente mit Bewusstseinsebenen
        Map<String, Integer> elementEbene = Map.of(
            "H", 1, "O", 1, "C", 1, "N", 1,
            "Fe", 2, "Si", 2,
            "Erde", 5
        );

        for (ElementAtom e : elemente.values()) {
            if (elementEbene.containsKey(e.symbol)) {
                BewusstseinsKnoten knoten = new BewusstseinsKnoten(
                    e.symbol,
                    elementEbene.get(e.symbol),
                    "Element"
                );
                knoten.planetTyp = "Erde";
                knoten.influence = e.elektronegativitätDouble / 4.0;
                knoten.coherence = Math.min(1.0, e.dichteDouble / 22.6);
                knoten.anxiety = 0.1;
                bewusstseinsNetz.put(e.symbol, knoten);
            }
        }

        // Planeten-Knoten
        BewusstseinsKnoten erde = new BewusstseinsKnoten("Erde", 5, "Planet");
        erde.planetTyp = "Neue habitable Welt";
        erde.influence = 0.95;
        erde.coherence = 0.8;
        erde.anxiety = 0.3;
        bewusstseinsNetz.put("Erde", erde);

        System.out.println("🧠 Bewusstseinsnetz mit " + bewusstseinsNetz.size() + " Knoten aufgebaut.");
    }

    private void initSQLConnection() throws SQLException {
        // Beispiel: SQLite oder MySQL – passe URL an
        String url = "jdbc:sqlite:matrixgame.db";
        this.sqlConnection = DriverManager.getConnection(url);
        // Tabellen ggf. erstellen (siehe SQL-Didaktik)
        createTablesIfNotExists();
        System.out.println("💾 SQL-Verbindung hergestellt.");
    }

    private void createTablesIfNotExists() throws SQLException {
        try (Statement stmt = sqlConnection.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Spieler (
                    SpielerID INTEGER PRIMARY KEY AUTOINCREMENT,
                    Benutzername TEXT NOT NULL UNIQUE,
                    Level INTEGER DEFAULT 1,
                    Credits INTEGER DEFAULT 0
                )
            """);
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS LuminiEvents (
                    EventID INTEGER PRIMARY KEY AUTOINCREMENT,
                    Zeitstempel REAL,
                    OrtX REAL, OrtY REAL, OrtZ REAL,
                    KnotenID TEXT,
                    Aktion TEXT,
                    Erfolg REAL
                )
            """);
        }
    }

    // === Entscheidungslogik (Binärbaum-basiert) ===
    public boolean stelleBinäreFrage(String frage, String knotenA, String knotenB) {
        BewusstseinsKnoten a = bewusstseinsNetz.get(knotenA);
        BewusstseinsKnoten b = bewusstseinsNetz.get(knotenB);
        if (a == null || b == null) return false;

        // Erfolgswahrscheinlichkeit basierend auf Kohärenz & Angst
        double p = (a.coherence + b.coherence) / 2.0 * (1.0 - Math.max(a.anxiety, b.anxiety));
        boolean entscheidung = ThreadLocalRandom.current().nextDouble() < p;

        // Logge Event
        logLuminiEvent(knotenA + "->" + knotenB, frage, p);

        System.out.printf("❓ %s\n   → Entscheidung: %s (Erfolgswahrscheinlichkeit: %.1f%%)\n",
                frage, entscheidung ? "JA" : "NEIN", p * 100);
        return entscheidung;
    }

    private void logLuminiEvent(String knotenID, String aktion, double erfolg) {
        try {
            PreparedStatement ps = sqlConnection.prepareStatement(
                "INSERT INTO LuminiEvents (Zeitstempel, OrtX, OrtY, OrtZ, KnotenID, Aktion, Erfolg) VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            ps.setDouble(1, System.currentTimeMillis() / 1000.0);
            ps.setDouble(2, Math.random() * 1e12);
            ps.setDouble(3, Math.random() * 1e12);
            ps.setDouble(4, Math.random() * 1e12);
            ps.setString(5, knotenID);
            ps.setString(6, aktion);
            ps.setDouble(7, erfolg);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // === Simulationsschleife ===
    public void startEpoche2B() {
        System.out.println("\n🚀 EPOCHE 2B: BEWUSSTSEINSVERKNÜPFUNG AKTIVIERT\n");

        // Beispiel-Entscheidungen
        stelleBinäreFrage(
            "Soll Wissen über Fusionsenergie an 'Weniger habitable Welten' gesendet werden?",
            "Erde", "Fe"
        );

        stelleBinäreFrage(
            "Soll die Quantenverschränkung mit 'Alte habitable Welten' verstärkt werden?",
            "Erde", "C"
        );

        // Starte Habitat-Simulation (optional)
        // new PlanetaryHabitatEngine().runEpochs(...);
    }

    // === Main ===
    public static void main(String[] args) {
        MatrixgameIntegrator integrator = new MatrixgameIntegrator();
        try {
            integrator.init();
            integrator.startEpoche2B();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}