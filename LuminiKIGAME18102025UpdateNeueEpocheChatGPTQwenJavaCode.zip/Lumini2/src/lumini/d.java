package lumini;

import lumini.ElementAtom;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * LuminiSymbolAdapter
 *
 * - Encodes ElementAtom properties into Lumini-style binary strings (using '-' for 1 and '.' for 0).
 * - Provides helper methods to build SQL insert statements, a simple SVG tile for visualization,
 *   and JSON-like representations for downstream simulation/serialization.
 *
 * Design notes:
 * - Binary encoding uses fixed width (configurable) for ordnungszahl and valenzelektronen.
 * - Color generation is heuristic (maps electronegativity -> hue), useful for quick visual debugging.
 * - SQL generation follows simple table pattern inspired by provided SQL didaktik doc. :contentReference[oaicite:4]{index=4}
 */
public class d {

    // configurable widths for encodings
    private final int ordnungszahlBits;
    private final int valenzBits;

    // Basic color mapping bounds (heuristic)
    private final double enegMin = 0.0;
    private final double enegMax = 4.0;

    public d() {
        this(8, 4); // default: 8 bits for atomic number (up to 255), 4 bits valence (up to 15)
    }

    public d(int ordnungszahlBits, int valenzBits) {
        this.ordnungszahlBits = ordnungszahlBits;
        this.valenzBits = valenzBits;
    }

    /**
     * Encodes an integer into Lumini binary string using '-' for 1 and '.' for 0
     * with fixed width (leading zeros included).
     */
    public String encodeToLuminiBits(int value, int bits) {
        StringBuilder sb = new StringBuilder(bits);
        for (int i = bits - 1; i >= 0; i--) {
            int bit = (value >> i) & 1;
            sb.append(bit == 1 ? '-' : '.');
        }
        return sb.toString();
    }

    /**
     * Convenience: encode the protonenzahl (ordinierungszahl).
     */
    public String encodeProtonenzahl(ElementAtom e) {
        int z = e.ordnungszahl;
        return encodeToLuminiBits(z, ordnungszahlBits);
    }

    /**
     * Convenience: encode outer-shell electron count.
     * Fallback behavior: if valenzelektronen string exists and is already Lumini-like,
     * pass-through; else try to parse e.valenzelektronen as int.
     */
    public String encodeValenzelektronen(ElementAtom e) {
        // if already seems to be lumini-coded (contains '-' or '.')
        if (e.valenzelektronen != null && (e.valenzelektronen.contains("-") || e.valenzelektronen.contains("."))) {
            return e.valenzelektronen;
        }
        try {
            int v = Integer.parseInt(e.valenzelektronen == null || e.valenzelektronen.isEmpty() ? "0" : e.valenzelektronen);
            return encodeToLuminiBits(v, valenzBits);
        } catch (NumberFormatException ex) {
            // unable to parse -> fallback empty
            return encodeToLuminiBits(0, valenzBits);
        }
    }

    /**
     * Build a compact Lumini symbol consisting of:
     * - Symbol (e.g. "H")
     * - Lumini proton bitstring
     * - Lumini valence bitstring
     *
     * Example output: "H|--..-.|.-.-"
     */
    public String buildLuminiSymbol(ElementAtom e) {
        String zBits = encodeProtonenzahl(e);
        String vBits = encodeValenzelektronen(e);
        String sym = e.symbol != null ? e.symbol : ("E" + e.ordnungszahl);
        return String.format("%s|%s|%s", sym, zBits, vBits);
    }

    /**
     * Heuristic color generation based on electronegativity.
     * Maps EN to a hue value (0..360). Returns hex color string.
     * Useful for quick visualization tiles.
     */
    public String colorFromElectronegativity(ElementAtom e) {
        double eneg = e.elektronegativitätDouble;
        if (eneg <= 0) {
            return "#999999"; // default neutral gray
        }
        double ratio = (eneg - enegMin) / (enegMax - enegMin);
        ratio = Math.max(0.0, Math.min(1.0, ratio));
        // map to hue 240 (blue) -> 0 (red) for visual contrast
        int hue = (int) Math.round(240 - 240 * ratio);
        // convert hue to simple RGB via H->RGB approximation (very basic)
        return hslToHex(hue, 70, 45);
    }

    // --- small HSL to hex helper (approximate, no external libs) ---
    private String hslToHex(int hue, int satPercent, int lightPercent) {
        double s = satPercent / 100.0;
        double l = lightPercent / 100.0;
        double c = (1.0 - Math.abs(2.0 * l - 1.0)) * s;
        double hPrime = hue / 60.0;
        double x = c * (1 - Math.abs(hPrime % 2 - 1));
        double r1 = 0, g1 = 0, b1 = 0;
        if (0 <= hPrime && hPrime < 1) { r1 = c; g1 = x; b1 = 0; }
        else if (1 <= hPrime && hPrime < 2) { r1 = x; g1 = c; b1 = 0; }
        else if (2 <= hPrime && hPrime < 3) { r1 = 0; g1 = c; b1 = x; }
        else if (3 <= hPrime && hPrime < 4) { r1 = 0; g1 = x; b1 = c; }
        else if (4 <= hPrime && hPrime < 5) { r1 = x; g1 = 0; b1 = c; }
        else if (5 <= hPrime && hPrime < 6) { r1 = c; g1 = 0; b1 = x; }

        double m = l - c / 2.0;
        int r = (int) Math.round((r1 + m) * 255);
        int g = (int) Math.round((g1 + m) * 255);
        int b = (int) Math.round((b1 + m) * 255);
        return String.format("#%02X%02X%02X", clamp(r), clamp(g), clamp(b));
    }

    private int clamp(int v) {
        if (v < 0) return 0;
        if (v > 255) return 255;
        return v;
    }

    /**
     * Builds a simple SQL INSERT statement for a table 'Elemente' (adapt to your schema).
     * Uses a minimal set of columns; you can expand based on your Matrixgame SQL design. :contentReference[oaicite:5]{index=5}
     */
    public String buildSqlInsert(ElementAtom e) {
        DecimalFormat df = new DecimalFormat("#.######");
        String name = safeSql(e.name);
        String symbol = safeSql(e.symbol);
        String ordnungszahl = Integer.toString(e.ordnungszahl);
        String gewicht = Double.isNaN(e.atomgewicht) ? "NULL" : df.format(e.atomgewicht);
        String dichte = Double.isNaN(e.dichteDouble) ? "NULL" : df.format(e.dichteDouble);
        String eneg = Double.isNaN(e.elektronegativitätDouble) ? "NULL" : df.format(e.elektronegativitätDouble);
        String halbw = Double.isNaN(e.halbwärtszeit) ? "NULL" : df.format(e.halbwärtszeit);

        String luminiSymbol = safeSql(buildLuminiSymbol(e));
        String color = safeSql(colorFromElectronegativity(e));

        return String.format("INSERT INTO Elemente (Name, Symbol, Ordnungszahl, Atomgewicht, Dichte, Elektronegativitaet, Halbwertszeit, LuminiSymbol, Farbe) VALUES ('%s','%s',%s,%s,%s,%s,%s,'%s','%s');",
                name, symbol, ordnungszahl, gewicht, dichte, eneg, halbw, luminiSymbol, color);
    }

    private String safeSql(String s) {
        if (s == null) return "";
        return s.replace("'", "''");
    }

    /**
     * Generates a tiny SVG tile representing the element for UI/debugging:
     * - A colored rectangle (color from EN)
     * - Symbol and atomic number text
     *
     * This is a single-string SVG (small, embeddable).
     */
    public String generateElementTileSVG(ElementAtom e, int width, int height) {
        String color = colorFromElectronegativity(e);
        String sym = e.symbol != null ? e.symbol : ("E" + e.ordnungszahl);
        String name = e.name != null ? e.name : "";
        String z = Integer.toString(e.ordnungszahl);
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("<svg xmlns='http://www.w3.org/2000/svg' width='%d' height='%d'>", width, height));
        sb.append(String.format("<rect width='100%%' height='100%%' fill='%s' rx='8' ry='8'/>", color));
        sb.append(String.format("<text x='50%%' y='42%%' font-family='Verdana' font-size='%d' text-anchor='middle' fill='#ffffff'>%s</text>", Math.max(12, width/4), sym));
        sb.append(String.format("<text x='50%%' y='78%%' font-family='Verdana' font-size='%d' text-anchor='middle' fill='#ffffff'>%s</text>", Math.max(8, width/8), z));
        sb.append(String.format("<title>%s (%s)</title>", name, sym));
        sb.append("</svg>");
        return sb.toString();
    }

    /**
     * Quick JSON-like map representation that can be serialized by your favorite JSON library.
     * This method returns data in a Map for easy conversion.
     */
    public Map<String, Object> toMap(ElementAtom e) {
        Map<String, Object> m = new HashMap<>();
        m.put("name", e.name);
        m.put("symbol", e.symbol);
        m.put("ordnungszahl", e.ordnungszahl);
        m.put("atomgewicht", e.atomgewicht);
        m.put("dichte", e.dichteDouble);
        m.put("elektronegativitaet", e.elektronegativitätDouble);
        m.put("luminiSymbol", buildLuminiSymbol(e));
        m.put("color", colorFromElectronegativity(e));
        return m;
    }

    // -------------------------
    // Example utilities below
    // -------------------------

    /**
     * Small helper to produce a human-friendly short summary string for logs/console.
     */
    public String summary(ElementAtom e) {
        return String.format("%s (%s) Z=%d mw=%.4f g/cm3=%.4f EN=%.2f Lumini=%s",
                e.name, e.symbol, e.ordnungszahl, e.atomgewicht, e.dichteDouble, e.elektronegativitätDouble, buildLuminiSymbol(e));
    }

}
