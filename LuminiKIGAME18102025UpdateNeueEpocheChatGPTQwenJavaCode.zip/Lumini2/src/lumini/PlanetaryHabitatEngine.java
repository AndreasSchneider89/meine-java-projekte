package lumini;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.text.DecimalFormat;

/**
 * PlanetaryHabitatEngine
 *
 * Simuliert Umwelteinflüsse auf chemische/biologische Lumini-Entitäten.
 * - HabitatParams: Parameter eines Planeten/Ort
 * - simulateStep: berechnet Reaktionswahrscheinlichkeiten, Selektionsdrücke
 * - runEpochs: ermöglicht Langzeitsimulation über mehrere Zeitschritte
 * - CSV-Export & einfache Konsolenvisualisierung
 *
 * Integrationen:
 * - Nutze ElementAtom (dein Modell) und BioLuminiEvolutionEngine.BioLumini falls vorhanden.
 * - LuminiSymbolAdapter kann benutzt werden, um Lumini-Codes in Visualisierung einzubeziehen.
 *
 * Andreas – MatrixGame: Epoche 4 (Habitat Engine)
 */
public class PlanetaryHabitatEngine {

    private final Random rnd = new Random();

    /**
     * Parameter-Container für einen Planeten/Ort
     */
    public static class HabitatParams {
        public final String name;
        public final double temperatureK;       // absolute Temperatur in Kelvin
        public final double pressureBar;        // Druck in bar
        public final double gravity;            // m/s^2
        public final double radiationFlux;      // relative Strahlungsstärke (Sun units)
        public final Map<String, Double> atmosphere; // Anteile (N2, O2, CO2, H2, He, Ar, CH4, etc.)
        public final boolean liquidWater;       // presence of surface liquid water
        public final double pHestimate;         // rough pH estimate for aqueous environments
        public final double salinity;           // relative salinity 0..1

        public HabitatParams(String name,
                             double temperatureK,
                             double pressureBar,
                             double gravity,
                             double radiationFlux,
                             Map<String, Double> atmosphere,
                             boolean liquidWater,
                             double pHestimate,
                             double salinity) {
            this.name = name;
            this.temperatureK = temperatureK;
            this.pressureBar = pressureBar;
            this.gravity = gravity;
            this.radiationFlux = radiationFlux;
            this.atmosphere = Collections.unmodifiableMap(new HashMap<>(atmosphere));
            this.liquidWater = liquidWater;
            this.pHestimate = pHestimate;
            this.salinity = salinity;
        }
    }

    /**
     * Snapshot für Statistiken pro Zeitschritt
     */
    public static class WorldSnapshot {
        public final int step;
        public final HabitatParams params;
        public final double avgEnergy;
        public final double avgStability;
        public final String topOrganismSummary;

        public WorldSnapshot(int step, HabitatParams params, double avgEnergy, double avgStability, String topOrganismSummary) {
            this.step = step;
            this.params = params;
            this.avgEnergy = avgEnergy;
            this.avgStability = avgStability;
            this.topOrganismSummary = topOrganismSummary;
        }

        public String toCsv() {
            return String.format(Locale.US, "%d,%s,%.6f,%.6f,%b,%.2f,%.2f,%s",
                    step,
                    params.name,
                    avgEnergy,
                    avgStability,
                    params.liquidWater,
                    params.temperatureK,
                    params.pressureBar,
                    topOrganismSummary.replace(",", ";"));
        }
    }

    /* ---------- Physikalisch-chemische Hilfsfunktionen ---------- */

    /**
     * Einfache Arrhenius-artige Skalierung der Reaktionsrate durch Temperatur.
     * k ~ exp(-Ea/(R*T)). Wir approximieren mit einem effektiven "EaFactor".
     * scaleTemperature: 0.0..10.0 typische Werte ~ 0.1..5
     */
    public double temperatureFactor(double temperatureK, double activationEnergyFactor) {
        // R ~ 8.314 J/(mol*K); We scale to convenient dimensionless factor.
        double R = 8.314;
        double exponent = -activationEnergyFactor / (R * Math.max(1.0, temperatureK)); // avoid zero
        // clamp exponent to avoid underflow
        exponent = Math.max(exponent, -50);
        return Math.exp(exponent);
    }

    /**
     * Druck hat Einfluss auf Gaslöslichkeit / Reaktionskontakte. Einfaches Modell:
     * höherer Druck -> höhere Reaktionswahrscheinlichkeit (linear bis Faktor 3)
     */
    public double pressureFactor(double pressureBar) {
        return Math.min(3.0, 0.5 + 0.5 * pressureBar);
    }

    /**
     * Strahlung erhöht Kreativität (Mutation, ionische Reaktionen) aber schädigt Stabilität.
     * radiationFlux: relative Einheit (1.0 = Earth solar)
     */
    public double radiationMutationFactor(double radiationFlux) {
        return 1.0 + 0.5 * Math.log1p(radiationFlux); // mild increase, saturierend
    }

    /**
     * Kombinierte Umwelteinfluss-Funktion (0..1)
     */
    public double environmentSuitability(HabitatParams p, double desiredTempK, double desiredPressure) {
        double tScore = Math.exp(-Math.abs(p.temperatureK - desiredTempK) / Math.max(10.0, desiredTempK*0.1));
        double pScore = Math.exp(-Math.abs(p.pressureBar - desiredPressure) / Math.max(0.1, desiredPressure*0.2));
        double waterScore = p.liquidWater ? 1.0 : 0.2;
        double radScore = Math.max(0.1, 1.0 - 0.2 * Math.log1p(p.radiationFlux));
        return tScore * pScore * waterScore * radScore;
    }

    /* ---------- Simulation core ---------- */

    /**
     * Simuliert einen Zeitschritt (one-step) über eine Population von BioLumini.
     * - verändert Energie & Stabilität in Abhängigkeit von HabitatParams
     * - erzeugt Mutationsvorschläge (durch Radiation & Temp)
     * - returns a summary snapshot
     *
     * Voraussetzung: Die Elemente in BioLumini benutzen die Felder elektronegativitätDouble, dichteDouble, symbol
     */
    public WorldSnapshot simulateStep(int step, HabitatParams params, List<BioLuminiEvolutionEngine.BioLumini> population) {
        double totalEnergy = 0.0;
        double totalStability = 0.0;

        double tempFactor = temperatureFactor(params.temperatureK, 5000); // example activation factor
        double presFactor = pressureFactor(params.pressureBar);
        double radMutFactor = radiationMutationFactor(params.radiationFlux);

        // Umweltdruck -> höhere Selektion gegen instabile Kombinationen bei extremen Bedingungen
        double harshness = 1.0;
        if (params.temperatureK > 450 || params.temperatureK < 150) harshness += 0.5;
        if (!params.liquidWater) harshness += 0.5;
        if (params.radiationFlux > 10) harshness += 0.5;

        for (BioLuminiEvolutionEngine.BioLumini b : population) {
            // Energie neu berechnen: ursprüngliche EN Werte skaliert durch Umweltfaktoren
            double baseE = (b.aEN() + b.bEN()) / 10.0; // normalized roughly 0..1
            double envBoost = tempFactor * presFactor * (params.liquidWater ? 1.0 : 0.7);
            double newEnergy = Math.tanh(baseE * envBoost);
            // Stabilität sinkt bei hoher Strahlung & hohen Temp-Unterschieden
            double enDifference = Math.abs(b.aEN() - b.bEN());
            double newStability = Math.max(0.0, 1.0 - (enDifference / 5.0) - 0.1 * Math.log1p(params.radiationFlux));
            // Harshness effect
            newStability = Math.max(0.0, newStability - 0.1*(harshness-1.0));

            // Mutation chance increases with radiation & temperature
            double mutationProb = 0.05 * radMutFactor + 0.02 * (params.temperatureK / 300.0);
            if (rnd.nextDouble() < mutationProb) {
                // simple mutation: swap one basis or choose nearby element by EN
                if (rnd.nextBoolean()) {
                    b.basisA = randomElementNearby(b.basisA);
                } else {
                    b.basisB = randomElementNearby(b.basisB);
                }
            }

            // Update internal state (assumes method updateState exists)
            b.updateState();
            // overwrite with computed values (to bias simulation)
            b.energie = newEnergy;
            b.stabilitaet = newStability;
            b.evolutionScore = (b.energie * 0.7 + b.stabilitaet * 0.3);

            totalEnergy += b.energie;
            totalStability += b.stabilitaet;
        }

        double avgEnergy = totalEnergy / population.size();
        double avgStability = totalStability / population.size();

        // Determine top organism summary (best score)
        population.sort(Comparator.comparingDouble(x -> -x.evolutionScore));
        String topSummary = population.get(0).toString();

        return new WorldSnapshot(step, params, avgEnergy, avgStability, topSummary);
    }

    /**
     * Hilfsfunktion: wähle ein Element, das 'nahe' an dem gegebenen Element ist (Elektronegativität +- delta)
     * nutzt LuminiPeriodensystem falls verfügbar; fallback: random ElementAtom aus Periode 1..40
     */
    private ElementAtom randomElementNearby(ElementAtom e) {
        double targetEN = e.elektronegativitätDouble;
        double delta = 0.5 + rnd.nextDouble() * 1.5; // search range
        // if you have LuminiPeriodensystem class with map 'symbole', use it:
        try {
            LuminiPeriodensystem ps = new LuminiPeriodensystem();
            List<ElementAtom> pool = new ArrayList<>();
            for (ElementAtom candidate : ps.symbole.values()) {
                if (Math.abs(candidate.elektronegativitätDouble - targetEN) <= delta) {
                    pool.add(candidate);
                }
            }
            if (!pool.isEmpty()) return pool.get(rnd.nextInt(pool.size()));
        } catch (Throwable ex) {
            // fallback
        }
        // fallback: random small-Z element
        int z = 1 + rnd.nextInt(40);
        return new ElementAtom(z);
    }

    /* ---------- Laufsteuerung / Utilities ---------- */

    /**
     * Führe mehrere Zeitschritte aus, sammle Snapshots und optional CSV exportieren.
     */
    public List<WorldSnapshot> runEpochs(HabitatParams params,
                                        List<BioLuminiEvolutionEngine.BioLumini> population,
                                        int steps,
                                        boolean exportCsv,
                                        String csvPath) throws IOException {

        List<WorldSnapshot> log = new ArrayList<>();
        for (int s = 1; s <= steps; s++) {
            WorldSnapshot snap = simulateStep(s, params, population);
            log.add(snap);
            // optional: print to console
            printSnapshot(snap);

            // re-selektion: keep top N and repopulate by cloning top performers
            int survivors = Math.max(2, population.size() / 4);
            population.sort(Comparator.comparingDouble(x -> -x.evolutionScore));
            List<BioLuminiEvolutionEngine.BioLumini> newPop = new ArrayList<>();
            // keep top survivors and clone to refill
            for (int i = 0; i < survivors; i++) {
                newPop.add(population.get(i));
            }
            while (newPop.size() < population.size()) {
                BioLuminiEvolutionEngine.BioLumini parent = population.get(rnd.nextInt(survivors));
                // shallow clone: new combination based on parent's bases with small mutation chance
                BioLuminiEvolutionEngine.BioLumini child = new BioLuminiEvolutionEngine.BioLumini(parent.basisA, parent.basisB);
                // apply possible mutation
                if (rnd.nextDouble() < 0.08) child.basisA = randomElementNearby(child.basisA);
                if (rnd.nextDouble() < 0.08) child.basisB = randomElementNearby(child.basisB);
                child.updateState();
                newPop.add(child);
            }
            population.clear();
            population.addAll(newPop);
        }

        if (exportCsv) exportSnapshotsCsv(log, csvPath);
        return log;
    }

    public void printSnapshot(WorldSnapshot s) {
        DecimalFormat df = new DecimalFormat("#0.000");
        System.out.printf("Step %3d | World: %-12s | avgE=%s avgS=%s | top=%s\n",
                s.step,
                s.params.name,
                df.format(s.avgEnergy),
                df.format(s.avgStability),
                s.topOrganismSummary.split(" ")[0]);
    }

    public void exportSnapshotsCsv(List<WorldSnapshot> snapshots, String path) throws IOException {
        try (FileWriter fw = new FileWriter(path)) {
            fw.write("step,world,avgEnergy,avgStability,liquidWater,tempK,pressureBar,topSummary\n");
            for (WorldSnapshot s : snapshots) fw.write(s.toCsv() + "\n");
        }
    }

    /* ---------- Convenience: Beispiel main zur Demonstration ---------- */

    public static void main(String[] args) throws IOException {
        PlanetaryHabitatEngine engine = new PlanetaryHabitatEngine();

        // Beispiel-Atmosphäre (Erde-ähnlich)
        Map<String, Double> earthAtmo = new HashMap<>();
        earthAtmo.put("N2", 0.78);
        earthAtmo.put("O2", 0.21);
        earthAtmo.put("Ar", 0.009);
        earthAtmo.put("CO2", 0.0004);

        HabitatParams earthLike = new HabitatParams("Erde-Analog",
                288.0,   // 15°C
                1.0,     // 1 bar
                9.81,    // gravity
                1.0,     // solar flux
                earthAtmo,
                true,    // liquid water
                7.0,     // neutral pH
                0.03     // low salinity
        );

        // init population from your BioLuminiEvolutionEngine
        BioLuminiEvolutionEngine evo = new BioLuminiEvolutionEngine();
        evo.initPopulation(); // erzeugt POPULATION_SIZE BioLumini in deinem Engine
        List<BioLuminiEvolutionEngine.BioLumini> pop = new ArrayList<>(evo.population);

        // run simulation 20 steps
        List<WorldSnapshot> log = engine.runEpochs(earthLike, pop, 20, true, "world_earthlike.csv");

        System.out.println("Simulation abgeschlossen. CSV: world_earthlike.csv");
    }

}
