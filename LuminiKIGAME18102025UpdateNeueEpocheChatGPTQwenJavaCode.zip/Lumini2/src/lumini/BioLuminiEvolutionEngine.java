package lumini;

import java.util.*;

/**
 * 🧬 BioLuminiEvolutionEngine
 * Simuliert evolutionäre Prozesse auf Basis der Lumini-Physik.
 * Kombiniert chemische, energetische und informationelle Ebenen.
 *
 * Andreas Schneider – MatrixGame Epoche 3
 */
public class BioLuminiEvolutionEngine {

    private static final int POPULATION_SIZE = 50;
    private static final double MUTATION_RATE = 0.1;
    private static final double ENERGY_THRESHOLD = 0.5;

    private final LuminiPeriodensystem ps = new LuminiPeriodensystem();
    private final Random rnd = new Random();

    List<BioLumini> population = new ArrayList<>();

    // 🌱 Innere Klasse: Lebenseinheit
    static class BioLumini {
        ElementAtom basisA;
        ElementAtom basisB;
        double energie;           // energetischer Zustand (0–1)
        double stabilitaet;       // inverse Entropie (0–1)
        String code;              // Lumini-Code (|-+)
        double evolutionScore;    // Fitnesswert

        public BioLumini(ElementAtom a, ElementAtom b) {
            this.basisA = a;
            this.basisB = b;
            updateState();
        }

        // Berechnet Energie und Stabilität
        void updateState() {
            double eA = aEN();
            double eB = bEN();
            energie = Math.tanh((eA + eB) / 8.0);
            stabilitaet = 1.0 - Math.abs(eA - eB) / 4.0;
            evolutionScore = (energie * 0.7 + stabilitaet * 0.3);
            code = LuminiSymbolAdapter.combine(
                    LuminiSymbolAdapter.toLuminiCode(eA, 4.0),
                    LuminiSymbolAdapter.toLuminiCode(eB, 4.0)
            );
        }

        double aEN() { return basisA.elektronegativitätDouble; }
        double bEN() { return basisB.elektronegativitätDouble; }

        @Override
        public String toString() {
            return "%s-%s  E=%.2f  S=%.2f  Score=%.2f  Code=%s"
                    .formatted(basisA.symbol, basisB.symbol, energie, stabilitaet, evolutionScore, code);
        }
    }

    // 🌍 Initialisierung mit zufälligen Elementpaaren
    public void initPopulation() {
        List<ElementAtom> elements = new ArrayList<>(ps.symbole.values());
        for (int i = 0; i < POPULATION_SIZE; i++) {
            ElementAtom a = elements.get(rnd.nextInt(elements.size()));
            ElementAtom b = elements.get(rnd.nextInt(elements.size()));
            population.add(new BioLumini(a, b));
        }
    }

    // 🔄 Eine Evolutionsgeneration
    public void evolve() {
        for (BioLumini b : population) {
            mutate(b);
            b.updateState();
        }
        population.sort(Comparator.comparingDouble(x -> -x.evolutionScore)); // absteigend
    }

    // 🧬 Mutation: kleine Änderung durch Elementtausch
    private void mutate(BioLumini bio) {
        if (rnd.nextDouble() < MUTATION_RATE) {
            List<ElementAtom> elements = new ArrayList<>(ps.symbole.values());
            if (rnd.nextBoolean())
                bio.basisA = elements.get(rnd.nextInt(elements.size()));
            else
                bio.basisB = elements.get(rnd.nextInt(elements.size()));
        }
    }

    // 📈 Anzeige der Top-Ergebnisse
    public void printTop(int n) {
        System.out.println("🔥 Top Lumini-Organismen:");
        for (int i = 0; i < Math.min(n, population.size()); i++) {
            System.out.println(population.get(i));
        }
    }

    // 🎮 Simulation starten
    public static void main(String[] args) {
        BioLuminiEvolutionEngine sim = new BioLuminiEvolutionEngine();
        sim.initPopulation();

        for (int gen = 1; gen <= 10; gen++) {
            System.out.println("\n=== Generation " + gen + " ===");
            sim.evolve();
            sim.printTop(5);
        }
    }
}
