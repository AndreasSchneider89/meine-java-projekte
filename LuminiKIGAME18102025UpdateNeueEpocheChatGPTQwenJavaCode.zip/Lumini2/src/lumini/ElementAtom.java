package lumini;



public class ElementAtom {
	String Artikel = "--"; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
	String protonenzahl; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
	String valenzelektronen; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
	String dichte; // Vielfaches der Dichte von H2O in Lumini
	
	int ordnungszahl;
	String name;
	String symbol;
	double atomgewicht;
	double dichteDouble;
	String serie;
	double elektronegativitätDouble;
	double potentielleChemischeEnergie;
	double halbwärtszeit;
	double elektrischeLeitfähigkeit;
	int[] orbitalBefüllungen;
	double häufigkeitUniversum;
	double häufigkeitSonnensystem;
	double häufigkeitErde;
	double häufigketErdoberfläche;
	
	public ElementAtom(String artikel, String protonenzahl, String valenzelektronen) {
		this.Artikel=artikel;
		this.protonenzahl=protonenzahl;
		this.valenzelektronen=valenzelektronen;
	}
	
	public ElementAtom(int protonenzahl) {
		this.ordnungszahl=protonenzahl;
		if (protonenzahl == 1) {
			this.name = "Wasserstoff";
			this.symbol = "H";
			this.atomgewicht = 0;
			this.dichteDouble = 0;

			this.elektronegativitätDouble = 0;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 2) {
			this.name = "Helium";
			this.symbol = "He";
			this.atomgewicht = 4.0026;
			this.dichteDouble = 0.00018;
			
			this.elektronegativitätDouble = 0;
			
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		
		if (protonenzahl == 3) {
			this.name = "Lithium";
			this.symbol = "Li";
			this.atomgewicht = 6.94;
			this.dichteDouble = 0.53;

			this.elektronegativitätDouble = 0.98;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 4) {
			this.name = "Berillium";
			this.symbol = "Be";
			this.atomgewicht = 9.0122;
			this.dichteDouble = 1.85;

			this.elektronegativitätDouble = 1.57;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 5) {
			this.name = "Bor";
			this.symbol = "B";
			this.atomgewicht = 10.81;
			this.dichteDouble = 2.46;

			this.elektronegativitätDouble = 2.04;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 6) {
			this.name = "Kohlenstoff";
			this.symbol = "C";
			this.atomgewicht = 12.011;
			this.dichteDouble = 2.26;

			this.elektronegativitätDouble = 2.55;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 7) {
			this.name = "Stickstoff";
			this.symbol = "N";
			this.atomgewicht = 14.007;
			this.dichteDouble = 0.00125;

			this.elektronegativitätDouble = 3.04;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 8) {
			this.name = "Sauerstoff";
			this.symbol = "O";
			this.atomgewicht = 15.999;
			this.dichteDouble = 0.00143;

			this.elektronegativitätDouble = 3.44;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 9) {
			this.name = "Flour";
			this.symbol = "F";
			this.atomgewicht = 18.998;
			this.dichteDouble = 0.0017;

			this.elektronegativitätDouble = 3.98;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 10) {
			this.name = "Neon";
			this.symbol = "Ne";
			this.atomgewicht = 20.18;
			this.dichteDouble = 0.0009;

			this.elektronegativitätDouble = 0;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 11) {
			this.name = "Natrium";
			this.symbol = "Na";
			this.atomgewicht = 22.99;
			this.dichteDouble = 0.97;

			this.elektronegativitätDouble = 0.93;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 12) {
			this.name = "Magnesium";
			this.symbol = "Mg";
			this.atomgewicht = 24.305;
			this.dichteDouble = 1.74;

			this.elektronegativitätDouble = 1.31;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 13) {
			this.name = "Aluminium";
			this.symbol = "Al";
			this.atomgewicht = 26.982;
			this.dichteDouble = 2.7;

			this.elektronegativitätDouble = 1.61;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 14) {
			this.name = "Silicium";
			this.symbol = "Si";
			this.atomgewicht = 28.085;
			this.dichteDouble = 2.34;

			this.elektronegativitätDouble = 1.9;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 15) {
			this.name = "Phosphor";
			this.symbol = "P";
			this.atomgewicht = 30.974;
			this.dichteDouble = 2.69;

			this.elektronegativitätDouble = 2.19;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 16) {
			this.name = "Schwefel";
			this.symbol = "S";
			this.atomgewicht = 32.06;
			this.dichteDouble = 2.07;

			this.elektronegativitätDouble = 2.58;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 17) {
			this.name = "Chlor";
			this.symbol = "Cl";
			this.atomgewicht = 35.45;
			this.dichteDouble = 0.00321;

			this.elektronegativitätDouble = 3.16;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 18) {
			this.name = "Argon";
			this.symbol = "Ar";
			this.atomgewicht = 39.948;
			this.dichteDouble = 0.00178;

			this.elektronegativitätDouble = 0;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 19) {
			this.name = "Kalium";
			this.symbol = "K";
			this.atomgewicht = 39.098;
			this.dichteDouble = 0.97;

			this.elektronegativitätDouble = 0.82;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 20) {
			this.name = "Calcium";
			this.symbol = "Ca";
			this.atomgewicht = 40.078;
			this.dichteDouble = 1.55;

			this.elektronegativitätDouble = 1;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 21) {
			this.name = "Scandium";
			this.symbol = "Sc";
			this.atomgewicht = 44.956;
			this.dichteDouble = 2.98;

			this.elektronegativitätDouble = 1.36;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 22) {
			this.name = "Titan";
			this.symbol = "Ti";
			this.atomgewicht = 47.867;
			this.dichteDouble = 4.5;

			this.elektronegativitätDouble = 1.54;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 23) {
			this.name = "Vanadium";
			this.symbol = "V";
			this.atomgewicht = 50.942;
			this.dichteDouble = 6.11;

			this.elektronegativitätDouble = 1.63;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 24) {
			this.name = "Chrom";
			this.symbol = "Cr";
			this.atomgewicht = 51.996;
			this.dichteDouble = 7.14;

			this.elektronegativitätDouble = 1.66;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 25) {
			this.name = "Mangan";
			this.symbol = "Mn";
			this.atomgewicht = 54.938;
			this.dichteDouble = 7.43;

			this.elektronegativitätDouble = 1.55;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 26) {
			this.name = "Eisen";
			this.symbol = "Fe";
			this.atomgewicht = 44.845;
			this.dichteDouble = 7.87;

			this.elektronegativitätDouble = 1.83;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 27) {
			this.name = "Cobalt";
			this.symbol = "Co";
			this.atomgewicht = 58.933;
			this.dichteDouble = 8.9;

			this.elektronegativitätDouble = 1.88;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 28) {
			this.name = "Nickel";
			this.symbol = "Ni";
			this.atomgewicht = 58.693;
			this.dichteDouble = 8.91;

			this.elektronegativitätDouble = 1.91;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 29) {
			this.name = "Kupfer";
			this.symbol = "Cu";
			this.atomgewicht = 63.546;
			this.dichteDouble = 8.92;

			this.elektronegativitätDouble = 1.9;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 30) {
			this.name = "Zink";
			this.symbol = "Zn";
			this.atomgewicht = 65.8;
			this.dichteDouble = 7.14;

			this.elektronegativitätDouble = 1.65;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 31) {
			this.name = "Gallium";
			this.symbol = "Ga";
			this.atomgewicht = 6.9723;
			this.dichteDouble = 5.9;

			this.elektronegativitätDouble = 1.81;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 32) {
			this.name = "Germanium";
			this.symbol = "Ge";
			this.atomgewicht = 72.63;
			this.dichteDouble = 5.32;

			this.elektronegativitätDouble = 2.01;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 33) {
			this.name = "Arsen";
			this.symbol = "As";
			this.atomgewicht = 74.922;
			this.dichteDouble = 5.73;

			this.elektronegativitätDouble = 2.18;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 34) {
			this.name = "Selen";
			this.symbol = "Se";
			this.atomgewicht = 78.971;
			this.dichteDouble = 4.82;

			this.elektronegativitätDouble = 2.55;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 35) {
			this.name = "Brom";
			this.symbol = "Br";
			this.atomgewicht = 79.904;
			this.dichteDouble = 3.12;

			this.elektronegativitätDouble = 2.96;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 36) {
			this.name = "Krypton";
			this.symbol = "Kr";
			this.atomgewicht = 83.798;
			this.dichteDouble = 0.00375;

			this.elektronegativitätDouble = 3;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 37) {
			this.name = "Rubidium";
			this.symbol = "Rb";
			this.atomgewicht = 85.468;
			this.dichteDouble = 1.53;

			this.elektronegativitätDouble = 0.82;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 38) {
			this.name = "Strontium";
			this.symbol = "Sr";
			this.atomgewicht = 87.62;
			this.dichteDouble = 2.63;

			this.elektronegativitätDouble = 0.95;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 39) {
			this.name = "Yittium";
			this.symbol = "Y";
			this.atomgewicht = 88.906;
			this.dichteDouble = 4.47;

			this.elektronegativitätDouble = 1.22;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 40) {
			this.name = "Zirconium";
			this.symbol = "Zr";
			this.atomgewicht = 91.224;
			this.dichteDouble = 6.5;

			this.elektronegativitätDouble = 1.33;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 41) {
			this.name = "Niob";
			this.symbol = "Nb";
			this.atomgewicht = 92.906;
			this.dichteDouble = 8.57;

			this.elektronegativitätDouble = 1.6;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 42) {
			this.name = "Molybdän";
			this.symbol = "Mo";
			this.atomgewicht = 95.95;
			this.dichteDouble = 10.28;

			this.elektronegativitätDouble = 2.16;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 43) {
			this.name = "Technetium";
			this.symbol = "Tc";
			this.atomgewicht = 96.906;
			this.dichteDouble = 11.50;

			this.elektronegativitätDouble = 1.9;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 44) {
			this.name = "Ruthenium";
			this.symbol = "Ru";
			this.atomgewicht = 101.07;
			this.dichteDouble = 12.37;

			this.elektronegativitätDouble = 2.2;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 45) {
			this.name = "Rhodium";
			this.symbol = "Rh";
			this.atomgewicht = 102.91;
			this.dichteDouble = 12.45;

			this.elektronegativitätDouble = 2.28;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 46) {
			this.name = "Palladium";
			this.symbol = "Pd";
			this.atomgewicht = 106.42;
			this.dichteDouble = 12.02;

			this.elektronegativitätDouble = 2.2;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 47) {
			this.name = "Silber";
			this.symbol = "Ag";
			this.atomgewicht = 107.87;
			this.dichteDouble = 10.49;

			this.elektronegativitätDouble = 1.93;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
		if (protonenzahl == 79) {
			this.name = "Gold";
			this.symbol = "Au";
			this.atomgewicht = 196.97;
			this.dichteDouble = 19.32;

			this.elektronegativitätDouble = 2.54;
			this.potentielleChemischeEnergie = 0;
			this.halbwärtszeit = 0;
			this.elektrischeLeitfähigkeit = 0;
			this.orbitalBefüllungen = new int[10];
			this.häufigkeitUniversum = 0;
			this.häufigkeitSonnensystem = 0;
			this.häufigkeitErde = 0;
			this.häufigketErdoberfläche = 0;

			this.Artikel = ""; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
			this.protonenzahl = ""; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
			this.valenzelektronen=""; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
			this.dichte=""; // Vielfaches der Dichte von H2O in Lumini
				 
			//Color regenerieren
		}
	}

	
	
}
