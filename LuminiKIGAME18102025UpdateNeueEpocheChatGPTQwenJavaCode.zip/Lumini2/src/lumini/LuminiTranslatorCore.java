package lumini;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Lumini Translator Core – Epoche 1.1
 * Andreas Schneider / MatrixGame Project
 * Kombiniert Logik – Energie – Bewusstsein in einem GameLoop.
 */
public class LuminiTranslatorCore {

    // --- Physikalische Konstanten ---
    static final double C = 299_792_458;         // Lichtgeschwindigkeit [m/s]
    static final double LI = 2.8e-10;            // Basislänge (Wasser-Molekül)
    static final double TI = LI / C;             // Basiseinheit der Zeit
    static final double PLANCK = 6.62607015e-34; // Planck-Konstante
    static final double ELEM = 1.60217663e-19;   // Elementarladung

    // --- Symbolkonstanten ---
    static final char POS = '|';   // Unterscheiden / Trennen
    static final char NEG = '-';   // Sein / Existieren
    static final char COMB = '+';  // Erschaffen / Kombinieren

    // --- Basisoperationen ---
    public static String toLumini(double value) {
        String binary = Long.toBinaryString(Double.doubleToRawLongBits(value));
        return binary.replace('0', NEG).replace('1', POS);
    }

    public static double fromLumini(String lumini) {
        String bin = lumini.replace(POS, '1').replace(NEG, '0');
        long bits = Long.parseLong(bin, 2);
        return Double.longBitsToDouble(bits);
    }

    // --- Logische Operatoren ---
    public static boolean NOT(boolean input) { return !input; }
    public static boolean AND(boolean a, boolean b) { return a && b; }
    public static boolean OR(boolean a, boolean b) { return a || b; }
    public static boolean XOR(boolean a, boolean b) { return (a ^ b); }

    // --- Lumini Halbaddierer ---
    public static boolean[] halbaddierer(boolean a, boolean b) {
        boolean summe = XOR(a, b);
        boolean carry = AND(a, b);
        return new boolean[]{carry, summe};
    }

    // --- Energie-Gleichungen ---
    public static double energie(double masse) { return masse * Math.pow(C, 2); }
    public static double frequenz(double energie) { return energie / PLANCK; }
    public static double wellenlaenge(double frequenz) { return C / frequenz; }

    // --- Knock-Code Generator ---
    public static String knockCode(double value) {
        String code = toLumini(value);
        StringBuilder sb = new StringBuilder();
        for (char c : code.toCharArray()) {
            if (c == POS) sb.append("• ");      // kurzer Schlag
            else if (c == NEG) sb.append("— "); // langer Schlag
        }
        return sb.toString();
    }

    // --- GameLoop ---
    public static void startGameLoop() {
        Scanner sc = new Scanner(System.in);
        boolean running = true;
        int epoche = 1;

        System.out.println("🌌 LUMINI TRANSLATOR CORE – Epoche " + epoche);
        System.out.println("Basis: | = Trennung, - = Sein, + = Kombination\n");

        while (running) {
            System.out.println("\n🌀 Menü:");
            System.out.println("1 – Zahl → Lumini-Code");
            System.out.println("2 – Lumini-Code → Zahl");
            System.out.println("3 – Physik-Quest");
            System.out.println("4 – Energie-Analyse");
            System.out.println("5 – Ende");
            System.out.print("Wahl > ");

            String choice = sc.nextLine();
            switch (choice) {
                case "1" -> {
                    System.out.print("Zahl eingeben: ");
                    double v = Double.parseDouble(sc.nextLine());
                    System.out.println("Lumini-Code: " + toLumini(v));
                }
                case "2" -> {
                    System.out.print("Lumini-Code eingeben: ");
                    String code = sc.nextLine();
                    System.out.println("Zahl: " + fromLumini(code));
                }
                case "3" -> physicsQuest();
                case "4" -> energyAnalysis();
                case "5" -> running = false;
                default -> System.out.println("Ungültige Eingabe.");
            }
        }
        sc.close();
        System.out.println("✨ Epoche 1 beendet – Bereit für Epoche 2 (Energie).");
    }

    // --- Physik-Quest ---
    static void physicsQuest() {
        int q = ThreadLocalRandom.current().nextInt(1, 4);
        switch (q) {
            case 1 -> {
                double e = energie(1e-9);
                System.out.println("Energie (1 Nanogramm): " + e + " J");
                System.out.println("Lumini-Code: " + toLumini(e));
            }
            case 2 -> {
                double f = frequenz(energie(1e-9));
                System.out.println("Frequenz: " + f + " Hz");
                System.out.println("Knock-Code: " + knockCode(f));
            }
            case 3 -> {
                double w = wellenlaenge(512);
                System.out.println("Wellenlänge bei 512 Hz: " + w + " m");
                System.out.println("Lumini-Form: " + toLumini(w));
            }
        }
    }

    // --- Energie-Analyse ---
    static void energyAnalysis() {
        System.out.println("⚡ Energieflussgesetz E = m c² → f = E/h → λ = c/f");
        double m = 1e-9;
        double e = energie(m);
        double f = frequenz(e);
        double w = wellenlaenge(f);
        System.out.println("m = " + m + " kg");
        System.out.println("E = " + e + " J");
        System.out.println("f = " + f + " Hz");
        System.out.println("λ = " + w + " m");
    }

    // --- Hauptprogramm ---
    public static void main(String[] args) {
        startGameLoop();
    }
}
