package lumini;
import javax.sound.sampled.*;

public class LuminiSoundEngine {

    public static void spieleFrequenz(double freqHz, int durationMs) {
        float sampleRate = 44100;
        byte[] buffer = new byte[(int) (durationMs * sampleRate / 1000)];
        for (int i = 0; i < buffer.length; i++) {
            double angle = i / (sampleRate / freqHz) * 2.0 * Math.PI;
            buffer[i] = (byte) (Math.sin(angle) * 127);
        }
        try (SourceDataLine line = AudioSystem.getSourceDataLine(new AudioFormat(sampleRate, 8, 1, true, true))) {
            line.open();
            line.start();
            line.write(buffer, 0, buffer.length);
            line.drain();
            line.stop();
        } catch (Exception e) {
            System.err.println("Fehler beim Abspielen der Frequenz: " + e.getMessage());
        }
    }
}
