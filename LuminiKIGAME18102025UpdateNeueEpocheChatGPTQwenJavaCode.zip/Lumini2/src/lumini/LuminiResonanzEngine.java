package lumini;


import java.awt.Color;
import java.util.Random;

public class LuminiResonanzEngine {

    private static final double MAX_FREQ = 1024.0; // obere Tonfrequenzgrenze Hz

    // 🔹 Farbe aus Eigenschaften generieren
    public static Color farbeAusElement(ElementAtom e) {
        float r = (float) (e.elektronegativitätDouble / 4.0);   // bis 4.0 ≈ Fluor
        float g = (float) (e.dichteDouble / 22.6);              // bis Osmium
        float b = (float) (e.atomgewicht / 294.0);              // bis Oganesson
        r = clamp(r, 0f, 1f); g = clamp(g, 0f, 1f); b = clamp(b, 0f, 1f);
        return new Color(r, g, b);
    }

    // 🔹 Tonfrequenz aus Elektronegativität
    public static double frequenzAusElement(ElementAtom e) {
        return 256.0 + (e.elektronegativitätDouble / 4.0) * (MAX_FREQ - 256.0);
    }

    // 🔹 Resonanz: Kombination zweier Elemente
    public static String resonanz(ElementAtom a, ElementAtom b) {
        String codeA = LuminiSymbolAdapter.toLuminiCode(a.elektronegativitätDouble, 4.0);
        String codeB = LuminiSymbolAdapter.toLuminiCode(b.elektronegativitätDouble, 4.0);
        String combined = LuminiSymbolAdapter.combine(codeA, codeB);

        double fA = frequenzAusElement(a);
        double fB = frequenzAusElement(b);
        double fRes = (fA + fB) / 2.0;

        Color ca = farbeAusElement(a);
        Color cb = farbeAusElement(b);
        Color cres = mixColors(ca, cb);

        return """
        ⚗️  Lumini-Resonanz-Simulation
        Elemente: %s (%s) + %s (%s)
        Symbolcode: %s
        Frequenzen: %.2f Hz  &  %.2f Hz  →  Resonanz %.2f Hz
        Farbe-Mix RGB: (%.2f, %.2f, %.2f)
        """.formatted(
                a.name, a.symbol, b.name, b.symbol,
                combined,
                fA, fB, fRes,
                cres.getRed() / 255.0, cres.getGreen() / 255.0, cres.getBlue() / 255.0);
    }

    // 🔹 Mischfarben-Berechnung
    private static Color mixColors(Color c1, Color c2) {
        return new Color(
                (c1.getRed() + c2.getRed()) / 2,
                (c1.getGreen() + c2.getGreen()) / 2,
                (c1.getBlue() + c2.getBlue()) / 2);
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    // 🔹 Demo-Main
    public static void main(String[] args) {
        LuminiPeriodensystem ps = new LuminiPeriodensystem();
        ElementAtom natrium = ps.getElementBySymbol("Na");
        ElementAtom chlor   = ps.getElementBySymbol("Cl");

        System.out.println(resonanz(natrium, chlor));

        ElementAtom wasserstoff = ps.getElementBySymbol("H");
        ElementAtom sauerstoff  = ps.getElementBySymbol("O");
        System.out.println(resonanz(wasserstoff, sauerstoff));
        
        ElementAtom Kohlenstoff = ps.getElementBySymbol("C");
        ElementAtom Phosphor  = ps.getElementBySymbol("P");
        System.out.println(resonanz(Kohlenstoff, wasserstoff));
        
   
        System.out.println(resonanz(Kohlenstoff, sauerstoff));
    }
}
