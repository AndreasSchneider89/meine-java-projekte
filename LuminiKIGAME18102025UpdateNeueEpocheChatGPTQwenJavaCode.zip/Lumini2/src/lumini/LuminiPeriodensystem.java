package lumini;

import java.util.HashMap;
import java.util.Map;

public class LuminiPeriodensystem {
    private Map<Integer, ElementAtom> elemente = new HashMap<>();
    Map<String, ElementAtom> symbole = new HashMap<>();

    public LuminiPeriodensystem() {
        // Erzeuge alle bekannten Elemente (bisher 1–47)
        for (int i = 1; i <= 47; i++) {
            ElementAtom e = new ElementAtom(i);
            elemente.put(i, e);
            symbole.put(e.symbol, e);
        }
    }

    public ElementAtom getElementByNumber(int nummer) {
        return elemente.get(nummer);
    }

    public ElementAtom getElementBySymbol(String symbol) {
        return symbole.get(symbol);
    }

    public void printAll() {
        for (int i = 1; i <= elemente.size(); i++) {
            ElementAtom e = elemente.get(i);
            if (e != null) {
                System.out.printf("%3d %-12s %-3s %.4f g/mol, Dichte %.3f g/cm³, EN=%.2f%n",
                        e.ordnungszahl, e.name, e.symbol, e.atomgewicht, e.dichteDouble, e.elektronegativitätDouble);
            }
        }
    }

    // Beispiel: Berechnung der durchschnittlichen Elektronegativität aller Elemente
    public double durchschnittElektronegativitaet() {
        double sum = 0;
        int count = 0;
        for (ElementAtom e : elemente.values()) {
            if (e.elektronegativitätDouble > 0) {
                sum += e.elektronegativitätDouble;
                count++;
            }
        }
        return count > 0 ? sum / count : 0;
    }

    // Lumini-Erweiterung (Placeholder)
    public String getLuminiCode(ElementAtom e) {
        if (e == null) return "";
        return "|".repeat((int) Math.round(e.elektronegativitätDouble)) + "-";
    }

    // Test-Main
    public static void main(String[] args) {
        LuminiPeriodensystem ps = new LuminiPeriodensystem();
        ps.printAll();

        System.out.println("\nTest: Suche Fe → " + ps.getElementBySymbol("Fe").name);
        System.out.println("Durchschnittliche Elektronegativität: " + ps.durchschnittElektronegativitaet());
    }
}
