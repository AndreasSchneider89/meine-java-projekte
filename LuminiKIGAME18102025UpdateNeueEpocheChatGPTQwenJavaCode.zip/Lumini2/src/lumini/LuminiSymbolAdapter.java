package lumini;

public class LuminiSymbolAdapter {

    // --- Parameterbereich (anpassbar an Lumini-Normierung) ---
    private static final double MAX_DICHTE = 22.6;        // Osmium
    private static final double MAX_ELEKTRONEG = 4.0;     // Fluor
    private static final double MAX_ATOMMASSE = 294.0;    // Oganesson (Z=118)

    /**
     * Wandelt einen Skalarwert (z.B. Dichte, EN, Atomgewicht)
     * in einen normierten Lumini-String um.
     */
    public static String toLuminiCode(double value, double max) {
        if (value <= 0) return "-";
        int bars = (int) Math.round((value / max) * 8); // max 8 Zeichen
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < bars; i++) code.append("|");
        for (int i = bars; i < 8; i++) code.append("-");
        return code.toString();
    }

    /**
     * Kombiniert Dichte, Elektronegativität und Atomgewicht
     * in einen Gesamt-Lumini-Code (dreischichtiges Symbol).
     */
    public static String elementToLumini(ElementAtom e) {
        if (e == null) return "---";
        String dichteCode = toLuminiCode(e.dichteDouble, MAX_DICHTE);
        String enCode = toLuminiCode(e.elektronegativitätDouble, MAX_ELEKTRONEG);
        String atomgewichtCode = toLuminiCode(e.atomgewicht, MAX_ATOMMASSE);

        return """
        [%s]
        Dichte:        %s
        Elektroneg.:   %s
        Atomgewicht:   %s
        """.formatted(e.symbol, dichteCode, enCode, atomgewichtCode);
    }

    /**
     * Kombiniert Codes logisch (z.B. für Moleküle oder Verbindungen)
     */
    public static String combine(String codeA, String codeB) {
        StringBuilder out = new StringBuilder();
        int len = Math.min(codeA.length(), codeB.length());
        for (int i = 0; i < len; i++) {
            char a = codeA.charAt(i);
            char b = codeB.charAt(i);
            out.append(combineSymbol(a, b));
        }
        return out.toString();
    }

    private static char combineSymbol(char a, char b) {
        if (a == '|' && b == '|') return '+';
        if (a == '-' && b == '-') return '-';
        if ((a == '|' && b == '-') || (a == '-' && b == '|')) return '|';
        return '+';
    }

    // --- Testlauf ---
    public static void main(String[] args) {
        LuminiPeriodensystem ps = new LuminiPeriodensystem();
        ElementAtom o = ps.getElementBySymbol("O");  // Sauerstoff
        ElementAtom h = ps.getElementBySymbol("H");  // Wasserstoff

        System.out.println("🌟 Lumini-Symbolisierung 🌟");
        System.out.println(elementToLumini(o));
        System.out.println(elementToLumini(h));

        String wasser = combine(toLuminiCode(o.dichteDouble, MAX_DICHTE),
                                toLuminiCode(h.dichteDouble, MAX_DICHTE));

        System.out.println("H₂O → " + wasser);
    }
}
