package lumini;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 🎨 Lumini Resonanz Visualizer
 * Visualisiert Farben, Frequenzen und Lumini-Codes zweier kombinierter Elemente.
 * Andreas Schneider – MatrixGame Epoche 1–2
 */
public class LuminiResonanzVisualizer extends JFrame {

    private final LuminiPeriodensystem ps = new LuminiPeriodensystem();

    private final JComboBox<String> elementABox;
    private final JComboBox<String> elementBBox;
    private final JTextArea outputArea;
    private final JPanel colorPanel;

    public LuminiResonanzVisualizer() {
        setTitle("🌌 Lumini Resonanz Visualizer");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔹 Kopfbereich
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        elementABox = new JComboBox<>(ps.symbole.keySet().toArray(new String[0]));
        elementBBox = new JComboBox<>(ps.symbole.keySet().toArray(new String[0]));
        JButton combineBtn = new JButton("Resonanz berechnen");
        combineBtn.addActionListener(new ResonanzAktion());
        topPanel.add(new JLabel("Element A:"));
        topPanel.add(elementABox);
        topPanel.add(new JLabel("Element B:"));
        topPanel.add(elementBBox);
        topPanel.add(combineBtn);

        // 🔹 Textausgabe
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 14));

        // 🔹 Farbfeld
        colorPanel = new JPanel();
        colorPanel.setPreferredSize(new Dimension(200, 200));
        colorPanel.setBackground(Color.BLACK);

        // 🔹 Layout
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);
        add(colorPanel, BorderLayout.SOUTH);
    }

    // 🔹 Aktion beim Klick auf "Resonanz berechnen"
    private class ResonanzAktion implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String symA = (String) elementABox.getSelectedItem();
            String symB = (String) elementBBox.getSelectedItem();
            ElementAtom a = ps.getElementBySymbol(symA);
            ElementAtom b = ps.getElementBySymbol(symB);

            String info = LuminiResonanzEngine.resonanz(a, b);
            outputArea.setText(info);

            // Farbe visualisieren
            Color mixed = LuminiResonanzEngine.farbeAusElement(a);
            Color mixed2 = LuminiResonanzEngine.farbeAusElement(b);
            Color res = new Color(
                    (mixed.getRed() + mixed2.getRed()) / 2,
                    (mixed.getGreen() + mixed2.getGreen()) / 2,
                    (mixed.getBlue() + mixed2.getBlue()) / 2);
            colorPanel.setBackground(res);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LuminiResonanzVisualizer gui = new LuminiResonanzVisualizer();
            gui.setVisible(true);
        });
    }
}


