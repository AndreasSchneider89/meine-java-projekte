package lumini;

import lumini.LuminiTranslatorCore;
import java.util.*;

/**
 * 🌐 LuminiSystemIntegrator – Epoche 1 ↔ WahresLuminiPSE
 * Andreas Schneider / MatrixGame Project
 * Bindet PSE-Elemente an den Lumini-TranslatorCore.
 */
public class LuminiSystemIntegrator {

    /** Interner Datentyp für PSE-Elemente */
    static class LuminiElement {
        String name;
        String symbol;
        double mass;        // in kg
        double energy;      // in Joule
        double frequency;   // in Hz
        String luminiCode;  // symbolischer Lumini-Code

        LuminiElement(String name, String symbol, double mass) {
            this.name = name;
            this.symbol = symbol;
            this.mass = mass;
            updateDerivedValues();
        }

        /** Berechnet Energie, Frequenz und Code */
        void updateDerivedValues() {
            this.energy = LuminiTranslatorCore.energie(mass);
            this.frequency = LuminiTranslatorCore.frequenz(energy);
            this.luminiCode = LuminiTranslatorCore.toLumini(energy);
        }

        @Override
        public String toString() {
            return "%s (%s) – m=%.3e kg, E=%.3e J, f=%.3e Hz\nLuminiCode=%s"
                    .formatted(name, symbol, mass, energy, frequency, luminiCode);
        }
    }

    // Datenbank aller Elemente
    static Map<String, LuminiElement> pse = new LinkedHashMap<>();

    /** Initialisierung mit Basiselementen */
    public static void init() {
        pse.put("Hydrogen", new LuminiElement("Hydrogen", "H", 1.67e-27));
        pse.put("Helium", new LuminiElement("Helium", "He", 6.64e-27));
        pse.put("Carbon", new LuminiElement("Carbon", "C", 1.99e-26));
        pse.put("Oxygen", new LuminiElement("Oxygen", "O", 2.66e-26));
        pse.put("Gold", new LuminiElement("Gold", "Au", 3.27e-25));
        pse.put("ZZ", new LuminiElement("ZZ", "ZZ", 1e-0));
        pse.put("ZZ2", new LuminiElement("ZZ2", "ZZ2", 2e-0));
        pse.put("ZZ3", new LuminiElement("ZZ", "ZZ4", 4e-0));
        pse.put("ZZ4", new LuminiElement("ZZ2", "ZZ25", 8e-0));
    }

    /** Zeigt das gesamte Lumini-PSE */
    public static void showAll() {
        System.out.println("🌞 Wahres Lumini PSE – Epoche 1 Integration");
        pse.values().forEach(System.out::println);
    }

    /** Suche nach Symbol oder Name */
    public static LuminiElement find(String key) {
        return pse.getOrDefault(key, pse.values().stream()
                .filter(e -> e.symbol.equalsIgnoreCase(key) || e.name.equalsIgnoreCase(key))
                .findFirst().orElse(null));
    }

    /** Vergleich zweier Elemente */
    public static void compare(String a, String b) {
        LuminiElement e1 = find(a);
        LuminiElement e2 = find(b);
        if (e1 == null || e2 == null) {
            System.out.println("❌ Element nicht gefunden.");
            return;
        }
        double ratio = e1.energy / e2.energy;
        System.out.printf("⚖️ Energieverhältnis %s:%s = %.4f%n", e1.symbol, e2.symbol, ratio);
        System.out.println("Δf = " + Math.abs(e1.frequency - e2.frequency) + " Hz");
    }

    /** Mini-GameLoop – Lumini PSE Explorer */
    public static void startExplorer() {
        Scanner sc = new Scanner(System.in);
        init();
        boolean running = true;

        System.out.println("🧬 Lumini PSE Explorer – Verbunden mit Translator Core 🧩");
        while (running) {
            System.out.println("\n1 – Zeige alle Elemente");
            System.out.println("2 – Finde Element");
            System.out.println("3 – Vergleiche zwei Elemente");
            System.out.println("4 – Physik-Quest (TranslatorCore)");
            System.out.println("5 – Ende");
            System.out.print("Wahl > ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> showAll();
                case "2" -> {
                    System.out.print("Name oder Symbol: ");
                    String key = sc.nextLine();
                    LuminiElement e = find(key);
                    System.out.println(e != null ? e : "Nicht gefunden.");
                }
                case "3" -> {
                    System.out.print("Erstes Element: ");
                    String a = sc.nextLine();
                    System.out.print("Zweites Element: ");
                    String b = sc.nextLine();
                    compare(a, b);
                }
                case "4" -> LuminiTranslatorCore.physicsQuest();
                case "5" -> running = false;
                default -> System.out.println("Ungültige Eingabe.");
            }
        }
        sc.close();
        System.out.println("🌐 Integration beendet – Epoche 1 vollständig synchronisiert.");
    }

    /** Startpunkt */
    public static void main(String[] args) {
        startExplorer();
    }
}
