/**
 * 
 */
/**
 * 
 */
module Lumini2 {
	requires java.desktop;
}