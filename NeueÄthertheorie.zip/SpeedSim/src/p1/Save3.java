package p1;

public class Save3 {

    public static void main(String[] args) {
        double geschwindigkeitTestmasse = 0.0;   // Geschwindigkeit der Testmasse
        double gesamtenergie = 0.0;              // Kumulierte Gesamtenergie
        
        final double geschwindigkeitProjektil = 300000.0;  // Konstante Geschwindigkeit der Projektile
        final double masseProjektil = 1.0;                 // Masse eines einzelnen Projektils
        final double masseTestmasse = 100.0;              // Masse der Testmasse
        
        double ätherdichte = 0.001;
        double testMasseOberfläche=1;
        

        for (int i = 0; i < 500; i++) {
            // Berechnung der Geschwindigkeitsänderung mittels elastischem Stoß
            final double deltaV = (2 * masseProjektil / (masseProjektil + masseTestmasse))
                                * Math.min((geschwindigkeitProjektil - geschwindigkeitTestmasse),300000);
            
            geschwindigkeitTestmasse += deltaV;
            
            // Energieberechnung (kinetische Energie des Projektils)
            gesamtenergie += 0.5 * masseProjektil * Math.pow(geschwindigkeitProjektil, 2);

            System.out.printf(
                "Iteration %2d: Geschwindigkeit = %9.2f m/s, Energieaufwand = %.2f J%n",
                i+1, geschwindigkeitTestmasse, gesamtenergie
            );
        }
    }
}