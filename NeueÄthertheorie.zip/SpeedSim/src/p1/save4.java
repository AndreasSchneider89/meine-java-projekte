package p1;

public class save4 {
	
	static double geschwindigkeitTestmasse = 0.0;   // Geschwindigkeit der Testmasse
	static double gesamtenergie = 0.0;              // Kumulierte Gesamtenergie
	static double zeitSchritt = 0.001;             // Zeitlicher Abstand zwischen den Berechnungen (in Sekunden)

    final static double geschwindigkeitProjektil = 300000.0;  // Konstante Geschwindigkeit der Projektile
    static double masseProjektil = 10.0;                 // Masse eines einzelnen Projektils
    static double masseTestmasse = 100.0;              // Masse der Testmasse

    // Parameter für den Luftwiderstand (angenommene Werte)
    static double Eterdichte = 3.69262695323247E-11;         //0.0000121// Dichte der Luft in kg/m^3 (bei Normalbedingungen)
    static double widerstandsBeiwert = 0.5;    // Beispielhafter Widerstandsbeiwert (hängt von der Form ab)
    static double querschnittsFlaeche = 0.1;   // Beispielhafte Querschnittsfläche in m^2

    public static void main(String[] args) {
    	
//    	System.out.println(durchlauf(100000)[1]);
    	double schritt = Eterdichte/2;
    	for(int i=0; i<10; i++) {
    	double[] ergebnis = durchlauf(1000000);
        if(ergebnis[0]>ergebnis[1])Eterdichte= Eterdichte-schritt;
        else Eterdichte= Eterdichte+schritt;
        schritt=schritt/2;
        System.out.println("Eterdichte"+Eterdichte+"unsereverschwendung"+ergebnis[0]+"wert"+ergebnis[0]);

    	}
    }
    
    public static double[] durchlauf(int iterationen) {
    	 for (int i = 0; i < iterationen; i++) {
             // Berechnung der Geschwindigkeitsänderung durch elastischen Stoß
             final double deltaVStoss = (2 * masseProjektil / (masseProjektil + masseTestmasse))
                                    * Math.min((geschwindigkeitProjektil - geschwindigkeitTestmasse), 300000);

             geschwindigkeitTestmasse += deltaVStoss;

             // Berechnung der Luftwiderstandskraft
             double luftWiderstandsKraft = -0.5 * Eterdichte * widerstandsBeiwert * querschnittsFlaeche * Math.pow(geschwindigkeitTestmasse, 2);

             // Berechnung der Beschleunigung durch den Luftwiderstand
             double beschleunigungLuftWiderstand = luftWiderstandsKraft / masseTestmasse;

             // Änderung der Geschwindigkeit aufgrund des Luftwiderstands über den Zeitschritt
             geschwindigkeitTestmasse += beschleunigungLuftWiderstand * zeitSchritt;

             // Energieberechnung (kinetische Energie des Projektils)
             gesamtenergie += 0.5 * masseProjektil * Math.pow(geschwindigkeitProjektil, 2);
             
             double kinetischeEnergie = 0.5*geschwindigkeitTestmasse*geschwindigkeitTestmasse*masseTestmasse;
             double zeichen = gesamtenergie/kinetischeEnergie;
             
             double zeichen2=1.0/Math.sqrt(1-geschwindigkeitTestmasse*geschwindigkeitTestmasse/300000/300000);

             
//             System.out.println("Faktor der Energieverschwendung"+zeichen+"HergeleiteterFaktor"+zeichen2);
             if(i==iterationen-1) {double[] ausgabe = new double[2];
          	ausgabe[0]=zeichen;
          	ausgabe[1]=zeichen2; return ausgabe;}
         } 
    	 double[] ausgabe = new double[2];
    	 return ausgabe;
    }
}