package p1;

public class Save1 {

	public static void main(String[] args) {
		double speedTestmasse = 0;
		double nötigeEnergie=0;
		for (int i = 0; i < 100; i++) {
			double speedBeschleuniger = 300000;
			double masseBeschleuniger = 1;
			nötigeEnergie += speedBeschleuniger * speedBeschleuniger * masseBeschleuniger;

			double masseTestmasse = 1000;
			

			double übertrageneEnergie = (speedBeschleuniger - speedTestmasse) * (speedBeschleuniger - speedTestmasse)
					* masseBeschleuniger;
			speedTestmasse += Math.sqrt(übertrageneEnergie / masseTestmasse);
			System.out.println("Speed Terstmasse: "+speedTestmasse+"Benötigte Energie: "+nötigeEnergie);
		}
	}

}
