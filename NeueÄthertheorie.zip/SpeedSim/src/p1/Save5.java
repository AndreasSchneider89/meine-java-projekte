package p1;

public class Save5 {

	static double geschwindigkeitTestmasse = 0.0;   // Geschwindigkeit der Testmasse (m/s)
    static double gesamtEnergieInput = 0.0;          // Kumulierte Energie, die dem System zugeführt wird (Joule)
    static double zeitSchritt = 1e-15;             // Sehr kleiner Zeitschritt (Sekunden)

    final static double geschwindigkeitProjektil = 3e8;  // Lichtgeschwindigkeit als obere Grenze (m/s)
    static double masseProjektil = 9.1093837e-31 ;       // Masse eines Protons (kg) - als Beispiel für ein leichtes Teilchen
    static double masseTestmasse = 1.67262192e-27;        // Masse des zu beschleunigenden Teilchens (Proton)

    // Parameter für den Ätherwiderstand (sehr klein angenommen, um Auswirkungen zu sehen)
    static double eterDichte = 1.0e-11;             // Extrem geringe Ätherdichte (kg/m^3)
    static double widerstandsBeiwert = 0.5;        // Widerstandsbeiwert (dimensionslos)
    static double querschnittsFlaeche = 1e-20;       // Geschätzter Querschnitt des Teilchens (m^2)

    public static void main(String[] args) {
    		beschleunigung(20000000);
    }

    public static void beschleunigung(int iterationen) {
        geschwindigkeitTestmasse = 0.0; // Reset der Geschwindigkeit für jeden Durchlauf
        gesamtEnergieInput = 0.0;        // Reset der Energie für jeden Durchlauf

        for (int i = 0; i < iterationen; i++) {
            // Berechnung der Geschwindigkeitsänderung durch elastischen Stoß
            final double deltaVStoss = (2 * masseProjektil / (masseProjektil + masseTestmasse))
                                    * Math.min((geschwindigkeitProjektil - geschwindigkeitTestmasse), 300000000);

            geschwindigkeitTestmasse += deltaVStoss;

            // Berechnung der Ätherwiderstandskraft
            double eterWiderstandsKraft = -0.5 * eterDichte * widerstandsBeiwert * querschnittsFlaeche * Math.pow(geschwindigkeitTestmasse, 2);

            // Berechnung der Beschleunigung durch den Ätherwiderstand
            double beschleunigungEterWiderstand = eterWiderstandsKraft / masseTestmasse;

            // Änderung der Geschwindigkeit aufgrund des Ätherwiderstands über den Zeitschritt
            geschwindigkeitTestmasse += beschleunigungEterWiderstand * zeitSchritt;

            // Energieberechnung (kinetische Energie des hinzugefügten Projektils)
            gesamtEnergieInput += 0.5 * masseProjektil * Math.pow(geschwindigkeitProjektil, 2);

            double kinetischeEnergieTestmasse = 0.5 * masseTestmasse * Math.pow(geschwindigkeitTestmasse, 2);
            double energieVerhaeltnis = gesamtEnergieInput / kinetischeEnergieTestmasse;

            double lorenzFaktor = 1.0 / Math.sqrt(1 - (geschwindigkeitTestmasse * geschwindigkeitTestmasse) / (300000000.0 * 300000000.0));
            if(i%200==0)System.out.println("geschwindigkeitTestmasse: "+geschwindigkeitTestmasse+"energieVerhaeltnis: "+energieVerhaeltnis+"lorenzFaktor: "+lorenzFaktor);
//            if (i == iterationen - 1) {
//                return new double[]{energieVerhaeltnis, lorenzFaktor};
//            }
        }
//        return new double[]{0.0, 0.0}; // Sollte eigentlich nicht erreicht werden
    }
}