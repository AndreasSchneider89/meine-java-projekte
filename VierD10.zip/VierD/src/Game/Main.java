package Game;

/**
Mein Ziel ist es die Java-Spieleentwicklung durch paralleles Programmieren der Youtube Tutorialreihe zu erlernen und am Ende etwas v�llig neues; ein Spiel in dem es nicht nur 2 oder 3 sondern 4 Raumdimensionen gibt. 
Der Pythagoras sowie Trigonometrie und Halbieren der Gr��e bei doppelter Entfernung sollen weiterhin existieren und auf dem 2D Bildschirm dargestellt werden! (Beispiel: Tesserakt)
Youtube Tutorial Reihe von: MrJavaFrank
https://www.youtube.com/watch?v=VRrzDoarC1k&list=PL-buEZyaAaNizo7vQ9B4JHjAwQfqyW5GN&index=7
Weitere Planung sowie meine Hoffnung auf gemeinsamen Ausbau und kollektives Wachstum: 
https://www.facebook.com/andreas.schneider.7393264/
*/

import javax.swing.JFrame;

public class Main {

	static int width = 800;
	static int height = 600;

	public static void main(String[] args) {
		Frame frame = new Frame();
		frame.setSize(width, height);
		frame.setDefaultCloseOperation(3);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setUndecorated(true);
		frame.setVisible(true);

		frame.makestrat();

		long lastFrame = System.currentTimeMillis();

		while (true) {
			long thisFrame = System.currentTimeMillis();
			float timeSinceLastFrame = (float) ((thisFrame - lastFrame) / 1000.0);
			lastFrame = thisFrame;

			frame.update(timeSinceLastFrame);
			frame.repaint();
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
