package main;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Frame extends JFrame {
	Sicht sicht;
	paint zeichnen;
	public Frame(Sicht sicht){
		super("MyGame v1.0");
		this.sicht = sicht;
		zeichnen = new paint();
		zeichnen.setBounds(0, 0, 1350, 750);
		addKeyListener(new keyCheck());
		add(zeichnen);
	}
	public void repaintScreen(){
		zeichnen.repaint();
	}
	private class paint extends JLabel{
		double[] Punkt = sicht.getPunkt();  //erstes+ -> runter, zweites+ -> rechts;
		double zoom2Pot = sicht.getZoom2Pot();
		
		
		
		double zoom = Math.pow(2, zoom2Pot);
		double pr�zision = 50;
		int iterationen = 100 + (int) (Math.log10(zoom) * pr�zision);
		double farbDarstellung = iterationen/110.0;
		double obererRand = Punkt[0]-1.1/zoom;
		double linkerRand = Punkt[1]-2.1/zoom;
		double zelle = 0.00325/zoom;
		
		public int checkC(double reC, double imC) {
			double reZ = 0, imZ = 0, reZ_minus1 = 0, imZ_minus1 = 0;
			int i = 0;
			for (i = 0; i < iterationen; i++) {
				imZ = 2 * reZ_minus1 * imZ_minus1 + imC;
				reZ = reZ_minus1 * reZ_minus1 - imZ_minus1 * imZ_minus1 + reC;
				if (reZ * reZ + imZ * imZ > 4)
					return i;
				reZ_minus1 = reZ;
				imZ_minus1 = imZ;
			}
			return i;
		}
		@Override
//		public void paint (Graphics g){
//			super.paintComponents(g);
//			g.setColor(Color.ORANGE);
//			g.fillRect(sicht.getBounding().x, sicht.getBounding().y, sicht.getBounding().width, sicht.getBounding().height);}
		public void paintComponent(Graphics g) {
			double reC, imC; 
			int x, y;

			imC = obererRand; // oberer Rand
			for (y = 0; y < 750; y++) {
				reC = linkerRand; // linker Rand
				for (x = 0; x < 1350; x++) {
					int R = 0;
					int Gr = 0;
					int B = 0;
					if (checkC(reC, imC) <= 10*farbDarstellung) R=5+(int) (25/farbDarstellung * checkC(reC, imC));
					else if (checkC(reC, imC) <= 35*farbDarstellung){R=(int) (250-10/farbDarstellung*(checkC(reC, imC)-10*farbDarstellung)); Gr=(int) (10/farbDarstellung*(checkC(reC, imC)-10*farbDarstellung));}
					else if (checkC(reC, imC) <= 60*farbDarstellung){Gr=(int) (250-10/farbDarstellung*(checkC(reC, imC)-35*farbDarstellung)); B=(int) (10/farbDarstellung*(checkC(reC, imC)-35*farbDarstellung));}
					else if (checkC(reC, imC) <= 85*farbDarstellung){B=(int) (250-5/farbDarstellung*(checkC(reC, imC)-60*farbDarstellung)); R=(int) (10/farbDarstellung*(checkC(reC, imC)-60*farbDarstellung));}
					else if (checkC(reC, imC) <= 110*farbDarstellung){R=(int) (250-10/farbDarstellung*(checkC(reC, imC)-85*farbDarstellung));B=(int) (250-5/farbDarstellung*(checkC(reC, imC)-60*farbDarstellung));}
					
					
						{Color colAppleman = new Color(R, Gr, B); // Farbe Apfelm�nnchen
						g.setColor(colAppleman);
						g.drawLine(x, y, x, y);
					}
					reC = reC + zelle; // n�chste Spalte
				}
				imC = imC + zelle; // n�chste Zeile
			}
			
		}
		}
		
	}


