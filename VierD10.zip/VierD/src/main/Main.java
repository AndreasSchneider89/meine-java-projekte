package main;

public class Main {

	public static void main(String[] args) {
		System.out.println("ff");
		// Mandelbrotmenge mandel = new Mandelbrotmenge();
		Sicht sicht = new Sicht();
		Frame frm = new Frame(sicht);
		frm.setLayout(null);
		frm.setSize(1350, 750);
		frm.setVisible(true);
		frm.setDefaultCloseOperation(Frame.EXIT_ON_CLOSE);

		while (true) {
			sicht.update();
			frm.repaintScreen();
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}
}
