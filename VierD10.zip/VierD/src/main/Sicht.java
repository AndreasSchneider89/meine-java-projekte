package main;

import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class Sicht {
	private Rectangle bounding;
	private int ply_x;
	private int ply_y;
	public Sicht(){
		ply_x = 200;
		ply_y = 450;
		bounding = new Rectangle (ply_x, ply_y, 70, 70);
	}
	
	double[] Punkt = {0,0};
	double zoom2Pot = 0;
	
	public void update(){
		if(keyCheck.keysCheck(KeyEvent.VK_Q)){
			zoom2Pot -=0.5;
			System.out.println(zoom2Pot);
		}
		if(keyCheck.keysCheck(KeyEvent.VK_E)){
			zoom2Pot +=0.5;
			System.out.println(zoom2Pot);
		}
		if(keyCheck.keysCheck(KeyEvent.VK_A)){
			Punkt[0] -=0.05;  ply_x-=5;
		}
		if(keyCheck.keysCheck(KeyEvent.VK_D)){
			Punkt[0] +=0.05;  ply_x+=5;
		}
		if(keyCheck.keysCheck(KeyEvent.VK_W)){
			Punkt[1] -=0.05;  ply_y-=5;
		}
		if(keyCheck.keysCheck(KeyEvent.VK_S)){
			Punkt[1] +=0.05;  ply_y+=5;
		}
		bounding.x = ply_x;
		bounding.y = ply_y;
	}
		public Rectangle getBounding(){
			return bounding;
		}

	public double[] getPunkt() {
		return Punkt;
	}

	public double getZoom2Pot() {
		return zoom2Pot;
	}	
}
